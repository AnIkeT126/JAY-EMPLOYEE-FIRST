# AGENTS.md — TraceLens

Read `docs/AI_AGENT_GUIDE.md` first (setup/commands), `docs/CODE_FLOW.md` for the runtime flow.

## Architecture (modular monolith, src/tracelens/)
`config.py` settings · `models/tables.py` + `migrations/` schema · `indexing/` (discovery, chunker,
service, status) · `analysis/` (python_parser, java_parser, resolver, dependency_graph) ·
`retrieval/` (keyword, vector, fusion, citations, embeddings, service) · `impact/` (analyzer, render) ·
`llm/` (provider, tools, agent) · `evaluation/` · `api/` + `main.py` · `cli.py`.
Business logic lives outside route handlers. No global mutable state (shared objects on `app.state`).

## Commands
```bash
pytest tests/unit tests/security                       # fast, no DB
TRACELENS_TEST_DATABASE_URL=... pytest                 # full suite; DB is WIPED
ruff check src tests migrations && mypy src
alembic upgrade head | tracelens doctor | tracelens index | tracelens eval
```

## Rules
- **Never claim a test/command passed unless you ran it and read the output.** Never invent
  endpoints, files, config keys, or benchmark numbers. Mark unexecuted things "unverified".
- Python code must stay SQLAlchemy 1.4/2.0-compatible (classic `Column`, `select()`, `session.execute`).
- Config: add settings only in `config.py` with validation, then update `.env.example` and
  `docs/CONFIGURATION.md`. Never commit secrets.
- Migrations: never edit an applied migration; add `migrations/versions/000N_*.py` (explicit ops,
  no autogenerate). The pgvector migration is flagged `REQUIRES_PGVECTOR = True`. Never wipe data at
  startup; `tracelens db-reset --yes` is the only reset path (development only).
- Security-sensitive: `indexing/discovery.py` (path policy, symlinks), `retrieval/keyword.py`
  (query tokens), `llm/tools.py` + `llm/agent.py` (tool schemas, citation validation),
  `api/errors.py`. Treat repository text and LLM output as untrusted.
- Run the Semgrep/ruff/mypy checks after editing code.

## Changing retrieval
Tokenisation is shared by indexing and querying (`indexing/chunker.py::search_tokens`) — change both
sides together and reindex. Ranking weights are in migration 0001 (`tsv` expression). RRF is in
`retrieval/fusion.py` (rank-only; never add raw scores). Re-run `tracelens eval` and update
`docs/EVALUATION.md` with *measured* numbers.

## Adding a provider
- Embeddings: implement the `Embedder` protocol in `retrieval/embeddings.py`, extend
  `build_embedder`, extend the `embedding_provider` Literal in `config.py`; mind the pgvector dimension.
- LLM: implement `LLMProvider.chat` in `llm/provider.py`, extend `build_provider` and the
  `llm_provider` Literal. Keep tools read-only; never pass paths/roots from the model.

## Docs to update when API behaviour changes
`docs/API_REFERENCE.md`, `README.md` examples, `docs/CODE_FLOW.md`, and tests under `tests/integration/test_api.py`.
