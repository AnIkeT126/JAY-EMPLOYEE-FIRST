"""LLM provider interface and an OpenAI-compatible chat-completions client (httpx)."""

from __future__ import annotations

from typing import Protocol

import httpx

from tracelens.config import Settings
from tracelens.errors import LLMError


class LLMProvider(Protocol):
    def chat(self, messages: list[dict], tools: list[dict]) -> dict:
        """Return the assistant message: {"content": str | None, "tool_calls": [...]}."""
        ...


class OpenAICompatibleProvider:
    """Works with any server implementing POST {base_url}/chat/completions with tool calling."""

    def __init__(self, base_url: str, model: str, api_key: str | None, timeout: float) -> None:
        self._url = base_url.rstrip("/") + "/chat/completions"
        self._model = model
        self._headers = {"Content-Type": "application/json"}
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"
        self._timeout = timeout

    def chat(self, messages: list[dict], tools: list[dict]) -> dict:
        body: dict = {"model": self._model, "messages": messages, "temperature": 0}
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        try:
            response = httpx.post(self._url, json=body, headers=self._headers,
                                  timeout=self._timeout)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]
        except httpx.TimeoutException as exc:
            raise LLMError("LLM request timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise LLMError(f"LLM provider returned HTTP {exc.response.status_code}") from exc
        except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
            raise LLMError(f"LLM request failed: {type(exc).__name__}") from exc


def build_provider(settings: Settings) -> LLMProvider | None:
    if not settings.llm_enabled:
        return None
    key = settings.llm_api_key.get_secret_value() if settings.llm_api_key else None
    return OpenAICompatibleProvider(settings.llm_base_url, settings.llm_model, key,
                                    settings.llm_timeout_seconds)
