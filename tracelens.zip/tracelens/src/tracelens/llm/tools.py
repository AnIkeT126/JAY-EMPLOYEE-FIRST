"""The five read-only tools exposed to the LLM, with strict argument schemas.

Tools only read the indexed snapshot in PostgreSQL. They never touch the filesystem, never
accept a repository root, and every result is labelled as untrusted data.
"""

from __future__ import annotations

import json
import uuid
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from tracelens.analysis import dependency_graph as dg
from tracelens.config import Settings
from tracelens.errors import TraceLensError
from tracelens.models import IndexedFile
from tracelens.retrieval.citations import make_citation
from tracelens.retrieval.service import SearchService

MAX_RANGE_LINES = 200


class _Args(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SearchCodeArgs(_Args):
    query: str = Field(..., min_length=2, max_length=300)
    top_k: int = Field(5, ge=1, le=10)
    language: Literal["python", "java", "markdown"] | None = None


class FindSymbolArgs(_Args):
    name: str = Field(..., min_length=1, max_length=200)
    file: str | None = Field(None, max_length=500)


class GetSourceRangeArgs(_Args):
    path: str = Field(..., min_length=1, max_length=500)
    start_line: int = Field(..., ge=1)
    end_line: int = Field(..., ge=1)


class TraceDependenciesArgs(_Args):
    symbol: str = Field(..., min_length=1, max_length=200)
    direction: Literal["upstream", "downstream"] = "upstream"
    depth: int = Field(2, ge=1, le=5)


class FindRelatedTestsArgs(_Args):
    symbol: str = Field(..., min_length=1, max_length=200)


TOOL_MODELS: dict[str, tuple[type[_Args], str]] = {
    "search_code": (SearchCodeArgs, "Hybrid keyword+vector search over indexed code and docs."),
    "find_symbol": (FindSymbolArgs, "Find indexed symbols by exact qualified or simple name."),
    "get_source_range": (GetSourceRangeArgs,
                         f"Return indexed source lines (max {MAX_RANGE_LINES}) of a file."),
    "trace_dependencies": (TraceDependenciesArgs,
                           "List resolved static dependents (upstream) or dependencies (downstream)."),
    "find_related_tests": (FindRelatedTestsArgs,
                           "List tests that reach a symbol through resolved static edges."),
}


def tool_definitions() -> list[dict]:
    return [
        {"type": "function",
         "function": {"name": name, "description": desc,
                      "parameters": model.model_json_schema()}}
        for name, (model, desc) in TOOL_MODELS.items()
    ]


class ToolExecutor:
    def __init__(self, session: Session, settings: Settings, search: SearchService,
                 snapshot_id: uuid.UUID) -> None:
        self.session = session
        self.settings = settings
        self.search = search
        self.snapshot_id = snapshot_id
        self.known_citations: set[str] = set()
        self.calls = 0

    def run(self, name: str, raw_arguments: str) -> str:
        """Execute a tool call; always returns a JSON string, never raises."""
        self.calls += 1
        if name not in TOOL_MODELS:
            return self._wrap({"error": f"unknown tool '{name}'"})
        try:
            args = TOOL_MODELS[name][0].model_validate_json(raw_arguments or "{}")
            data = getattr(self, f"_{name}")(args)
        except ValidationError as exc:
            return self._wrap({"error": "invalid arguments", "details": exc.errors(
                include_url=False, include_context=False, include_input=False)})
        except TraceLensError as exc:
            return self._wrap({"error": exc.message})
        return self._wrap(data)

    def _wrap(self, data: object) -> str:
        text = json.dumps({"untrusted_content": True, "data": data}, default=str)
        limit = self.settings.llm_max_context_chars // 2
        if len(text) > limit:
            text = json.dumps({"untrusted_content": True, "truncated": True,
                               "data": text[: limit - 100]})
        return text

    # -- tools -----------------------------------------------------------------------------
    def _search_code(self, a: SearchCodeArgs) -> list[dict]:
        outcome = self.search.search(self.snapshot_id, a.query, top_k=a.top_k, language=a.language)
        out = []
        for h in outcome.hits:
            self.known_citations.add(h.citation.id)
            out.append({"citation": h.citation.id, "file": h.file_path, "symbol": h.symbol_name,
                        "snippet": h.content[:600]})
        return out

    def _find_symbol(self, a: FindSymbolArgs) -> list[dict]:
        found = dg.find_symbols(self.session, self.snapshot_id, symbol=a.name, file=a.file,
                                limit=20)
        out = []
        for s in found:
            cid = make_citation(self.snapshot_id, s.file_path, s.start_line, s.end_line).id
            self.known_citations.add(cid)
            out.append({"symbol": s.qualified_name, "kind": s.kind, "file": s.file_path,
                        "lines": [s.start_line, s.end_line], "citation": cid})
        return out

    def _get_source_range(self, a: GetSourceRangeArgs) -> dict:
        if a.end_line < a.start_line:
            return {"error": "end_line must be >= start_line"}
        if a.end_line - a.start_line + 1 > MAX_RANGE_LINES:
            return {"error": f"range exceeds {MAX_RANGE_LINES} lines"}
        row = self.session.execute(
            select(IndexedFile.content, IndexedFile.line_count).where(
                IndexedFile.snapshot_id == self.snapshot_id, IndexedFile.rel_path == a.path)
        ).first()
        if row is None:
            return {"error": "file is not part of the indexed snapshot"}
        content, line_count = row
        if a.start_line > line_count:
            return {"error": f"file has {line_count} lines"}
        end = min(a.end_line, line_count)
        cid = make_citation(self.snapshot_id, a.path, a.start_line, end).id
        self.known_citations.add(cid)
        lines = content.splitlines()[a.start_line - 1:end]
        return {"citation": cid, "source": "\n".join(lines)}

    def _trace_dependencies(self, a: TraceDependenciesArgs) -> list[dict]:
        targets = dg.resolve_target(self.session, self.snapshot_id, symbol=a.symbol, file=None)
        depth = min(a.depth, self.settings.max_trace_depth + 2)
        result = dg.trace(self.session, self.snapshot_id, [t.id for t in targets], a.direction,
                          depth, 100)
        out = []
        for st in result.steps[:50]:
            first = st.path[0]
            cid = make_citation(self.snapshot_id, first.file_path, first.line, first.line).id
            self.known_citations.add(cid)
            out.append({"symbol": st.symbol.qualified_name, "file": st.symbol.file_path,
                        "depth": st.depth, "edges": st.edge_types, "citation": cid})
        return out

    def _find_related_tests(self, a: FindRelatedTestsArgs) -> list[dict]:
        targets = dg.resolve_target(self.session, self.snapshot_id, symbol=a.symbol, file=None)
        result = dg.trace(self.session, self.snapshot_id, [t.id for t in targets], "upstream",
                          self.settings.max_trace_depth, 200)
        out = []
        for st in result.steps:
            if st.symbol.is_test and st.symbol.kind not in {"module", "file"}:
                edge = st.path[-1]
                cid = make_citation(self.snapshot_id, edge.file_path, edge.line, edge.line).id
                self.known_citations.add(cid)
                out.append({"test": st.symbol.qualified_name, "file": st.symbol.file_path,
                            "depth": st.depth, "citation": cid})
        return out[:50]
