"""Deterministic change-impact analysis: dependency traversal + hybrid retrieval evidence.

Evidence classes are kept strictly apart:
  * static edges (resolved from declarations/imports/types)  -> affected_components, related_tests
  * retrieval-only matches                                    -> semantic_candidates (low, unconfirmed)
  * documentation                                             -> related_documentation
  * ambiguous references                                      -> unresolved_relationships
"""

from __future__ import annotations

import logging
import time
import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from tracelens.analysis import dependency_graph as dg
from tracelens.config import Settings
from tracelens.llm.agent import ImpactNarrator
from tracelens.models import ImpactAnalysis, Symbol
from tracelens.retrieval.citations import Citation, make_citation, validate_citation
from tracelens.retrieval.embeddings import Embedder
from tracelens.retrieval.service import SearchService
from tracelens.schemas.impact import (
    AffectedComponent,
    CitationOut,
    Evidence,
    ImpactReport,
    ImpactRequest,
    RelatedDoc,
    RelatedTest,
    SemanticCandidate,
    TargetInfo,
    UnresolvedRelationship,
)
from tracelens.snapshots import require_active_snapshot

log = logging.getLogger(__name__)

LIMITATIONS = [
    "Static analysis only: reflection, dynamic dispatch, monkey-patching, dependency injection "
    "frameworks and string-based lookups are not followed.",
    "Calls on receivers whose type cannot be determined from declarations are listed as "
    "unresolved instead of being guessed.",
    "Overloaded Java methods are resolved by name and argument count only.",
    "Only Python, Java and Markdown files in the indexed snapshot are considered.",
    "Semantic candidates come from text similarity and are not confirmed dependencies.",
    "Traversal is bounded by max_depth and a node limit; deeper dependents are not reported.",
]


def classify(depth: int, edge_types: list[str]) -> tuple[str, str]:
    """Interpretable confidence rule (not a probability):

    high   - a resolved static edge links the component directly to the target
             (CALLS/EXTENDS/IMPLEMENTS/TESTS)
    medium - direct import only, or an indirect chain made of resolved non-import edges
    low    - an indirect chain that relies on an import edge
    """
    if depth == 1:
        if edge_types[0] == "IMPORTS":
            return "medium", "direct import; usage of the target is not proven by the import"
        return "high", f"direct resolved {edge_types[0]} edge to the target"
    if "IMPORTS" in edge_types:
        return "low", f"indirect chain of {depth} edges that includes an import-only link"
    return "medium", f"indirect chain of {depth} resolved edges ({' -> '.join(edge_types)})"


def _cite(c: Citation) -> CitationOut:
    return CitationOut(id=c.id, path=c.path, start_line=c.start_line, end_line=c.end_line,
                       snapshot_id=c.snapshot_id)


class ImpactAnalyzer:
    def __init__(self, session: Session, settings: Settings, embedder: Embedder | None,
                 narrator: ImpactNarrator | None = None) -> None:
        self.session = session
        self.settings = settings
        self.search = SearchService(session, settings, embedder)
        self.narrator = narrator

    # ------------------------------------------------------------------------------------
    def analyze(self, request: ImpactRequest) -> ImpactReport:
        started = time.perf_counter()
        s = self.settings
        repo, snapshot_id = require_active_snapshot(self.session, request.repository_id)
        max_depth = min(request.max_depth or s.max_trace_depth, 8)
        warnings: list[str] = []
        missing: list[str] = []

        targets = dg.resolve_target(self.session, snapshot_id, symbol=request.target_symbol,
                                    file=request.target_file)
        target_ids = self._expand_targets(snapshot_id, targets)
        target_set = set(target_ids)

        upstream = dg.trace(self.session, snapshot_id, target_ids, "upstream", max_depth,
                            s.trace_node_limit)
        if upstream.truncated:
            warnings.append(f"dependency traversal stopped at the node limit ({s.trace_node_limit})")
        steps = [st for st in upstream.steps if st.symbol.id not in target_set]
        steps = self._merge_steps(
            steps, self._inheritance_steps(snapshot_id, targets, max_depth, target_set))

        components, tests = self._partition(snapshot_id, steps)
        if not tests:
            missing.append("No tests reference the target through resolved static edges.")
        if not components and not tests:
            missing.append("No resolved static dependents were found for the target.")

        unresolved = self._unresolved(snapshot_id, targets, target_set)
        if any(u.direction == "possible_reference_to_target" for u in unresolved):
            missing.append("Some unresolved references may also depend on the target; verify manually.")

        semantic, docs, sem_warnings = self._retrieval(
            snapshot_id, request, targets, components, tests, target_set)
        warnings += sem_warnings
        if len(request.change_description.split()) < 4:
            missing.append("The change description is very short; semantic retrieval may be weak.")

        report = ImpactReport(
            analysis_id=uuid.uuid4(), repository_id=repo.id, repository_name=repo.name,
            snapshot_id=snapshot_id, target_file=request.target_file,
            target_symbol=request.target_symbol,
            resolved_targets=[self._target_info(snapshot_id, t) for t in targets
                              if t.kind not in {"module", "file"}] or
                             [self._target_info(snapshot_id, t) for t in targets[:1]],
            change_description=request.change_description, max_depth=max_depth,
            affected_components=components, related_tests=tests, semantic_candidates=semantic,
            related_documentation=docs, unresolved_relationships=unresolved,
            missing_information=missing, limitations=list(LIMITATIONS), warnings=warnings,
            duration_ms=0.0, created_at=datetime.now(UTC),
        )
        self._validate_citations(report)

        if request.use_llm:
            self._narrate(report)
        report.duration_ms = round((time.perf_counter() - started) * 1000, 2)
        self._persist(request, report)
        return report

    # ------------------------------------------------------------------------------------
    def _expand_targets(self, snapshot_id: uuid.UUID, targets: list[dg.SymbolInfo]) -> list[uuid.UUID]:
        """A class target includes its members; a file target already lists every symbol."""
        ids = {t.id for t in targets}
        frontier = {t.id for t in targets if t.kind in {"class", "interface", "enum"}}
        while frontier:
            children = set(self.session.execute(
                select(Symbol.id).where(Symbol.snapshot_id == snapshot_id,
                                        Symbol.parent_id.in_(frontier))).scalars().all())
            frontier = children - ids
            ids |= children
        return sorted(ids, key=str)

    @staticmethod
    def _merge_steps(first: list[dg.TraceStep], second: list[dg.TraceStep]) -> list[dg.TraceStep]:
        """One step per symbol, keeping the shortest path."""
        best: dict[uuid.UUID, dg.TraceStep] = {}
        for st in [*first, *second]:
            current = best.get(st.symbol.id)
            if current is None or st.depth < current.depth:
                best[st.symbol.id] = st
        return list(best.values())

    def _inheritance_steps(self, snapshot_id: uuid.UUID, targets: list[dg.SymbolInfo],
                           max_depth: int, target_set: set[uuid.UUID]) -> list[dg.TraceStep]:
        """Changing a method of a type can affect its subtypes/implementors and their users."""
        parent_ids: list[uuid.UUID] = []
        for t in targets:
            if t.kind in {"method", "function"}:
                parent = self.session.execute(
                    select(Symbol.parent_id).where(Symbol.id == t.id)).scalar()
                pinfo = dg.get_symbol(self.session, parent) if parent is not None else None
                if pinfo and pinfo.kind in {"class", "interface", "enum"}:
                    parent_ids.append(pinfo.id)
        if not parent_ids:
            return []
        limit = self.settings.trace_node_limit
        inherited = dg.trace(self.session, snapshot_id, parent_ids, "upstream", max_depth, limit,
                             edge_types=("EXTENDS", "IMPLEMENTS"))
        out: list[dg.TraceStep] = []
        for st in inherited.steps:
            if st.symbol.id in target_set:
                continue
            out.append(st)
            remaining = max_depth - st.depth
            if remaining < 1:
                continue
            members = self._expand_targets(snapshot_id, [st.symbol])
            for sub in dg.trace(self.session, snapshot_id, members, "upstream", remaining,
                                limit).steps:
                if sub.symbol.id in target_set or sub.symbol.id in set(members):
                    continue
                out.append(dg.TraceStep(sub.symbol, st.depth + sub.depth, st.path + sub.path))
        return out

    def _evidence(self, snapshot_id: uuid.UUID, step: dg.TraceStep) -> list[Evidence]:
        out: list[Evidence] = []
        for edge in step.path:
            out.append(Evidence(
                relationship=edge.edge_type,
                description=f"{edge.edge_type} edge at {edge.file_path}:{edge.line}",
                snippet=edge.evidence,
                citation=_cite(make_citation(snapshot_id, edge.file_path, edge.line, edge.line)),
                note=edge.note,
            ))
        return out

    def _partition(self, snapshot_id: uuid.UUID, steps: list[dg.TraceStep]
                   ) -> tuple[list[AffectedComponent], list[RelatedTest]]:
        components: list[AffectedComponent] = []
        tests: list[RelatedTest] = []
        steps = sorted(steps, key=lambda st: (st.depth, st.symbol.file_path, st.symbol.start_line))
        test_files_with_callables = {
            st.symbol.file_path for st in steps
            if st.symbol.is_test and st.symbol.kind not in {"module", "file"}
        }
        for st in steps:
            sym = st.symbol
            conf, reason = classify(st.depth, st.edge_types)
            kwargs: dict[str, Any] = dict(
                symbol=sym.qualified_name, name=sym.name, kind=sym.kind, file_path=sym.file_path,
                start_line=sym.start_line, end_line=sym.end_line,
                relationship=st.path[0].edge_type if st.path else "UNKNOWN", depth=st.depth,
                evidence_kind="direct_static" if st.depth == 1 else "indirect_static",
                confidence=conf, confidence_reason=reason,
                evidence=self._evidence(snapshot_id, st),
            )
            if sym.is_test:
                if sym.kind in {"module", "file"} and sym.file_path in test_files_with_callables:
                    continue  # the individual test functions already cover this file
                tests.append(RelatedTest(**kwargs))
            else:
                components.append(AffectedComponent(**kwargs))
        return components, tests

    def _unresolved(self, snapshot_id: uuid.UUID, targets: list[dg.SymbolInfo],
                    target_set: set[uuid.UUID]) -> list[UnresolvedRelationship]:
        hints = [t.name for t in targets if t.kind not in {"module", "file"}]
        edges = dg.unresolved_edges(self.session, snapshot_id, src_ids=list(target_set),
                                    name_hints=hints)
        out: list[UnresolvedRelationship] = []
        for e in edges:
            out.append(UnresolvedRelationship(
                direction="from_target" if e.src_id in target_set else "possible_reference_to_target",
                edge_type=e.edge_type, file_path=e.file_path, line=e.line,
                reference=e.dst_ref or "", reason=e.note or "unresolved",
                snippet=e.evidence,
                citation=_cite(make_citation(snapshot_id, e.file_path, e.line, e.line)),
            ))
        return out

    def _retrieval(self, snapshot_id: uuid.UUID, request: ImpactRequest,
                   targets: list[dg.SymbolInfo], components: list[AffectedComponent],
                   tests: list[RelatedTest], target_set: set[uuid.UUID]
                   ) -> tuple[list[SemanticCandidate], list[RelatedDoc], list[str]]:
        names = [t.name for t in targets if t.kind not in {"module", "file"}][:3] or \
                [targets[0].name]
        query = f"{request.change_description} {' '.join(names)}"[: self.settings.max_query_chars]
        outcome = self.search.search(snapshot_id, query, mode="hybrid",
                                     top_k=request.semantic_top_k * 2)
        known = {(c.file_path, c.name) for c in components} | {(t.file_path, t.name) for t in tests}
        target_ranges = [(t.file_path, t.start_line, t.end_line) for t in targets
                         if t.kind not in {"module", "file"}]
        semantic: list[SemanticCandidate] = []
        docs: dict[str, RelatedDoc] = {}

        def overlaps_target(path: str, a: int, b: int) -> bool:
            return any(p == path and a <= e and b >= s for p, s, e in target_ranges)

        for hit in outcome.hits:
            if hit.language == "markdown":
                docs[hit.citation.id] = RelatedDoc(
                    file_path=hit.file_path, heading=hit.symbol_name, match="semantic",
                    snippet=hit.content[:400], citation=_cite(hit.citation))
                continue
            if overlaps_target(hit.file_path, hit.start_line, hit.end_line):
                continue
            if (hit.file_path, hit.symbol_name) in known:
                continue  # already reported with static evidence
            if len(semantic) < request.semantic_top_k:
                semantic.append(SemanticCandidate(
                    file_path=hit.file_path, symbol_name=hit.symbol_name,
                    snippet=hit.content[:400], citation=_cite(hit.citation),
                    fusion_score=round(hit.fusion_score, 6), keyword_rank=hit.keyword_rank,
                    vector_rank=hit.vector_rank))
        # Documentation that literally mentions the target name (deterministic, keyword based).
        doc_hits = self.search.search(snapshot_id, " ".join(names), mode="keyword", top_k=20,
                                      language="markdown")
        for hit in doc_hits.hits:
            if any(n.lower() in hit.content.lower() for n in names):
                docs[hit.citation.id] = RelatedDoc(
                    file_path=hit.file_path, heading=hit.symbol_name, match="mentions_target",
                    snippet=hit.content[:400], citation=_cite(hit.citation))
        ordered = sorted(docs.values(), key=lambda d: (d.match != "mentions_target", d.file_path,
                                                       d.citation.start_line))
        return semantic, ordered[:10], list(outcome.warnings)

    def _target_info(self, snapshot_id: uuid.UUID, t: dg.SymbolInfo) -> TargetInfo:
        return TargetInfo(symbol=t.qualified_name, kind=t.kind, file_path=t.file_path,
                          citation=_cite(make_citation(snapshot_id, t.file_path, t.start_line,
                                                       t.end_line)))

    def _validate_citations(self, report: ImpactReport) -> None:
        """Every citation must resolve to indexed source; invalid evidence is dropped, loudly."""
        sid = report.snapshot_id

        def ok(cid: str) -> bool:
            return validate_citation(self.session, sid, cid)

        for comp in [*report.affected_components, *report.related_tests]:
            bad = [e for e in comp.evidence if not ok(e.citation.id)]
            if bad:
                report.warnings.append(f"dropped {len(bad)} invalid citation(s) for {comp.symbol}")
                comp.evidence = [e for e in comp.evidence if e not in bad]
        for coll_name in ("semantic_candidates", "related_documentation",
                          "unresolved_relationships"):
            items = getattr(report, coll_name)
            valid = [i for i in items if ok(i.citation.id)]
            if len(valid) != len(items):
                report.warnings.append(f"dropped {len(items) - len(valid)} invalid {coll_name}")
                setattr(report, coll_name, valid)

    def _narrate(self, report: ImpactReport) -> None:
        if self.narrator is None:
            report.warnings.append(
                "LLM narration requested but no provider is configured "
                "(TRACELENS_LLM_PROVIDER=none); deterministic report returned")
            return
        try:
            narration = self.narrator.narrate(report, report.snapshot_id)
        except Exception as exc:  # provider/network/validation errors must never fail analysis
            log.warning("LLM narration failed: %s", type(exc).__name__)
            report.warnings.append(
                f"LLM narration failed ({type(exc).__name__}); deterministic report returned")
            return
        report.llm_summary = narration.summary
        report.llm_notes = narration.notes
        report.generated_by = "llm+deterministic"

    def _persist(self, request: ImpactRequest, report: ImpactReport) -> None:
        self.session.add(ImpactAnalysis(
            id=report.analysis_id, repository_id=report.repository_id,
            snapshot_id=report.snapshot_id, request=request.model_dump(mode="json"),
            report=report.model_dump(mode="json"), generated_by=report.generated_by,
            duration_ms=report.duration_ms))
        self.session.flush()
