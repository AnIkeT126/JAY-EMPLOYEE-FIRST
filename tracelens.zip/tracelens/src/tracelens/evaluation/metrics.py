"""Deterministic retrieval and impact metrics.

Edge cases (also documented in docs/EVALUATION.md):
  * recall@k with no relevant labels is undefined for retrieval cases; such cases are rejected
    by the dataset loader, so every retrieval case has >= 1 relevant label.
  * nDCG@k uses gains 2^grade - 1 and log2(rank + 1) discounts; ideal DCG of 0 yields 0.0.
  * reciprocal rank is 0.0 when no relevant item is retrieved.
  * set precision/recall: empty prediction with empty expectation -> 1.0 / 1.0; empty
    prediction with non-empty expectation -> precision 1.0 (nothing wrong was claimed) and
    recall 0.0; non-empty prediction with empty expectation -> precision 0.0, recall 1.0.
"""

from __future__ import annotations

import math
from collections.abc import Sequence


def recall_at_k(gains: Sequence[float], n_relevant: int, k: int) -> float:
    """``gains``: gain per ranked result (0 = not relevant, each label counted at most once)."""
    if n_relevant <= 0:
        raise ValueError("recall requires at least one relevant label")
    return sum(1 for g in gains[:k] if g > 0) / n_relevant


def reciprocal_rank(gains: Sequence[float]) -> float:
    for rank, gain in enumerate(gains, start=1):
        if gain > 0:
            return 1.0 / rank
    return 0.0


def dcg(grades: Sequence[float], k: int) -> float:
    return sum((2 ** g - 1) / math.log2(i + 1) for i, g in enumerate(grades[:k], start=1))


def ndcg_at_k(gains: Sequence[float], label_grades: Sequence[float], k: int) -> float:
    ideal = dcg(sorted(label_grades, reverse=True), k)
    return 0.0 if ideal == 0 else dcg(gains, k) / ideal


def set_precision_recall(predicted: set, expected: set) -> tuple[float, float]:
    hit = len(predicted & expected)
    precision = hit / len(predicted) if predicted else 1.0
    recall = hit / len(expected) if expected else 1.0
    return precision, recall


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0
