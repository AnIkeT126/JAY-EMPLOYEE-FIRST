"""Run the labelled benchmark against an indexed repository and write JSON + Markdown reports.

Nothing here hard-codes expected scores: every number is computed from the dataset labels and
the live results. Modes that cannot run (e.g. vector search without pgvector/model) are
reported as skipped with the reason instead of being scored.
"""

from __future__ import annotations

import hashlib
import json
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import cast

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from tracelens.config import Settings
from tracelens.errors import TraceLensError
from tracelens.evaluation import metrics as m
from tracelens.impact.analyzer import ImpactAnalyzer
from tracelens.models import Repository
from tracelens.retrieval.citations import validate_citation
from tracelens.retrieval.embeddings import Embedder
from tracelens.retrieval.service import SearchHit, SearchMode, SearchService
from tracelens.schemas.impact import ImpactRequest
from tracelens.snapshots import require_active_snapshot

RETRIEVAL_MODES: tuple[SearchMode, ...] = ("keyword", "vector", "hybrid")
# deps_only (static graph traversal alone) is an extra baseline beyond the four required modes.
IMPACT_MODES = ("keyword", "vector", "hybrid", "deps_only", "hybrid+deps")
SCORED_KINDS_EXCLUDED = {"module", "file"}


def load_dataset(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    ids = [c["id"] for c in data["retrieval_cases"] + data["impact_cases"]]
    if len(ids) != len(set(ids)):
        raise ValueError("dataset case ids must be unique")
    for case in data["retrieval_cases"]:
        if not case["relevant"]:
            raise ValueError(f"retrieval case {case['id']} has no relevant labels")
    data["_digest"] = hashlib.sha256(path.read_bytes()).hexdigest()
    return data


def _gains(hits: list[SearchHit], labels: list[dict]) -> list[float]:
    """Gain per ranked hit; every label can be credited by at most one hit."""
    used: set[int] = set()
    gains: list[float] = []
    for hit in hits:
        gain = 0.0
        for i, label in enumerate(labels):
            if i in used or label["path"] != hit.file_path:
                continue
            if label.get("symbol") in (None, hit.symbol_name):
                used.add(i)
                gain = float(label["grade"])
                break
        gains.append(gain)
    return gains


def _skip_reason(exc: Exception) -> str:
    return f"{type(exc).__name__}: {getattr(exc, 'message', str(exc))}"[:300]


def run_evaluation(factory: sessionmaker, settings: Settings, embedder: Embedder | None,
                   dataset_path: Path, k: int = 10) -> dict:
    data = load_dataset(dataset_path)
    with factory() as session:
        repo = session.execute(
            select(Repository).where(Repository.name == data["repository"]["name"])
        ).scalar_one_or_none()
        if repo is None:
            raise TraceLensError(
                f"repository '{data['repository']['name']}' is not indexed; run `tracelens index`")
        _, snapshot_id = require_active_snapshot(session, repo.id)
        search = SearchService(session, settings, embedder)
        retrieval = _run_retrieval(session, search, snapshot_id, data["retrieval_cases"], k)
        impact = _run_impact(session, settings, embedder, search, repo.id, snapshot_id,
                             data["impact_cases"], k)
        session.rollback()  # evaluation must not persist analyses
    return {
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "dataset": {"path": dataset_path.name, "sha256": data["_digest"],
                    "retrieval_cases": len(data["retrieval_cases"]),
                    "impact_cases": len(data["impact_cases"])},
        "config": {"k": k, "rrf_k": settings.rrf_k,
                   "embedding_model": settings.embedding_model if embedder else None,
                   "embedding_dim": settings.embedding_dim if embedder else None,
                   "snapshot_id": str(snapshot_id)},
        "retrieval": retrieval,
        "impact": impact,
    }


def _run_retrieval(session: Session, search: SearchService, snapshot_id: uuid.UUID,
                   cases: list[dict], k: int) -> dict:
    out: dict = {}
    for mode in RETRIEVAL_MODES:
        rows = []
        try:
            for case in cases:
                t0 = time.perf_counter()
                outcome = search.search(snapshot_id, case["query"], mode=mode, top_k=k)
                latency = (time.perf_counter() - t0) * 1000
                if outcome.mode_used != mode:
                    raise TraceLensError("; ".join(outcome.warnings) or "mode degraded")
                labels = case["relevant"]
                gains = _gains(outcome.hits, labels)
                valid = [validate_citation(session, snapshot_id, h.citation.id)
                         for h in outcome.hits]
                rows.append({
                    "id": case["id"],
                    "recall": m.recall_at_k(gains, len(labels), k),
                    "mrr": m.reciprocal_rank(gains),
                    "ndcg": m.ndcg_at_k(gains, [lb["grade"] for lb in labels], k),
                    "citation_validity": m.mean([1.0 if v else 0.0 for v in valid]) if valid else 1.0,
                    "latency_ms": latency,
                })
        except TraceLensError as exc:
            out[mode] = {"status": "skipped", "reason": _skip_reason(exc)}
            continue
        out[mode] = {
            "status": "measured",
            f"recall@{k}": m.mean([r["recall"] for r in rows]),
            "mrr": m.mean([r["mrr"] for r in rows]),
            f"ndcg@{k}": m.mean([r["ndcg"] for r in rows]),
            "citation_validity": m.mean([r["citation_validity"] for r in rows]),
            "latency_ms_mean": m.mean([r["latency_ms"] for r in rows]),
            "per_case": rows,
        }
    return out


def _case_files(items: list[dict]) -> set[str]:
    return {i["path"] for i in items}


def _run_impact(session: Session, settings: Settings, embedder: Embedder | None,
                search: SearchService, repo_id: uuid.UUID, snapshot_id: uuid.UUID,
                cases: list[dict], k: int) -> dict:
    per_mode: dict[str, list[dict]] = {mode: [] for mode in IMPACT_MODES}
    skipped: dict[str, str] = {}
    symbol_rows: list[dict] = []
    unresolved_rows: list[float] = []
    analyzer = ImpactAnalyzer(session, settings, embedder, narrator=None)

    for case in cases:
        request = ImpactRequest(
            repository_id=repo_id, target_file=case.get("target_file"),
            target_symbol=case.get("target_symbol"),
            change_description=case["change_description"], max_depth=case.get("max_depth"))
        t0 = time.perf_counter()
        report = analyzer.analyze(request)
        deps_latency = (time.perf_counter() - t0) * 1000
        target_files = {t.file_path for t in report.resolved_targets}
        expected_files = _case_files(case["expected_affected"] + case["expected_tests"])
        query = f"{case['change_description']} {case.get('target_symbol') or ''}".strip()

        def hit_files(mode: SearchMode, _query: str = query, _targets: set[str] = target_files) -> set[str]:
            outcome = search.search(snapshot_id, _query, mode=mode, top_k=k)
            if outcome.mode_used != mode:
                raise TraceLensError("; ".join(outcome.warnings) or "mode degraded")
            return {h.file_path for h in outcome.hits} - _targets

        graph_files = ({c.file_path for c in report.affected_components}
                       | {t.file_path for t in report.related_tests}) - target_files
        for mode in IMPACT_MODES:
            if mode in skipped:
                continue
            t1 = time.perf_counter()
            try:
                if mode == "deps_only":
                    predicted = set(graph_files)
                    latency = deps_latency
                elif mode == "hybrid+deps":
                    predicted = hit_files("hybrid") | graph_files
                    latency = deps_latency + (time.perf_counter() - t1) * 1000
                else:
                    predicted = hit_files(cast(SearchMode, mode))
                    latency = (time.perf_counter() - t1) * 1000
            except TraceLensError as exc:
                skipped[mode] = _skip_reason(exc)
                per_mode[mode] = []
                continue
            precision, recall = m.set_precision_recall(predicted, expected_files)
            per_mode[mode].append({"id": case["id"], "precision": precision, "recall": recall,
                                   "latency_ms": latency})

        scored = lambda c: c.kind not in SCORED_KINDS_EXCLUDED  # noqa: E731
        pred_sym = {(c.file_path, c.name) for c in report.affected_components if scored(c)} | \
                   {(t.file_path, t.name) for t in report.related_tests if scored(t)}
        exp_sym = {(i["path"], i["symbol"]) for i in case["expected_affected"] + case["expected_tests"]}
        p, r = m.set_precision_recall(pred_sym, exp_sym)
        symbol_rows.append({"id": case["id"], "precision": p, "recall": r,
                            "predicted": sorted(map(list, pred_sym)),
                            "expected": sorted(map(list, exp_sym))})
        wanted = case.get("expected_unresolved", [])
        if wanted:
            refs = [u.reference for u in report.unresolved_relationships]
            unresolved_rows.append(
                sum(1 for w in wanted if any(w in ref for ref in refs)) / len(wanted))
        all_cites = [e.citation.id for c in [*report.affected_components, *report.related_tests]
                     for e in c.evidence]
        symbol_rows[-1]["citation_validity"] = m.mean(
            [1.0 if validate_citation(session, snapshot_id, c) else 0.0 for c in all_cites]) \
            if all_cites else 1.0

    modes: dict = {}
    for mode in IMPACT_MODES:
        if mode in skipped:
            modes[mode] = {"status": "skipped", "reason": skipped[mode]}
            continue
        rows = per_mode[mode]
        modes[mode] = {
            "status": "measured", "level": "file",
            "precision": m.mean([r["precision"] for r in rows]),
            "recall": m.mean([r["recall"] for r in rows]),
            "latency_ms_mean": m.mean([r["latency_ms"] for r in rows]),
            "per_case": rows,
        }
    return {
        "modes": modes,
        "static_analysis_symbol_level": {
            "precision": m.mean([r["precision"] for r in symbol_rows]),
            "recall": m.mean([r["recall"] for r in symbol_rows]),
            "citation_validity": m.mean([r["citation_validity"] for r in symbol_rows]),
            "unresolved_reference_recall": m.mean(unresolved_rows) if unresolved_rows else None,
            "per_case": symbol_rows,
        },
    }


def render_markdown(result: dict) -> str:
    k = result["config"]["k"]
    lines = [
        "# TraceLens evaluation report", "",
        f"Generated: {result['generated_at']}  ",
        f"Dataset: `{result['dataset']['path']}` (sha256 `{result['dataset']['sha256'][:12]}`), "
        f"{result['dataset']['retrieval_cases']} retrieval + "
        f"{result['dataset']['impact_cases']} impact cases  ",
        f"Snapshot: `{result['config']['snapshot_id']}`  ",
        f"Embedding model: `{result['config']['embedding_model']}`  ", "",
        f"## Retrieval (K={k})", "",
        f"| Mode | Recall@{k} | MRR | nDCG@{k} | Citation validity | Mean latency (ms) |",
        "|---|---|---|---|---|---|",
    ]
    for mode, r in result["retrieval"].items():
        if r["status"] != "measured":
            lines.append(f"| {mode} | skipped | | | | |")
            continue
        lines.append(f"| {mode} | {r[f'recall@{k}']:.3f} | {r['mrr']:.3f} | {r[f'ndcg@{k}']:.3f} "
                     f"| {r['citation_validity']:.3f} | {r['latency_ms_mean']:.1f} |")
    for mode, r in result["retrieval"].items():
        if r["status"] != "measured":
            lines += ["", f"- `{mode}` skipped: {r['reason']}"]
    lines += ["", "## Impact analysis (file-level precision/recall)", "",
              "| Mode | Precision | Recall | Mean latency (ms) |", "|---|---|---|---|"]
    for mode, r in result["impact"]["modes"].items():
        if r["status"] != "measured":
            lines.append(f"| {mode} | skipped | | |")
            continue
        lines.append(f"| {mode} | {r['precision']:.3f} | {r['recall']:.3f} "
                     f"| {r['latency_ms_mean']:.1f} |")
    for mode, r in result["impact"]["modes"].items():
        if r["status"] != "measured":
            lines += ["", f"- `{mode}` skipped: {r['reason']}"]
    s = result["impact"]["static_analysis_symbol_level"]
    recall = s["unresolved_reference_recall"]
    unresolved = "n/a" if recall is None else f"{recall:.3f}"
    lines += ["", "## Static analysis + retrieval report (symbol-level)", "",
              f"- Precision: {s['precision']:.3f}", f"- Recall: {s['recall']:.3f}",
              f"- Citation validity: {s['citation_validity']:.3f}",
              f"- Unresolved-reference recall: {unresolved}", "",
              "Per-case predictions and expectations are in the JSON report.", ""]
    return "\n".join(lines)


def write_reports(result: dict, output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "evaluation.json"
    md_path = output_dir / "evaluation.md"
    json_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    md_path.write_text(render_markdown(result), encoding="utf-8")
    return json_path, md_path
