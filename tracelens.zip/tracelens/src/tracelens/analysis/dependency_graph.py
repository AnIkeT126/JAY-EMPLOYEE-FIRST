"""Bounded dependency traversal over persisted, resolved edges of one snapshot."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Literal

from sqlalchemy import select
from sqlalchemy.orm import Session

from tracelens.errors import AmbiguousTargetError, NotFoundError
from tracelens.models import EDGE_RESOLVED, Edge, IndexedFile, Symbol

IMPACT_EDGE_TYPES = ("CALLS", "IMPORTS", "EXTENDS", "IMPLEMENTS", "TESTS")
Direction = Literal["upstream", "downstream"]


@dataclass(frozen=True)
class SymbolInfo:
    id: uuid.UUID
    qualified_name: str
    name: str
    kind: str
    file_path: str
    start_line: int
    end_line: int
    is_test: bool
    language: str
    signature: str | None


@dataclass(frozen=True)
class EdgeInfo:
    edge_type: str
    src_id: uuid.UUID
    dst_id: uuid.UUID | None
    file_path: str
    line: int
    evidence: str
    note: str | None
    status: str = EDGE_RESOLVED
    dst_ref: str | None = None


@dataclass
class TraceStep:
    symbol: SymbolInfo
    depth: int
    path: list[EdgeInfo]  # edges from the start set to this symbol (nearest first)

    @property
    def edge_types(self) -> list[str]:
        return [e.edge_type for e in self.path]


@dataclass
class TraceResult:
    steps: list[TraceStep] = field(default_factory=list)
    truncated: bool = False


def _symbol_infos(session: Session, ids: list[uuid.UUID]) -> dict[uuid.UUID, SymbolInfo]:
    if not ids:
        return {}
    rows = session.execute(
        select(Symbol, IndexedFile.rel_path)
        .join(IndexedFile, IndexedFile.id == Symbol.file_id)
        .where(Symbol.id.in_(ids))
    ).all()
    return {
        s.id: SymbolInfo(s.id, s.qualified_name, s.name, s.kind, path, s.start_line, s.end_line,
                         bool(s.is_test), s.language, s.signature)
        for s, path in rows
    }


def get_symbol(session: Session, symbol_id: uuid.UUID) -> SymbolInfo | None:
    return _symbol_infos(session, [symbol_id]).get(symbol_id)


def find_symbols(session: Session, snapshot_id: uuid.UUID, *, symbol: str | None = None,
                 file: str | None = None, limit: int = 50) -> list[SymbolInfo]:
    """Find symbols by exact qualified name, else exact simple name; optionally within a file."""
    stmt = (
        select(Symbol.id)
        .join(IndexedFile, IndexedFile.id == Symbol.file_id)
        .where(Symbol.snapshot_id == snapshot_id)
    )
    if file:
        stmt = stmt.where(IndexedFile.rel_path == file)
    if symbol:
        exact = session.execute(stmt.where(Symbol.qualified_name == symbol)).scalars().all()
        ids = exact or session.execute(stmt.where(Symbol.name == symbol)).scalars().all()
    else:
        ids = session.execute(stmt).scalars().all()
    found = sorted(_symbol_infos(session, list(ids)[:limit]).values(),
                   key=lambda i: (i.file_path, i.start_line, i.qualified_name))
    if symbol:
        # A class and its constructor, or a module and a same-named function, are one target.
        concrete = [i for i in found if i.kind not in {"module", "file", "constructor"}]
        if concrete:
            return concrete
    return found


def resolve_target(session: Session, snapshot_id: uuid.UUID, *, symbol: str | None,
                   file: str | None) -> list[SymbolInfo]:
    """Resolve a user-supplied target to indexed symbols; raise if absent or ambiguous."""
    if not symbol and not file:
        raise NotFoundError("provide target_symbol and/or target_file")
    matches = find_symbols(session, snapshot_id, symbol=symbol, file=file)
    if not matches:
        raise NotFoundError(
            "target not found in the active snapshot "
            f"(symbol={symbol!r}, file={file!r}); check the name and the repository status"
        )
    if symbol and len({m.id for m in matches}) > 1:
        # Overloads in the same file/class are fine; different declaring files are ambiguous.
        files = {m.file_path for m in matches}
        qnames = {m.qualified_name for m in matches}
        if len(files) > 1 or len(qnames) > 1:
            listing = ", ".join(sorted(f"{m.qualified_name} ({m.file_path})" for m in matches)[:8])
            raise AmbiguousTargetError(
                f"target_symbol matches several symbols: {listing}. Use a qualified name "
                "and/or target_file."
            )
    return matches


def _edge_info(edge: Edge, path: str) -> EdgeInfo:
    return EdgeInfo(edge.edge_type, edge.src_symbol_id, edge.dst_symbol_id, path, edge.line,
                    edge.evidence, edge.note, edge.status, edge.dst_ref)


def trace(session: Session, snapshot_id: uuid.UUID, start_ids: list[uuid.UUID],
          direction: Direction, max_depth: int, node_limit: int = 500,
          edge_types: tuple[str, ...] = IMPACT_EDGE_TYPES) -> TraceResult:
    """Breadth-first traversal over RESOLVED edges only (``path`` runs from the start set outward).

    ``upstream`` follows edges backwards (who depends on the start symbols: the impact set);
    ``downstream`` follows them forwards (what the start symbols depend on).
    """
    result = TraceResult()
    visited: set[uuid.UUID] = set(start_ids)
    frontier: dict[uuid.UUID, list[EdgeInfo]] = {sid: [] for sid in start_ids}
    near, far = (Edge.dst_symbol_id, Edge.src_symbol_id) if direction == "upstream" else (
        Edge.src_symbol_id, Edge.dst_symbol_id)
    for depth in range(1, max_depth + 1):
        if not frontier:
            break
        rows = session.execute(
            select(Edge, IndexedFile.rel_path)
            .join(IndexedFile, IndexedFile.id == Edge.file_id)
            .where(Edge.snapshot_id == snapshot_id, Edge.status == EDGE_RESOLVED,
                   Edge.edge_type.in_(edge_types), near.in_(list(frontier)))
            .order_by(Edge.file_id, Edge.line, Edge.id)
        ).all()
        next_frontier: dict[uuid.UUID, list[EdgeInfo]] = {}
        for edge, path in rows:
            near_id = edge.dst_symbol_id if direction == "upstream" else edge.src_symbol_id
            far_id = edge.src_symbol_id if direction == "upstream" else edge.dst_symbol_id
            if far_id in visited:
                continue
            if len(visited) - len(start_ids) >= node_limit:
                result.truncated = True
                break
            visited.add(far_id)
            next_frontier[far_id] = [*frontier[near_id], _edge_info(edge, path)]
        infos = _symbol_infos(session, list(next_frontier))
        for sid, edge_path in next_frontier.items():
            if sid in infos:
                result.steps.append(TraceStep(infos[sid], depth, edge_path))
        frontier = next_frontier
        if result.truncated:
            break
    return result


def unresolved_edges(session: Session, snapshot_id: uuid.UUID, *, src_ids: list[uuid.UUID],
                     name_hints: list[str]) -> list[EdgeInfo]:
    """UNRESOLVED edges leaving the given symbols, or whose reference ends in a hinted name."""
    rows = session.execute(
        select(Edge, IndexedFile.rel_path)
        .join(IndexedFile, IndexedFile.id == Edge.file_id)
        .where(Edge.snapshot_id == snapshot_id, Edge.status == "UNRESOLVED")
        .order_by(IndexedFile.rel_path, Edge.line)
    ).all()
    hints = {h for h in name_hints if h}
    ids = set(src_ids)
    out = []
    for edge, path in rows:
        tail = (edge.dst_ref or "").split(".")[-1]
        if edge.src_symbol_id in ids or tail in hints:
            out.append(_edge_info(edge, path))
    return out
