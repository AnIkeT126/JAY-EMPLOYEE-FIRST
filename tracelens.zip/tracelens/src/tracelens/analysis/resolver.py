"""Resolve raw references into dependency edges.

Policy: an edge is only RESOLVED when the target is identified from declarations, imports or
explicit type information. References that look internal (a symbol with that name exists in
the repository) but cannot be pinned down become UNRESOLVED edges that carry the reason,
instead of guessed edges. References to external libraries/builtins are not recorded.
"""

from __future__ import annotations

import uuid
from collections import defaultdict
from dataclasses import dataclass

from tracelens.analysis.java_parser import JAVA_DYNAMIC_CALLS
from tracelens.analysis.python_parser import DYNAMIC_CALLS
from tracelens.analysis.types import ParsedFile, ParsedSymbol, RawRef

CLASS_KINDS = {"class", "interface", "enum"}
CALLABLE_KINDS = {"function", "method", "constructor"}
MAX_CANDIDATES_SHOWN = 5


@dataclass
class EdgeRecord:
    edge_type: str
    status: str  # RESOLVED | UNRESOLVED
    src_id: uuid.UUID
    dst_id: uuid.UUID | None
    dst_ref: str | None
    rel_path: str
    line: int
    evidence: str
    note: str | None = None


class _Index:
    def __init__(self, files: list[ParsedFile]) -> None:
        self.files = files
        self.by_qname: dict[str, list[ParsedSymbol]] = defaultdict(list)
        self.sym_file: dict[uuid.UUID, ParsedFile] = {}
        self.children: dict[str, list[ParsedSymbol]] = defaultdict(list)
        self.callables_by_name: dict[str, list[ParsedSymbol]] = defaultdict(list)
        self.py_modules: dict[str, ParsedSymbol] = {}
        self.java_types_by_simple: dict[str, list[ParsedSymbol]] = defaultdict(list)
        self.file_syms: dict[str, dict[str, ParsedSymbol]] = {}
        self.file_syms_exact: dict[str, dict[tuple[str, int], ParsedSymbol]] = {}
        self.py_imports: dict[str, tuple[dict[str, str], dict[str, str]]] = {}
        self.java_imports: dict[str, tuple[dict[str, str], list[str]]] = {}
        # class qname -> resolved base class symbols (EXTENDS / IMPLEMENTS)
        self.bases: dict[str, list[ParsedSymbol]] = defaultdict(list)
        self.subtypes: dict[str, list[ParsedSymbol]] = defaultdict(list)
        for pf in files:
            local: dict[str, ParsedSymbol] = {}
            exact: dict[tuple[str, int], ParsedSymbol] = {}
            for sym in pf.symbols:
                self.by_qname[sym.qualified_name].append(sym)
                self.sym_file[sym.id] = pf
                local[sym.qualified_name] = sym
                exact[(sym.qualified_name, sym.start_line)] = sym
                if sym.parent_qname:
                    self.children[sym.parent_qname].append(sym)
                if sym.kind in CALLABLE_KINDS:
                    self.callables_by_name[sym.name].append(sym)
                if sym.kind == "module":
                    self.py_modules[sym.qualified_name] = sym
                if pf.language == "java" and sym.kind in CLASS_KINDS:
                    self.java_types_by_simple[sym.name].append(sym)
            self.file_syms[pf.rel_path] = local
            self.file_syms_exact[pf.rel_path] = exact

    def src_of(self, pf: ParsedFile, ref: RawRef) -> ParsedSymbol | None:
        """The symbol containing a reference (overloads are told apart by start line)."""
        exact = self.file_syms_exact[pf.rel_path].get((ref.src_qname, ref.src_start_line))
        return exact or self.file_syms[pf.rel_path].get(ref.src_qname)

    # -- generic lookups -------------------------------------------------------------------
    def one(self, qname: str) -> ParsedSymbol | None:
        found = self.by_qname.get(qname, [])
        return found[0] if len(found) == 1 else None

    def class_of(self, sym: ParsedSymbol) -> ParsedSymbol | None:
        current: ParsedSymbol | None = sym
        while current is not None:
            if current.kind in CLASS_KINDS:
                return current
            current = self.one(current.parent_qname) if current.parent_qname else None
        return None

    def module_for(self, dotted: str) -> ParsedSymbol | None:
        if dotted in self.py_modules:
            return self.py_modules[dotted]
        matches = [m for q, m in self.py_modules.items() if q.endswith("." + dotted)]
        return matches[0] if len(matches) == 1 else None

    def mro(self, cls: ParsedSymbol) -> list[ParsedSymbol]:
        order: list[ParsedSymbol] = []
        queue = [cls]
        while queue:
            current = queue.pop(0)
            if current in order:
                continue
            order.append(current)
            queue.extend(self.bases.get(current.qualified_name, []))
        return order

    def candidates_note(self, name: str, exclude: set[uuid.UUID] | None = None) -> str | None:
        cands = [c for c in self.callables_by_name.get(name, [])]
        if not cands:
            return None
        shown = ", ".join(c.qualified_name for c in cands[:MAX_CANDIDATES_SHOWN])
        more = "" if len(cands) <= MAX_CANDIDATES_SHOWN else f" (+{len(cands) - 5} more)"
        return f"{len(cands)} candidate(s): {shown}{more}"


# ------------------------------------------------------------------------------------------
# Python
# ------------------------------------------------------------------------------------------
def _py_package_parts(pf: ParsedFile) -> list[str]:
    parts = pf.module_qname.split(".") if pf.module_qname else []
    return parts if pf.rel_path.endswith("__init__.py") else parts[:-1]


def _build_py_imports(idx: _Index, pf: ParsedFile, edges: list[EdgeRecord]) -> None:
    modules: dict[str, str] = {}  # bound name -> module qname in repo
    symbols: dict[str, str] = {}  # bound name -> symbol qname in repo
    src_mod = idx.file_syms[pf.rel_path].get(pf.module_qname or pf.rel_path)
    for ref in pf.refs:
        if ref.kind != "IMPORT" or src_mod is None:
            continue
        aliases = dict(p.split("=") for p in ref.alias.split(",")) if ref.alias and ref.names else {}
        if not ref.names:  # import a.b [as c]
            mod = idx.module_for(ref.target)
            if mod is None:
                continue
            modules[ref.alias or ref.target] = mod.qualified_name
            edges.append(_edge("IMPORTS", src_mod, mod, pf, ref))
            continue
        base_target = ref.target
        if ref.level:
            base = _py_package_parts(pf)
            base = base[: len(base) - (ref.level - 1)] if ref.level > 1 else base
            base_target = ".".join(base + ([ref.target] if ref.target else []))
        base_mod = idx.module_for(base_target) if base_target else None
        for name in ref.names:
            bound = aliases.get(name, name)
            sub = idx.module_for(f"{base_target}.{name}" if base_target else name)
            if sub is not None:
                modules[bound] = sub.qualified_name
                edges.append(_edge("IMPORTS", src_mod, sub, pf, ref))
                continue
            if base_mod is None:
                continue  # external package
            sym = idx.one(f"{base_mod.qualified_name}.{name}")
            if sym is not None:
                symbols[bound] = sym.qualified_name
                edges.append(_edge("IMPORTS", src_mod, sym, pf, ref))
            else:
                edges.append(_unresolved("IMPORTS", src_mod, f"{base_target}.{name}", pf, ref,
                                         "imported name not found in indexed module"))
    idx.py_imports[pf.rel_path] = (modules, symbols)


def _edge(edge_type: str, src: ParsedSymbol, dst: ParsedSymbol, pf: ParsedFile, ref: RawRef,
          note: str | None = None) -> EdgeRecord:
    return EdgeRecord(edge_type, "RESOLVED", src.id, dst.id, None, pf.rel_path, ref.line,
                      ref.evidence, note)


def _unresolved(edge_type: str, src: ParsedSymbol, target: str, pf: ParsedFile, ref: RawRef,
                note: str) -> EdgeRecord:
    return EdgeRecord(edge_type, "UNRESOLVED", src.id, None, target, pf.rel_path, ref.line,
                      ref.evidence, note)


def _py_member(idx: _Index, owner: ParsedSymbol, name: str) -> ParsedSymbol | None:
    """Find ``name`` on a class (and its resolved bases) or inside a module."""
    if owner.kind == "module":
        return idx.one(f"{owner.qualified_name}.{name}")
    if owner.kind in CLASS_KINDS:
        for cls in idx.mro(owner):
            found = idx.one(f"{cls.qualified_name}.{name}")
            if found is not None:
                return found
    return None


def _py_chain(idx: _Index, pf: ParsedFile, parts: list[str]) -> ParsedSymbol | None:
    modules, symbols = idx.py_imports[pf.rel_path]
    current: ParsedSymbol | None = None
    rest: list[str] = []
    for i in range(len(parts), 0, -1):  # longest bound prefix wins (import a.b.c)
        key = ".".join(parts[:i])
        if key in modules:
            current, rest = idx.py_modules.get(modules[key]), parts[i:]
            break
        if key in symbols:
            current, rest = idx.one(symbols[key]), parts[i:]
            break
    else:
        local = idx.one(f"{pf.module_qname}.{parts[0]}")
        if local is not None:
            current, rest = local, parts[1:]
    for part in rest:
        if current is None:
            return None
        current = _py_member(idx, current, part)
    return current


def _py_constructor_target(idx: _Index, cls: ParsedSymbol) -> ParsedSymbol:
    return idx.one(f"{cls.qualified_name}.__init__") or cls


def _resolve_python(idx: _Index, pf: ParsedFile, edges: list[EdgeRecord], phase: str) -> None:
    for ref in pf.refs:
        if ref.kind == "IMPORT" or (ref.kind == "CALL") != (phase == "calls"):
            continue
        src = idx.src_of(pf, ref)
        if src is None:
            continue
        if ref.kind == "EXTENDS":
            base = _py_chain(idx, pf, ref.target.split("."))
            if base is not None and base.kind in CLASS_KINDS:
                idx.bases[src.qualified_name].append(base)
                idx.subtypes[base.qualified_name].append(src)
                edges.append(_edge("EXTENDS", src, base, pf, ref))
            continue
        # CALL
        target = ref.target
        last = target.split(".")[-1]
        if last in DYNAMIC_CALLS:
            edges.append(_unresolved("CALLS", src, target, pf, ref,
                                     "dynamic/reflective call; target cannot be determined statically"))
            continue
        if "(" in target or "[" in target:
            continue  # call on an expression result: receiver unknowable, ignore
        parts = target.split(".")
        dst: ParsedSymbol | None = None
        if parts[0] in {"self", "cls"}:
            owner = idx.class_of(src)
            if owner is not None and len(parts) == 2:
                dst = _py_member(idx, owner, parts[1])
            elif owner is not None and len(parts) == 3:
                for cls in idx.mro(owner):
                    ctor = pf_attr(idx, cls, parts[1])
                    if ctor:
                        tcls = _py_chain(idx, idx.sym_file[cls.id], ctor.split("."))
                        if tcls is not None and tcls.kind in CLASS_KINDS:
                            dst = _py_member(idx, tcls, parts[2])
                        break
        elif ref.receiver_type and len(parts) == 2:
            tcls = _py_chain(idx, pf, ref.receiver_type.split("."))
            if tcls is not None and tcls.kind in CLASS_KINDS:
                dst = _py_member(idx, tcls, parts[1])
        else:
            dst = _py_chain(idx, pf, parts)
            if dst is not None and dst.kind in CLASS_KINDS:
                dst = _py_constructor_target(idx, dst)
        if dst is not None:
            edges.append(_edge("CALLS", src, dst, pf, ref))
            continue
        cand = idx.candidates_note(last)
        if cand is not None:
            edges.append(_unresolved("CALLS", src, target, pf, ref,
                                     f"receiver type unknown or ambiguous; {cand}"))


def pf_attr(idx: _Index, cls: ParsedSymbol, attr: str) -> str | None:
    return idx.sym_file[cls.id].attr_types.get(cls.qualified_name, {}).get(attr)


# ------------------------------------------------------------------------------------------
# Java
# ------------------------------------------------------------------------------------------
def _build_java_imports(idx: _Index, pf: ParsedFile, edges: list[EdgeRecord]) -> None:
    explicit: dict[str, str] = {}
    wildcard: list[str] = []
    src_file = idx.file_syms[pf.rel_path].get(f"file:{pf.rel_path}")
    for ref in pf.refs:
        if ref.kind != "IMPORT":
            continue
        if ref.names == ["*"]:
            wildcard.append(ref.target)
            continue
        target = ref.target
        if ref.static:
            target = target.rsplit(".", 1)[0]  # static import of member: depend on its type
        sym = idx.one(target)
        if sym is not None and sym.kind in CLASS_KINDS:
            if not ref.static:
                explicit[sym.name] = sym.qualified_name
            if src_file is not None:
                edges.append(_edge("IMPORTS", src_file, sym, pf, ref))
        elif sym is None and target.split(".")[-1] in idx.java_types_by_simple and not ref.static:
            # looks internal (simple name exists) but the package does not match
            if src_file is not None:
                edges.append(_unresolved("IMPORTS", src_file, ref.target, pf, ref,
                                         "imported type not found under that package"))
    idx.java_imports[pf.rel_path] = (explicit, wildcard)


def _java_type(idx: _Index, pf: ParsedFile, name: str, src: ParsedSymbol) -> ParsedSymbol | None:
    explicit, wildcard = idx.java_imports[pf.rel_path]
    if "." in name:
        return idx.one(name)
    owner = src
    while owner is not None:  # nested types visible from the enclosing class chain
        found = idx.one(f"{owner.qualified_name}.{name}")
        if found is not None and found.kind in CLASS_KINDS:
            return found
        owner = idx.one(owner.parent_qname) if owner.parent_qname else None  # type: ignore[assignment]
    if name in explicit:
        return idx.one(explicit[name])
    same_pkg = f"{pf.module_qname}.{name}" if pf.module_qname else name
    found = idx.one(same_pkg)
    if found is not None:
        return found
    for pkg in wildcard:
        found = idx.one(f"{pkg}.{name}")
        if found is not None:
            return found
    return None


def _java_methods(idx: _Index, cls: ParsedSymbol, name: str) -> tuple[list[ParsedSymbol], ParsedSymbol]:
    """Methods called ``name`` from the nearest type in the hierarchy that declares any."""
    for candidate_cls in idx.mro(cls):
        found = [s for s in idx.children.get(candidate_cls.qualified_name, [])
                 if s.name == name and s.kind in {"method", "constructor"}]
        if found:
            return found, candidate_cls
    return [], cls


def _resolve_java(idx: _Index, pf: ParsedFile, edges: list[EdgeRecord], phase: str) -> None:

    def pick(methods: list[ParsedSymbol], arity: int | None) -> tuple[ParsedSymbol | None, str | None]:
        if len(methods) == 1:
            return methods[0], None
        by_arity = [m for m in methods if arity is not None and m.arity == arity]
        if len(by_arity) == 1:
            return by_arity[0], None
        return None, (
            f"overloaded: {len(by_arity) or len(methods)} candidate(s) match name"
            + (f" and arity {arity}" if by_arity else "")
        )

    for ref in pf.refs:
        if ref.kind == "IMPORT" or (ref.kind == "CALL") != (phase == "calls"):
            continue
        src = idx.src_of(pf, ref)
        if src is None:
            continue
        if ref.kind in {"EXTENDS", "IMPLEMENTS"}:
            dst = _java_type(idx, pf, ref.target, src)
            if dst is not None:
                idx.bases[src.qualified_name].append(dst)
                idx.subtypes[dst.qualified_name].append(src)
                edge_type = "EXTENDS"
                if ref.kind == "IMPLEMENTS" or (src.kind == "class" and dst.kind == "interface"):
                    edge_type = "IMPLEMENTS"
                edges.append(_edge(edge_type, src, dst, pf, ref))
            continue
        target = ref.target
        last = target.split(".")[-1]
        if last in JAVA_DYNAMIC_CALLS and not target.startswith("new "):
            edges.append(_unresolved("CALLS", src, target, pf, ref,
                                     "reflection; target cannot be determined statically"))
            continue
        if target.startswith("new "):
            cls = _java_type(idx, pf, ref.receiver_type or target[4:], src)
            if cls is None:
                continue  # external type
            ctors = [s for s in idx.children.get(cls.qualified_name, []) if s.kind == "constructor"]
            ctor, _ = pick(ctors, ref.arg_count) if ctors else (None, None)
            edges.append(_edge("CALLS", src, ctor or cls, pf, ref))
            continue
        owner_cls = idx.class_of(src)
        dst_cls: ParsedSymbol | None = None
        note_extra: str | None = None
        if ref.receiver_type == "super" and owner_cls is not None:
            supers = idx.bases.get(owner_cls.qualified_name, [])
            dst_cls = supers[0] if supers else None
        elif ref.receiver_type:
            dst_cls = _java_type(idx, pf, ref.receiver_type, src)
            if dst_cls is None:
                continue  # receiver is an external type (List, String, ...)
        elif "." not in target:
            dst_cls = owner_cls
            while dst_cls is not None:  # also search lexically enclosing classes
                methods, _ = _java_methods(idx, dst_cls, last)
                if methods:
                    break
                outer = idx.one(dst_cls.parent_qname) if dst_cls.parent_qname else None
                dst_cls = idx.class_of(outer) if outer is not None else None
        if dst_cls is not None:
            methods, _ = _java_methods(idx, dst_cls, last)
            chosen, why = pick(methods, ref.arg_count) if methods else (None, None)
            if chosen is not None:
                declaring = idx.class_of(chosen) or dst_cls
                if declaring.kind == "interface":
                    impls = sorted({s.qualified_name for s in _all_subtypes(idx, declaring)})
                    if impls:
                        note_extra = "dynamic dispatch; implementations: " + ", ".join(impls)
                edges.append(_edge("CALLS", src, chosen, pf, ref, note_extra))
                continue
            if why is not None:
                edges.append(_unresolved("CALLS", src, target, pf, ref, why))
                continue
        cand = idx.candidates_note(last)
        if cand is not None:
            edges.append(_unresolved("CALLS", src, target, pf, ref,
                                     f"receiver type unknown or ambiguous; {cand}"))


def _all_subtypes(idx: _Index, cls: ParsedSymbol) -> list[ParsedSymbol]:
    seen: list[ParsedSymbol] = []
    queue = list(idx.subtypes.get(cls.qualified_name, []))
    while queue:
        current = queue.pop(0)
        if current not in seen:
            seen.append(current)
            queue.extend(idx.subtypes.get(current.qualified_name, []))
    return seen


# ------------------------------------------------------------------------------------------
def build_edges(files: list[ParsedFile]) -> list[EdgeRecord]:
    """Produce DEFINES/IMPORTS/CALLS/EXTENDS/IMPLEMENTS/TESTS edges for parsed files."""
    idx = _Index(files)
    edges: list[EdgeRecord] = []
    py_files = [f for f in files if f.language == "python" and not f.error]
    java_files = [f for f in files if f.language == "java"]

    for pf in files:  # DEFINES from declaration structure
        local = idx.file_syms[pf.rel_path]
        for sym in pf.symbols:
            parent = local.get(sym.parent_qname) if sym.parent_qname else None
            if parent is not None:
                edges.append(EdgeRecord("DEFINES", "RESOLVED", parent.id, sym.id, None,
                                        pf.rel_path, sym.start_line,
                                        sym.signature or sym.name))
    for pf in py_files:
        _build_py_imports(idx, pf, edges)
    for pf in java_files:
        _build_java_imports(idx, pf, edges)
    # Inheritance first (method lookup depends on it), then calls.
    for phase in ("bases", "calls"):
        for pf in py_files:
            _resolve_python(idx, pf, edges, phase)
        for pf in java_files:
            _resolve_java(idx, pf, edges, phase)
    return _finalize(idx, edges)


def _finalize(idx: _Index, edges: list[EdgeRecord]) -> list[EdgeRecord]:
    """Convert test->production CALLS to TESTS and drop exact duplicates."""
    dst_file: dict[uuid.UUID, ParsedFile] = idx.sym_file
    out: list[EdgeRecord] = []
    seen: set[tuple] = set()
    for e in edges:
        if e.edge_type == "CALLS" and e.status == "RESOLVED" and e.dst_id is not None:
            src_pf, dst_pf = dst_file[e.src_id], dst_file[e.dst_id]
            if src_pf.is_test and not dst_pf.is_test:
                e = EdgeRecord("TESTS", e.status, e.src_id, e.dst_id, e.dst_ref, e.rel_path,
                               e.line, e.evidence, e.note)
        key = (e.edge_type, e.status, e.src_id, e.dst_id, e.dst_ref, e.line)
        if key in seen:
            continue
        seen.add(key)
        out.append(e)
    return out
