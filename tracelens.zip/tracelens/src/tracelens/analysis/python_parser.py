"""Python source analysis using the standard-library ``ast`` module (never executes code)."""

from __future__ import annotations

import ast

from tracelens.analysis.types import ParsedFile, ParsedSymbol, RawRef

# Calls that signal runtime dispatch we deliberately do not try to resolve.
DYNAMIC_CALLS = {"getattr", "__import__", "import_module", "eval", "exec"}


def module_name_for(rel_path: str) -> str:
    path = rel_path[:-3] if rel_path.endswith(".py") else rel_path
    parts = [p for p in path.split("/") if p]
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _dotted(node: ast.AST) -> str | None:
    """Return 'a.b.c' for pure Name/Attribute chains, else None."""
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


def _annotation_type(node: ast.AST | None) -> str | None:
    if node is None:
        return None
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value.strip("'\"") or None
    if isinstance(node, ast.Subscript):  # Optional[Foo] / list[Foo] -> not a plain type
        inner = node.slice
        if _dotted(node.value) in {"Optional", "typing.Optional"}:
            return _annotation_type(inner)
        return None
    return _dotted(node)


class _Visitor(ast.NodeVisitor):
    def __init__(self, parsed: ParsedFile, source_lines: list[str]) -> None:
        self.parsed = parsed
        self.lines = source_lines
        module = parsed.module_qname
        self.module_qname = module
        self.symbol_stack: list[ParsedSymbol] = []
        self.class_stack: list[ParsedSymbol] = []
        self.var_types: list[dict[str, str]] = [{}]

    # -- helpers ---------------------------------------------------------------------------
    def _line(self, lineno: int) -> str:
        return self.lines[lineno - 1].strip() if 0 < lineno <= len(self.lines) else ""

    @property
    def _current(self) -> ParsedSymbol:
        return self.symbol_stack[-1]

    def _add_symbol(self, node: ast.AST, kind: str, name: str, signature: str | None,
                    arity: int | None = None) -> ParsedSymbol:
        parent = self._current
        sym = ParsedSymbol(
            kind=kind,
            name=name,
            qualified_name=f"{parent.qualified_name}.{name}",
            start_line=min(
                [node.lineno]  # type: ignore[attr-defined]
                + [d.lineno for d in getattr(node, "decorator_list", [])]
            ),
            end_line=getattr(node, "end_lineno", node.lineno) or node.lineno,  # type: ignore[attr-defined]
            signature=signature,
            parent_qname=parent.qualified_name,
            arity=arity,
        )
        self.parsed.symbols.append(sym)
        return sym

    def _ref(self, **kwargs) -> None:
        self.parsed.refs.append(RawRef(**kwargs))

    # -- structure -------------------------------------------------------------------------
    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self._ref(
                kind="IMPORT", src_qname=self.symbol_stack[0].qualified_name,
                src_start_line=self.symbol_stack[0].start_line, target=alias.name,
                line=node.lineno, evidence=self._line(node.lineno), alias=alias.asname,
            )

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        names = [a.name for a in node.names]
        alias = {a.name: a.asname for a in node.names if a.asname}
        self._ref(
            kind="IMPORT", src_qname=self.symbol_stack[0].qualified_name,
            src_start_line=self.symbol_stack[0].start_line, target=node.module or "",
            line=node.lineno, evidence=self._line(node.lineno),
            names=names, level=node.level,
            alias=",".join(f"{k}={v}" for k, v in alias.items()) or None,
        )

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        sym = self._add_symbol(node, "class", node.name, f"class {node.name}")
        for base in node.bases:
            expr = _dotted(base)
            if expr and expr not in {"object", "ABC", "abc.ABC"}:
                self._ref(kind="EXTENDS", src_qname=sym.qualified_name,
                          src_start_line=sym.start_line, target=expr,
                          line=node.lineno, evidence=self._line(node.lineno))
        self.symbol_stack.append(sym)
        self.class_stack.append(sym)
        for child in node.body:
            self.visit(child)
        self.class_stack.pop()
        self.symbol_stack.pop()

    def _visit_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        in_class = bool(self.class_stack) and self._current is self.class_stack[-1]
        nested = len(self.symbol_stack) > 1 and not in_class
        params = [a for a in (node.args.posonlyargs + node.args.args)]
        if in_class and params and params[0].arg in {"self", "cls"}:
            params = params[1:]
        arity = len(params)
        if nested:
            # Nested helper: attribute its calls to the enclosing symbol.
            self.generic_visit(node)
            return
        kind = "method" if in_class else "function"
        sig_params = ", ".join(a.arg for a in node.args.args)
        sym = self._add_symbol(node, kind, node.name, f"{node.name}({sig_params})", arity)
        types: dict[str, str] = {}
        for arg in node.args.posonlyargs + node.args.args + node.args.kwonlyargs:
            hint = _annotation_type(arg.annotation)
            if hint:
                types[arg.arg] = hint
        self.var_types.append(types)
        self.symbol_stack.append(sym)
        for child in node.body:
            self.visit(child)
        self.symbol_stack.pop()
        self.var_types.pop()

    visit_FunctionDef = _visit_function
    visit_AsyncFunctionDef = _visit_function

    # -- type hints from assignments -----------------------------------------------------
    def visit_Assign(self, node: ast.Assign) -> None:
        ctor = _dotted(node.value.func) if isinstance(node.value, ast.Call) else None
        if ctor:
            for target in node.targets:
                if isinstance(target, ast.Name):
                    self.var_types[-1][target.id] = ctor
                elif (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "self"
                    and self.class_stack
                ):
                    attrs = self.parsed.attr_types.setdefault(
                        self.class_stack[-1].qualified_name, {}
                    )
                    attrs[target.attr] = ctor
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        hint = _annotation_type(node.annotation)
        if hint and isinstance(node.target, ast.Name):
            self.var_types[-1][node.target.id] = hint
        self.generic_visit(node)

    # -- calls ---------------------------------------------------------------------------
    def visit_Call(self, node: ast.Call) -> None:
        target = _dotted(node.func)
        arg_count = len(node.args) + len(node.keywords)
        if target is None:
            # a().b() / x[0]() -> receiver is an expression result; recorded for the resolver
            target = ast.unparse(node.func)
        receiver_type = None
        if target and "." in target and "(" not in target:
            head = target.split(".")[0]
            for scope in reversed(self.var_types):
                if head in scope:
                    receiver_type = scope[head]
                    break
        self._ref(
            kind="CALL", src_qname=self._current.qualified_name,
            src_start_line=self._current.start_line, target=target,
            line=node.lineno, evidence=self._line(node.lineno), arg_count=arg_count,
            receiver_type=receiver_type,
        )
        self.generic_visit(node)


def parse_python(source: str, rel_path: str, is_test: bool) -> ParsedFile:
    module = module_name_for(rel_path)
    parsed = ParsedFile(rel_path=rel_path, language="python", is_test=is_test, module_qname=module)
    lines = source.splitlines()
    try:
        tree = ast.parse(source, filename=rel_path)
    except (SyntaxError, ValueError) as exc:
        parsed.error = f"python syntax error: {exc}"
        return parsed
    root = ParsedSymbol(
        kind="module", name=module.split(".")[-1] if module else rel_path,
        qualified_name=module or rel_path, start_line=1, end_line=max(len(lines), 1),
        signature=f"module {module}",
    )
    parsed.symbols.append(root)
    visitor = _Visitor(parsed, lines)
    visitor.symbol_stack.append(root)
    for stmt in tree.body:
        visitor.visit(stmt)
    return parsed
