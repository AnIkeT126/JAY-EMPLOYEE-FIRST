"""Parser-neutral data structures shared by the Python/Java parsers and the resolver."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field


@dataclass
class ParsedSymbol:
    kind: str  # module | file | class | interface | enum | function | method | constructor
    name: str
    qualified_name: str
    start_line: int
    end_line: int
    signature: str | None = None
    parent_qname: str | None = None
    arity: int | None = None  # Java/Python callable parameter count (excluding self)
    id: uuid.UUID = field(default_factory=uuid.uuid4)


@dataclass
class RawRef:
    """An unresolved reference found in source. ``kind`` is IMPORT/CALL/EXTENDS/IMPLEMENTS."""

    kind: str
    src_qname: str  # qualified name of the symbol containing the reference
    src_start_line: int  # start line of that symbol (disambiguates overloads)
    target: str  # textual target, e.g. "calculate_total", "self.total", "service.estimate"
    line: int
    evidence: str  # the source line (stripped)
    arg_count: int | None = None
    # Receiver type hint for ``var.method()`` calls: a type expression such as "Invoice".
    receiver_type: str | None = None
    # IMPORT only: imported names ("*" for wildcard) and alias map {alias: name}
    names: list[str] = field(default_factory=list)
    alias: str | None = None
    level: int = 0  # Python relative-import level
    static: bool = False  # Java static import


@dataclass
class ParsedFile:
    rel_path: str
    language: str
    is_test: bool
    module_qname: str  # python dotted module path, java package (may be "")
    symbols: list[ParsedSymbol] = field(default_factory=list)
    refs: list[RawRef] = field(default_factory=list)
    # Python: class qname -> {self attribute -> constructor/type expression}
    attr_types: dict[str, dict[str, str]] = field(default_factory=dict)
    error: str | None = None
