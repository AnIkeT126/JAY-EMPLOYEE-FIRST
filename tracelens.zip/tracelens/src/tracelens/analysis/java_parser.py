"""Java source analysis using tree-sitter (a maintained incremental parser).

Only syntax is analysed; types are resolved later by name from declarations, imports and
the variable/field/parameter declarations visible in the enclosing method.
"""

from __future__ import annotations

import re

import tree_sitter_java
from tree_sitter import Language, Node, Parser

from tracelens.analysis.types import ParsedFile, ParsedSymbol, RawRef

_LANGUAGE = Language(tree_sitter_java.language())

JAVA_DYNAMIC_CALLS = {"forName", "getMethod", "getDeclaredMethod", "invoke", "newInstance",
                      "getConstructor"}
_TYPE_DECLS = {
    "class_declaration": "class",
    "interface_declaration": "interface",
    "enum_declaration": "enum",
    "record_declaration": "class",
}
_TYPE_NODE_NAMES = {"type_identifier", "scoped_type_identifier"}


def _text(node: Node | None) -> str:
    return node.text.decode("utf-8", errors="replace") if node is not None and node.text else ""


def _line_no(node: Node) -> int:
    return node.start_point[0] + 1


def _end_line(node: Node) -> int:
    return node.end_point[0] + 1


def _type_name(node: Node | None) -> str | None:
    """Reduce a type node (generic/array/scoped) to a plain type name."""
    if node is None:
        return None
    if node.type in _TYPE_NODE_NAMES:
        return _text(node)
    if node.type == "generic_type":
        for child in node.children:
            if child.type in _TYPE_NODE_NAMES:
                return _text(child)
        return None
    if node.type == "array_type":
        return _type_name(node.child_by_field_name("element"))
    return None


class _JavaVisitor:
    def __init__(self, parsed: ParsedFile, lines: list[str], package: str) -> None:
        self.parsed = parsed
        self.lines = lines
        self.package = package

    def _evidence(self, node: Node) -> str:
        idx = node.start_point[0]
        return self.lines[idx].strip() if idx < len(self.lines) else ""

    def _ref(self, **kwargs) -> None:
        self.parsed.refs.append(RawRef(**kwargs))

    # -- types -----------------------------------------------------------------------------
    def visit_type(self, node: Node, outer_qname: str | None, file_sym: ParsedSymbol) -> None:
        kind = _TYPE_DECLS[node.type]
        name = _text(node.child_by_field_name("name"))
        qname = f"{outer_qname}.{name}" if outer_qname else (
            f"{self.package}.{name}" if self.package else name
        )
        sym = ParsedSymbol(
            kind=kind, name=name, qualified_name=qname, start_line=_line_no(node),
            end_line=_end_line(node), signature=f"{kind} {name}",
            parent_qname=outer_qname or file_sym.qualified_name,
        )
        self.parsed.symbols.append(sym)

        superclass = node.child_by_field_name("superclass")
        if superclass is not None:
            for child in superclass.children:
                tname = _type_name(child)
                if tname:
                    self._ref(kind="EXTENDS", src_qname=qname, src_start_line=sym.start_line,
                              target=tname, line=_line_no(node), evidence=self._evidence(node))
        interfaces = node.child_by_field_name("interfaces")
        if interfaces is not None:
            for tname in self._type_list(interfaces):
                self._ref(kind="IMPLEMENTS", src_qname=qname, src_start_line=sym.start_line,
                          target=tname, line=_line_no(node), evidence=self._evidence(node))
        for child in node.children:
            if child.type == "extends_interfaces":  # interface A extends B, C
                for tname in self._type_list(child):
                    self._ref(kind="EXTENDS", src_qname=qname, src_start_line=sym.start_line,
                              target=tname, line=_line_no(node), evidence=self._evidence(node))

        body = node.child_by_field_name("body")
        if body is None:
            return
        field_types: dict[str, str] = {}
        members = list(body.children)
        for member in list(members):  # enum bodies nest members one level deeper
            if member.type == "enum_body_declarations":
                members.extend(member.children)
        for member in members:
            if member.type == "field_declaration":
                tname = _type_name(member.child_by_field_name("type"))
                if tname:
                    for decl in member.children:
                        if decl.type == "variable_declarator":
                            field_types[_text(decl.child_by_field_name("name"))] = tname
        for member in members:
            if member.type in ("method_declaration", "constructor_declaration"):
                self.visit_method(member, sym, field_types)
            elif member.type in _TYPE_DECLS:
                self.visit_type(member, qname, file_sym)
            elif member.type in ("field_declaration", "static_initializer", "block"):
                self.walk_calls(member, qname, sym.start_line, field_types)

    @staticmethod
    def _type_list(node: Node) -> list[str]:
        names: list[str] = []
        stack = [node]
        while stack:
            current = stack.pop()
            for child in reversed(current.children):
                if child.type == "type_list":
                    stack.append(child)
                else:
                    tname = _type_name(child)
                    if tname:
                        names.append(tname)
        return names

    # -- methods ---------------------------------------------------------------------------
    def visit_method(self, node: Node, owner: ParsedSymbol, field_types: dict[str, str]) -> None:
        is_ctor = node.type == "constructor_declaration"
        name = _text(node.child_by_field_name("name"))
        params = node.child_by_field_name("parameters")
        param_nodes = [
            c for c in (params.children if params else [])
            if c.type in ("formal_parameter", "spread_parameter")
        ]
        param_types = {}
        for p in param_nodes:
            tname = _type_name(p.child_by_field_name("type")) if p.type == "formal_parameter" else None
            pname = _text(p.child_by_field_name("name"))
            if p.type == "spread_parameter":
                for c in p.children:
                    tname = tname or _type_name(c)
                    if c.type == "variable_declarator":
                        pname = _text(c.child_by_field_name("name"))
            if tname and pname:
                param_types[pname] = tname
        sig = re.sub(r"\s+", " ", _text(params)) if params is not None else "()"
        sym = ParsedSymbol(
            kind="constructor" if is_ctor else "method", name=name,
            qualified_name=f"{owner.qualified_name}.{name}", start_line=_line_no(node),
            end_line=_end_line(node), signature=f"{name}{sig}",
            parent_qname=owner.qualified_name, arity=len(param_nodes),
        )
        self.parsed.symbols.append(sym)
        body = node.child_by_field_name("body")
        if body is None:
            return
        types = dict(field_types)
        types.update(param_types)
        self._collect_locals(body, types)
        self.walk_calls(body, sym.qualified_name, sym.start_line, types)

    def _collect_locals(self, node: Node, types: dict[str, str]) -> None:
        stack = [node]
        while stack:
            current = stack.pop()
            if current.type == "local_variable_declaration":
                tname = _type_name(current.child_by_field_name("type"))
                for decl in current.children:
                    if decl.type != "variable_declarator":
                        continue
                    vname = _text(decl.child_by_field_name("name"))
                    declared = tname
                    if declared is None or declared == "var":
                        value = decl.child_by_field_name("value")
                        declared = (
                            _type_name(value.child_by_field_name("type"))
                            if value is not None and value.type == "object_creation_expression"
                            else None
                        )
                    if declared:
                        types[vname] = declared
            stack.extend(current.children)

    # -- calls -----------------------------------------------------------------------------
    def walk_calls(self, node: Node, src_qname: str, src_start: int,
                   types: dict[str, str]) -> None:
        stack = [node]
        while stack:
            current = stack.pop()
            if current.type == "method_invocation":
                self._invocation(current, src_qname, src_start, types)
            elif current.type == "object_creation_expression":
                tname = _type_name(current.child_by_field_name("type"))
                if tname:
                    args = current.child_by_field_name("arguments")
                    count = len([c for c in (args.children if args else []) if c.is_named
                                 and c.type != "comment"])
                    self._ref(kind="CALL", src_qname=src_qname, src_start_line=src_start,
                              target=f"new {tname}",
                              line=_line_no(current), evidence=self._evidence(current),
                              arg_count=count, receiver_type=tname)
            stack.extend(reversed(current.children))

    def _invocation(self, node: Node, src_qname: str, src_start: int,
                    types: dict[str, str]) -> None:
        name = _text(node.child_by_field_name("name"))
        obj = node.child_by_field_name("object")
        args = node.child_by_field_name("arguments")
        count = len([c for c in (args.children if args else []) if c.is_named
                     and c.type != "comment"])
        receiver_type: str | None = None
        if obj is None:
            target = name
        else:
            obj_text = _text(obj)
            if obj.type == "this":
                target = name
            elif obj.type == "super":
                target, receiver_type = f"super.{name}", "super"
            elif obj.type == "identifier":
                target = f"{obj_text}.{name}"
                if obj_text in types:
                    receiver_type = types[obj_text]
                elif obj_text[:1].isupper():
                    receiver_type = obj_text  # static call on a type name
            elif obj.type == "field_access" and _text(obj.child_by_field_name("object")) == "this":
                field = _text(obj.child_by_field_name("field"))
                target = f"this.{field}.{name}"
                receiver_type = types.get(field)
            else:
                target = f"{obj_text}.{name}"  # chained/complex receiver: not resolvable
        self._ref(kind="CALL", src_qname=src_qname, src_start_line=src_start, target=target,
                  line=_line_no(node),
                  evidence=self._evidence(node), arg_count=count, receiver_type=receiver_type)


def parse_java(source: str, rel_path: str, is_test: bool) -> ParsedFile:
    parsed = ParsedFile(rel_path=rel_path, language="java", is_test=is_test, module_qname="")
    data = source.encode("utf-8")
    tree = Parser(_LANGUAGE).parse(data)
    lines = source.splitlines()
    if tree.root_node.has_error:
        # tree-sitter recovers from errors; keep what was parsed but record the limitation.
        parsed.error = "java parse tree contains syntax errors; results may be incomplete"

    package = ""
    for child in tree.root_node.children:
        if child.type == "package_declaration":
            package = next((_text(c) for c in child.children
                            if c.type in ("scoped_identifier", "identifier")), "")
    parsed.module_qname = package
    file_sym = ParsedSymbol(
        kind="file", name=rel_path.rsplit("/", 1)[-1], qualified_name=f"file:{rel_path}",
        start_line=1, end_line=max(len(lines), 1), signature=f"file {rel_path}",
    )
    parsed.symbols.append(file_sym)
    visitor = _JavaVisitor(parsed, lines, package)
    for child in tree.root_node.children:
        if child.type == "import_declaration":
            raw = _text(child).rstrip(";").strip()
            body = raw[len("import"):].strip()
            static = body.startswith("static ")
            if static:
                body = body[len("static "):].strip()
            wildcard = body.endswith(".*")
            target = body[:-2] if wildcard else body
            parsed.refs.append(RawRef(
                kind="IMPORT", src_qname=file_sym.qualified_name, src_start_line=1, target=target,
                line=_line_no(child), evidence=visitor._evidence(child),
                names=["*"] if wildcard else [], static=static,
            ))
        elif child.type in _TYPE_DECLS:
            visitor.visit_type(child, None, file_sym)
    return parsed
