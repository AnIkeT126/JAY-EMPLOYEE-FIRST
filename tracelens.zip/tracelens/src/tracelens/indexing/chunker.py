"""Source-aware chunking: one chunk per function/method/class header/markdown section."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from tracelens.analysis.types import ParsedFile, ParsedSymbol
from tracelens.indexing.discovery import SourceFile

_TOKEN_RE = re.compile(r"[A-Za-z]+|[0-9]+")
_CAMEL_RE = re.compile(r"[A-Z]+(?![a-z])|[A-Z]?[a-z]+|[0-9]+")


@dataclass
class ChunkDraft:
    kind: str
    symbol_qname: str | None
    symbol_name: str | None
    start_line: int
    end_line: int
    content: str
    content_sha: str
    search_text: str


def search_tokens(text: str) -> list[str]:
    """Lower-cased alphanumeric tokens with camelCase / snake_case identifiers split.

    Indexing and querying both use this function so exact identifiers stay matchable: an
    identifier such as ``calculateTotal`` yields ``calculate`` and ``total`` (and so does
    ``calculate_total``); the whole identifier is also kept for exact matching.
    """
    tokens: list[str] = []
    for word in re.findall(r"[A-Za-z0-9_]+", text):
        parts = [p.lower() for piece in word.split("_") if piece for p in _CAMEL_RE.findall(piece)]
        if len(parts) > 1:
            tokens.append("".join(parts))  # whole identifier, e.g. calculatetotal
        tokens.extend(parts)
    return tokens


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _make(kind: str, sym: ParsedSymbol | None, path: str, lines: list[str], start: int, end: int,
          name: str | None = None) -> ChunkDraft | None:
    body = "\n".join(lines[start - 1:end])
    if not body.strip():
        return None
    sym_name = name or (sym.name if sym else None)
    header = f"{path} {sym_name or ''}"
    return ChunkDraft(
        kind=kind,
        symbol_qname=sym.qualified_name if sym else None,
        symbol_name=sym_name,
        start_line=start,
        end_line=end,
        content=body,
        content_sha=_sha(body),
        search_text=" ".join(search_tokens(f"{header}\n{body}")),
    )


def _windows(draft: ChunkDraft, lines: list[str], path: str, max_lines: int,
             overlap: int) -> list[ChunkDraft]:
    if draft.end_line - draft.start_line + 1 <= max_lines:
        return [draft]
    out: list[ChunkDraft] = []
    start = draft.start_line
    step = max_lines - overlap
    while start <= draft.end_line:
        end = min(start + max_lines - 1, draft.end_line)
        sub = _make(draft.kind, None, path, lines, start, end, draft.symbol_name)
        if sub is not None:
            sub.symbol_qname = draft.symbol_qname
            out.append(sub)
        if end == draft.end_line:
            break
        start += step
    return out


def _chunk_code(parsed: ParsedFile, lines: list[str], path: str) -> list[ChunkDraft]:
    """Chunk by symbol; gaps (imports, constants) become 'module' chunks."""
    members = [s for s in parsed.symbols if s.kind in {"function", "method", "constructor"}]
    containers = [s for s in parsed.symbols if s.kind in {"class", "interface", "enum"}]
    covered = [False] * (len(lines) + 2)
    drafts: list[ChunkDraft] = []

    for sym in members:
        draft = _make(sym.kind, sym, path, lines, sym.start_line, sym.end_line)
        if draft:
            drafts.append(draft)
        for ln in range(sym.start_line, sym.end_line + 1):
            covered[ln] = True
    for sym in containers:
        child_starts = [s.start_line for s in parsed.symbols
                        if s.parent_qname == sym.qualified_name]
        header_end = min(child_starts) - 1 if child_starts else sym.end_line
        if header_end >= sym.start_line:
            draft = _make(sym.kind, sym, path, lines, sym.start_line, header_end)
            if draft:
                drafts.append(draft)
        # Mark the whole class body covered for gap computation, except lines not belonging to
        # any member (e.g. comments between methods) which remain part of the class region.
        for ln in range(sym.start_line, sym.end_line + 1):
            covered[ln] = True

    gap_start: int | None = None
    for ln in range(1, len(lines) + 2):
        is_gap = ln <= len(lines) and not covered[ln]
        if is_gap and gap_start is None:
            gap_start = ln
        elif not is_gap and gap_start is not None:
            draft = _make("module", None, path, lines, gap_start, ln - 1, "module")
            if draft:
                drafts.append(draft)
            gap_start = None
    return drafts


_FENCE_RE = re.compile(r"^\s*(```|~~~)")
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")


def _chunk_markdown(lines: list[str], path: str) -> list[ChunkDraft]:
    sections: list[tuple[int, str]] = []  # (start_line, heading)
    in_fence = False
    for i, line in enumerate(lines, start=1):
        if _FENCE_RE.match(line):
            in_fence = not in_fence
        elif not in_fence:
            m = _HEADING_RE.match(line)
            if m:
                sections.append((i, m.group(2)))
    drafts: list[ChunkDraft] = []
    if not sections or sections[0][0] > 1:
        first_end = (sections[0][0] - 1) if sections else len(lines)
        d = _make("section", None, path, lines, 1, first_end, "(preamble)")
        if d:
            drafts.append(d)
    for idx, (start, heading) in enumerate(sections):
        end = sections[idx + 1][0] - 1 if idx + 1 < len(sections) else len(lines)
        d = _make("section", None, path, lines, start, end, heading)
        if d:
            drafts.append(d)
    return drafts


def chunk_file(source: SourceFile, parsed: ParsedFile | None, max_lines: int,
               overlap: int) -> list[ChunkDraft]:
    lines = source.content.splitlines()
    if source.language == "markdown":
        drafts = _chunk_markdown(lines, source.rel_path)
    elif parsed is not None and not parsed.error and parsed.symbols:
        drafts = _chunk_code(parsed, lines, source.rel_path)
    else:  # parse failure / nothing structural: bounded fallback windows
        base = _make("window", None, source.rel_path, lines, 1, len(lines))
        drafts = [base] if base else []
    out: list[ChunkDraft] = []
    for draft in drafts:
        out.extend(_windows(draft, lines, source.rel_path, max_lines, overlap))
    out.sort(key=lambda c: (c.start_line, c.end_line))
    return out
