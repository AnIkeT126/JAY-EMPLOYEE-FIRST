"""Safe, bounded source-file discovery. Repository contents are untrusted input."""

from __future__ import annotations

import fnmatch
import hashlib
import os
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from tracelens.errors import IndexLimitError, PathPolicyError

SUPPORTED_EXTENSIONS = {".py": "python", ".java": "java", ".md": "markdown"}
_GENERATED_MARKERS = ("@generated", "code generated", "do not edit")


@dataclass(frozen=True)
class SourceFile:
    rel_path: str
    language: str
    content: str
    sha256: str
    size_bytes: int
    line_count: int
    is_test: bool


@dataclass(frozen=True)
class DiscoveryResult:
    files: list[SourceFile]
    skipped: list[tuple[str, str]]  # (rel_path, reason)


def resolve_within(base: Path, relative: str) -> Path:
    """Resolve ``relative`` under ``base``; reject absolute paths, traversal and symlink escape."""
    if "\x00" in relative:
        raise PathPolicyError("path contains a NUL byte")
    candidate = PurePosixPath(relative.replace("\\", "/"))
    if candidate.is_absolute() or (len(relative) > 1 and relative[1] == ":"):
        raise PathPolicyError("absolute paths are not accepted; use a path relative to the root")
    if ".." in candidate.parts:
        raise PathPolicyError("path traversal ('..') is not allowed")
    base_real = base.resolve()
    target = (base_real / Path(*candidate.parts)).resolve() if candidate.parts else base_real
    if target != base_real and base_real not in target.parents:
        raise PathPolicyError("path resolves outside the configured repository root")
    if not target.is_dir():
        raise PathPolicyError("path is not an existing directory under the repository root")
    return target


def is_test_path(rel_path: str, language: str) -> bool:
    path = PurePosixPath(rel_path)
    name = path.name
    parts = {p.lower() for p in path.parts[:-1]}
    if language == "python":
        return name.startswith("test_") or name.endswith("_test.py") or bool(
            parts & {"tests", "test"}
        )
    if language == "java":
        return (
            name.endswith(("Test.java", "Tests.java", "IT.java"))
            or "test" in parts
            or ("src" in parts and "test" in parts)
        )
    return False


def _looks_generated(text: str) -> bool:
    head = "\n".join(text.splitlines()[:5]).lower()
    return any(marker in head for marker in _GENERATED_MARKERS)


def discover_files(
    root: Path,
    *,
    ignored_dirs: list[str],
    ignored_patterns: list[str],
    max_file_bytes: int,
    max_files: int,
) -> DiscoveryResult:
    root_real = root.resolve()
    files: list[SourceFile] = []
    skipped: list[tuple[str, str]] = []
    ignored = set(ignored_dirs)

    for dirpath, dirnames, filenames in os.walk(root_real, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in ignored)
        for filename in sorted(filenames):
            suffix = os.path.splitext(filename)[1].lower()
            language = SUPPORTED_EXTENSIONS.get(suffix)
            if language is None:
                continue
            full = Path(dirpath) / filename
            rel = full.relative_to(root_real).as_posix()
            if any(fnmatch.fnmatch(filename, pat) for pat in ignored_patterns):
                skipped.append((rel, "matches ignored pattern"))
                continue
            real = full.resolve()
            if root_real not in real.parents:
                skipped.append((rel, "symlink resolves outside repository root"))
                continue
            try:
                size = real.stat().st_size
            except OSError as exc:
                skipped.append((rel, f"stat failed: {exc.strerror}"))
                continue
            if size > max_file_bytes:
                skipped.append((rel, f"file larger than {max_file_bytes} bytes"))
                continue
            try:
                raw = real.read_bytes()
            except OSError as exc:
                skipped.append((rel, f"read failed: {exc.strerror}"))
                continue
            if b"\x00" in raw:
                skipped.append((rel, "binary content"))
                continue
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                skipped.append((rel, "not valid UTF-8"))
                continue
            if _looks_generated(text):
                skipped.append((rel, "generated code marker"))
                continue
            if len(files) >= max_files:
                raise IndexLimitError(
                    f"more than {max_files} supported files found; raise TRACELENS_MAX_FILES "
                    "or narrow the repository subdirectory"
                )
            files.append(
                SourceFile(
                    rel_path=rel,
                    language=language,
                    content=text,
                    sha256=hashlib.sha256(raw).hexdigest(),
                    size_bytes=size,
                    line_count=len(text.splitlines()) or 1,
                    is_test=is_test_path(rel, language),
                )
            )
    return DiscoveryResult(files=files, skipped=skipped)
