"""Repository indexing: discover -> parse -> resolve -> chunk -> embed -> persist atomically.

Consistency model: a snapshot row is created as RUNNING and committed first; all derived rows
(files, symbols, edges, chunks, embeddings) are written in one transaction together with the
RUNNING -> COMPLETED switch and the repository's ``active_snapshot_id`` pointer. If anything
fails the transaction rolls back (no partial rows) and the snapshot is marked FAILED in a
separate transaction. Queries only ever read the active snapshot.
"""

from __future__ import annotations

import logging
import time
import uuid
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import PurePosixPath

from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session, sessionmaker

from tracelens.analysis.java_parser import parse_java
from tracelens.analysis.python_parser import parse_python
from tracelens.analysis.resolver import build_edges
from tracelens.analysis.types import ParsedFile
from tracelens.config import Settings
from tracelens.database.session import session_scope
from tracelens.errors import (
    IndexingFailedError,
    IndexingInProgressError,
    NotFoundError,
    TraceLensError,
)
from tracelens.indexing.chunker import ChunkDraft, chunk_file, search_tokens
from tracelens.indexing.discovery import SourceFile, discover_files, resolve_within
from tracelens.models import (
    SNAPSHOT_COMPLETED,
    SNAPSHOT_FAILED,
    SNAPSHOT_RUNNING,
    Chunk,
    Edge,
    IndexedFile,
    Repository,
    Snapshot,
    Symbol,
)
from tracelens.retrieval import vector as vector_store
from tracelens.retrieval.embeddings import Embedder, validate_dimensions

log = logging.getLogger(__name__)


@dataclass
class IndexResult:
    repository_id: uuid.UUID
    snapshot_id: uuid.UUID
    unchanged: bool
    stats: dict = field(default_factory=dict)
    skipped: list[tuple[str, str]] = field(default_factory=list)


def _parse(source: SourceFile) -> ParsedFile | None:
    if source.language == "python":
        return parse_python(source.content, source.rel_path, source.is_test)
    if source.language == "java":
        return parse_java(source.content, source.rel_path, source.is_test)
    return None


def recover_stale_snapshots(session: Session, repository_id: uuid.UUID, stale_minutes: int) -> int:
    """Mark RUNNING snapshots older than the threshold FAILED (interrupted indexing)."""
    cutoff = datetime.now(UTC) - timedelta(minutes=stale_minutes)
    result = session.execute(
        update(Snapshot)
        .where(Snapshot.repository_id == repository_id, Snapshot.status == SNAPSHOT_RUNNING,
               Snapshot.started_at < cutoff)
        .values(status=SNAPSHOT_FAILED, finished_at=datetime.now(UTC),
                error="interrupted: indexing did not finish before the stale threshold")
    )
    return int(result.rowcount or 0)


class Indexer:
    def __init__(self, session_factory: sessionmaker, settings: Settings,
                 embedder: Embedder | None) -> None:
        self._factory = session_factory
        self._s = settings
        self._embedder = embedder

    # -- public API ------------------------------------------------------------------------
    def index(self, name: str | None = None, subdirectory: str = "",
              force: bool = False) -> IndexResult:
        root = resolve_within(self._s.repository_base, subdirectory)
        repo_name = name or (root.name or "repository")
        return self._run(repo_name, subdirectory, force)

    def reindex(self, repository_id: uuid.UUID, force: bool = False) -> IndexResult:
        with session_scope(self._factory) as session:
            repo = session.get(Repository, repository_id)
            if repo is None:
                raise NotFoundError("repository not found")
            name, sub = repo.name, repo.subdirectory
        return self._run(name, sub, force)

    # -- implementation --------------------------------------------------------------------
    def _run(self, repo_name: str, subdirectory: str, force: bool) -> IndexResult:
        started = time.perf_counter()
        root = resolve_within(self._s.repository_base, subdirectory)
        s = self._s
        if self._embedder is not None:
            with session_scope(self._factory) as session:
                try:
                    vector_store.ensure_available(session, s.embedding_dim)
                except TraceLensError as exc:
                    raise IndexingFailedError(
                        f"{exc.message} (or set TRACELENS_EMBEDDINGS_ENABLED=false to index "
                        "without embeddings)"
                    ) from exc

        discovery = discover_files(
            root, ignored_dirs=s.ignored_dir_list, ignored_patterns=s.ignored_pattern_list,
            max_file_bytes=s.max_file_bytes, max_files=s.max_files,
        )

        with session_scope(self._factory) as session:
            repo = self._lock_repo(session, repo_name, subdirectory)
            previous_id = repo.active_snapshot_id
            previous = self._previous_hashes(session, previous_id)
            current = {f.rel_path: f.sha256 for f in discovery.files}
            change = {
                "added": sorted(set(current) - set(previous)),
                "deleted": sorted(set(previous) - set(current)),
                "modified": sorted(p for p in current if p in previous and current[p] != previous[p]),
            }
            change["unchanged"] = [p for p in current if p in previous and current[p] == previous[p]]
            no_changes = not (change["added"] or change["deleted"] or change["modified"])
            if previous_id is not None and no_changes and not force:
                return IndexResult(repo.id, previous_id, True,
                                   {"changes": {k: len(v) for k, v in change.items()}},
                                   discovery.skipped)
            snapshot = Snapshot(id=uuid.uuid4(), repository_id=repo.id, status=SNAPSHOT_RUNNING,
                                stats={})
            session.add(snapshot)
            repo_id, snapshot_id = repo.id, snapshot.id

        try:
            stats = self._build_and_commit(repo_id, snapshot_id, previous_id, discovery.files)
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"[:2000]
            log.error("indexing failed for %s: %s", repo_name, message)
            with session_scope(self._factory) as session:
                session.execute(
                    update(Snapshot).where(Snapshot.id == snapshot_id)
                    .values(status=SNAPSHOT_FAILED, finished_at=datetime.now(UTC), error=message)
                )
            if isinstance(exc, TraceLensError):
                raise
            raise IndexingFailedError(
                "indexing failed; the snapshot was marked FAILED and the previous index (if any) "
                "remains active. See the repository status endpoint for the error."
            ) from exc
        stats["changes"] = {k: len(v) for k, v in change.items()}
        stats["skipped_files"] = len(discovery.skipped)
        stats["duration_seconds"] = round(time.perf_counter() - started, 3)
        with session_scope(self._factory) as session:
            snap = session.get(Snapshot, snapshot_id)
            snap.stats = stats
        return IndexResult(repo_id, snapshot_id, False, stats, discovery.skipped)

    def _lock_repo(self, session: Session, name: str, subdirectory: str) -> Repository:
        repo = session.execute(
            select(Repository).where(Repository.name == name).with_for_update()
        ).scalar_one_or_none()
        if repo is None:
            repo = Repository(id=uuid.uuid4(), name=name, subdirectory=subdirectory)
            session.add(repo)
            session.flush()
        elif repo.subdirectory != subdirectory:
            raise TraceLensError(
                f"repository '{name}' is already registered for a different subdirectory"
            )
        recover_stale_snapshots(session, repo.id, self._s.index_stale_after_minutes)
        running = session.execute(
            select(Snapshot.id).where(Snapshot.repository_id == repo.id,
                                      Snapshot.status == SNAPSHOT_RUNNING)
        ).first()
        if running is not None:
            raise IndexingInProgressError(
                "an indexing run for this repository is already in progress"
            )
        return repo

    @staticmethod
    def _previous_hashes(session: Session, snapshot_id: uuid.UUID | None) -> dict[str, str]:
        if snapshot_id is None:
            return {}
        rows = session.execute(
            select(IndexedFile.rel_path, IndexedFile.sha256).where(
                IndexedFile.snapshot_id == snapshot_id)
        ).all()
        return {p: h for p, h in rows}

    def _build_and_commit(self, repo_id: uuid.UUID, snapshot_id: uuid.UUID,
                          previous_id: uuid.UUID | None, files: list[SourceFile]) -> dict:
        s = self._s
        parsed: dict[str, ParsedFile | None] = {f.rel_path: _parse(f) for f in files}
        parsed_files = [p for p in parsed.values() if p is not None]
        edges = build_edges(parsed_files)
        drafts: dict[str, list[ChunkDraft]] = {
            f.rel_path: chunk_file(f, parsed[f.rel_path], s.max_chunk_lines, s.chunk_overlap_lines)
            for f in files
        }

        file_ids = {f.rel_path: uuid.uuid4() for f in files}
        symbol_rows: list[dict] = []
        sym_lookup: dict[tuple[str, str, int], uuid.UUID] = {}
        sym_by_name: dict[tuple[str, str], uuid.UUID] = {}
        id_by_sym: dict[uuid.UUID, uuid.UUID] = {}
        for pf in parsed_files:
            by_q = {sym.qualified_name: sym for sym in pf.symbols}
            for sym in pf.symbols:
                parent = by_q.get(sym.parent_qname) if sym.parent_qname else None
                symbol_rows.append(dict(
                    id=sym.id, snapshot_id=snapshot_id, file_id=file_ids[pf.rel_path],
                    parent_id=parent.id if parent else None, kind=sym.kind, name=sym.name,
                    qualified_name=sym.qualified_name, signature=sym.signature,
                    language=pf.language, start_line=sym.start_line, end_line=sym.end_line,
                    is_test=pf.is_test,
                ))
                sym_lookup[(pf.rel_path, sym.qualified_name, sym.start_line)] = sym.id
                sym_by_name.setdefault((pf.rel_path, sym.qualified_name), sym.id)
                id_by_sym[sym.id] = sym.id

        chunk_rows: list[dict] = []
        for f in files:
            for d in drafts[f.rel_path]:
                sid = None
                if d.symbol_qname:
                    sid = sym_lookup.get((f.rel_path, d.symbol_qname, d.start_line)) or \
                        sym_by_name.get((f.rel_path, d.symbol_qname))
                chunk_rows.append(dict(
                    id=uuid.uuid4(), snapshot_id=snapshot_id, file_id=file_ids[f.rel_path],
                    symbol_id=sid, kind=d.kind, symbol_name=d.symbol_name, language=f.language,
                    start_line=d.start_line, end_line=d.end_line, content=d.content,
                    content_sha=d.content_sha, search_text=d.search_text,
                    name_text=" ".join(search_tokens(d.symbol_name or PurePosixPath(f.rel_path).stem)),
                ))

        embeddings: list[tuple[uuid.UUID, list[float]]] = []
        reused = 0
        with session_scope(self._factory) as session:
            if self._embedder is not None and chunk_rows:
                cache = vector_store.reusable_embeddings(
                    session, previous_id, self._embedder.model_name)
                todo = [r for r in chunk_rows if r["content_sha"] not in cache]
                fresh: dict[str, list[float]] = {}
                if todo:
                    unique = {r["content_sha"]: r["content"] for r in todo}
                    keys = list(unique)
                    vectors = self._embedder.embed([unique[k] for k in keys])
                    validate_dimensions(vectors, s.embedding_dim)
                    fresh = dict(zip(keys, vectors, strict=True))
                for r in chunk_rows:
                    if r["content_sha"] in cache:
                        reused += 1
                        embeddings.append((r["id"], cache[r["content_sha"]]))
                    else:
                        embeddings.append((r["id"], fresh[r["content_sha"]]))

        with session_scope(self._factory) as session:
            if files:
                session.execute(IndexedFile.__table__.insert(), [dict(
                    id=file_ids[f.rel_path], snapshot_id=snapshot_id, rel_path=f.rel_path,
                    language=f.language, sha256=f.sha256, size_bytes=f.size_bytes,
                    line_count=f.line_count, is_test=f.is_test, content=f.content,
                    parse_error=getattr(parsed[f.rel_path], "error", None),
                ) for f in files])
            if symbol_rows:
                session.execute(Symbol.__table__.insert(), symbol_rows)
            file_id_by_path = file_ids
            if edges:
                session.execute(Edge.__table__.insert(), [dict(
                    id=uuid.uuid4(), snapshot_id=snapshot_id, edge_type=e.edge_type,
                    status=e.status, src_symbol_id=e.src_id, dst_symbol_id=e.dst_id,
                    dst_ref=e.dst_ref, file_id=file_id_by_path[e.rel_path], line=e.line,
                    evidence=e.evidence, note=e.note,
                ) for e in edges])
            if chunk_rows:
                session.execute(Chunk.__table__.insert(), chunk_rows)
            if embeddings and self._embedder is not None:
                vector_store.insert_embeddings(session, snapshot_id, self._embedder.model_name,
                                               embeddings)
            session.execute(
                update(Snapshot).where(Snapshot.id == snapshot_id)
                .values(status=SNAPSHOT_COMPLETED, finished_at=datetime.now(UTC))
            )
            session.execute(
                update(Repository).where(Repository.id == repo_id)
                .values(active_snapshot_id=snapshot_id)
            )
            # Retention: keep the new active snapshot and the one it replaced.
            keep = [snapshot_id] + ([previous_id] if previous_id else [])
            session.execute(
                delete(Snapshot).where(
                    Snapshot.repository_id == repo_id, Snapshot.status == SNAPSHOT_COMPLETED,
                    Snapshot.id.notin_(keep))
            )

        by_edge = Counter((e.edge_type, e.status) for e in edges)
        return {
            "files": len(files),
            "by_language": dict(Counter(f.language for f in files)),
            "symbols": len(symbol_rows),
            "edges": len(edges),
            "edges_by_type": dict(Counter(e.edge_type for e in edges)),
            "unresolved_edges": sum(n for (_t, st), n in by_edge.items() if st == "UNRESOLVED"),
            "chunks": len(chunk_rows),
            "embeddings": len(embeddings),
            "embeddings_reused": reused,
            "embeddings_enabled": self._embedder is not None,
            "parse_errors": sum(1 for p in parsed_files if p.error),
        }
