"""Read-side helpers for repository / snapshot status (shared by the API and CLI)."""

from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from tracelens.models import Chunk, Edge, IndexedFile, Repository, Snapshot, Symbol
from tracelens.retrieval import vector as vector_store
from tracelens.schemas.api import RepositoryOut, RepositoryStatus, SnapshotOut
from tracelens.snapshots import get_repository


def _snap(s: Snapshot | None) -> SnapshotOut | None:
    if s is None:
        return None
    return SnapshotOut(id=s.id, status=s.status, started_at=s.started_at,
                       finished_at=s.finished_at, error=s.error, stats=s.stats or {})


def repository_out(repo: Repository) -> RepositoryOut:
    return RepositoryOut(id=repo.id, name=repo.name, subdirectory=repo.subdirectory,
                         active_snapshot_id=repo.active_snapshot_id, created_at=repo.created_at)


def repository_status(session: Session, repository_id: uuid.UUID) -> RepositoryStatus:
    repo = get_repository(session, repository_id)
    active = session.get(Snapshot, repo.active_snapshot_id) if repo.active_snapshot_id else None
    latest = session.execute(
        select(Snapshot).where(Snapshot.repository_id == repo.id)
        .order_by(Snapshot.started_at.desc()).limit(1)
    ).scalar_one_or_none()
    counts: dict[str, int] = {}
    if active is not None:
        for label, model in (("files", IndexedFile), ("symbols", Symbol), ("edges", Edge),
                             ("chunks", Chunk)):
            counts[label] = session.execute(
                select(func.count()).select_from(model).where(model.snapshot_id == active.id)
            ).scalar_one()
    return RepositoryStatus(
        repository=repository_out(repo), active_snapshot=_snap(active), latest_snapshot=_snap(latest),
        counts=counts, embeddings_available=vector_store.table_exists(session))
