"""Domain errors. The API layer maps these to safe HTTP responses."""

from __future__ import annotations


class TraceLensError(Exception):
    status_code = 400
    code = "tracelens_error"

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class PathPolicyError(TraceLensError):
    status_code = 400
    code = "path_policy_violation"


class IndexLimitError(TraceLensError):
    status_code = 422
    code = "index_limit_exceeded"


class IndexingInProgressError(TraceLensError):
    status_code = 409
    code = "indexing_in_progress"


class IndexingFailedError(TraceLensError):
    status_code = 500
    code = "indexing_failed"


class NotFoundError(TraceLensError):
    status_code = 404
    code = "not_found"


class NoActiveSnapshotError(TraceLensError):
    status_code = 409
    code = "no_active_snapshot"


class AmbiguousTargetError(TraceLensError):
    status_code = 422
    code = "ambiguous_target"


class VectorUnavailableError(TraceLensError):
    status_code = 503
    code = "vector_search_unavailable"


class EmbeddingError(TraceLensError):
    status_code = 503
    code = "embedding_error"


class LLMError(TraceLensError):
    status_code = 502
    code = "llm_error"
