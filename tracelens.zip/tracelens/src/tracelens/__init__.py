"""TraceLens: hybrid RAG + static analysis + optional GenAI change-impact engine."""

__version__ = "0.1.0"
