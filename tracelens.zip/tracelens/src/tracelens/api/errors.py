"""Uniform, safe error envelope: {"error": {"code": ..., "message": ...}}. No stack traces."""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from tracelens.errors import TraceLensError

log = logging.getLogger(__name__)


def _envelope(code: str, message: str, status: int, extra: dict | None = None) -> JSONResponse:
    body: dict = {"error": {"code": code, "message": message}}
    if extra:
        body["error"].update(extra)
    return JSONResponse(status_code=status, content=body)


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(TraceLensError)
    async def _domain(_: Request, exc: TraceLensError) -> JSONResponse:
        return _envelope(exc.code, exc.message, exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError) -> JSONResponse:
        details = [
            {"location": ".".join(str(p) for p in e["loc"]), "message": e["msg"]}
            for e in exc.errors()
        ]
        return _envelope("validation_error", "request validation failed", 422,
                         {"details": details})

    @app.exception_handler(Exception)
    async def _unexpected(_: Request, exc: Exception) -> JSONResponse:
        log.exception("unhandled error")
        return _envelope("internal_error", "internal server error", 500)
