"""FastAPI dependencies. Shared objects live on ``app.state`` (no module-level globals)."""

from __future__ import annotations

from collections.abc import Iterator

from fastapi import Request
from sqlalchemy.orm import Session

from tracelens.config import Settings
from tracelens.indexing.service import Indexer
from tracelens.llm.provider import LLMProvider
from tracelens.retrieval.embeddings import Embedder


def get_settings_dep(request: Request) -> Settings:
    return request.app.state.settings


def get_session(request: Request) -> Iterator[Session]:
    session: Session = request.app.state.session_factory()
    try:
        yield session
        session.commit()
    except BaseException:
        session.rollback()
        raise
    finally:
        session.close()


def get_embedder(request: Request) -> Embedder | None:
    return request.app.state.embedder


def get_llm_provider(request: Request) -> LLMProvider | None:
    return request.app.state.llm_provider


def get_indexer(request: Request) -> Indexer:
    state = request.app.state
    return Indexer(state.session_factory, state.settings, state.embedder)
