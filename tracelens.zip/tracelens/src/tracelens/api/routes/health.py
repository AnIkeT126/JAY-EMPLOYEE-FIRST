from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from tracelens import __version__
from tracelens.api.dependencies import get_session, get_settings_dep
from tracelens.config import Settings
from tracelens.database.migration_state import migration_state
from tracelens.retrieval import vector as vector_store

router = APIRouter()
log = logging.getLogger(__name__)


@router.get("/health/live", tags=["health"])
def live() -> dict:
    return {"status": "ok"}


@router.get("/health/ready", tags=["health"])
def ready(request: Request, session: Session = Depends(get_session),
          settings: Settings = Depends(get_settings_dep)) -> JSONResponse:
    checks: dict[str, object] = {}
    ok = True
    try:
        session.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception:
        log.exception("readiness: database check failed")
        return JSONResponse(status_code=503, content={"status": "unavailable",
                                                      "checks": {"database": "unreachable"}})
    try:
        state = migration_state(request.app.state.engine, settings.embeddings_enabled)
        checks["migrations"] = "ok" if state.up_to_date else (
            f"not up to date (current={state.current}, required={state.required}); "
            "run `alembic upgrade head`")
        ok = ok and state.up_to_date
    except Exception:
        log.exception("readiness: migration check failed")
        checks["migrations"] = "unknown"
        ok = False
    checks["vector_search"] = "available" if (
        settings.embeddings_enabled and vector_store.table_exists(session)) else "unavailable"
    return JSONResponse(status_code=200 if ok else 503,
                        content={"status": "ready" if ok else "not_ready", "checks": checks})


@router.get("/api/v1/system/info", tags=["system"])
def system_info(settings: Settings = Depends(get_settings_dep)) -> dict:
    return {
        "name": "tracelens",
        "version": __version__,
        "environment": settings.environment,
        "repository_root_name": settings.repository_base.name,
        "supported_languages": ["python", "java", "markdown"],
        "embeddings": {
            "enabled": settings.embeddings_enabled,
            "provider": settings.embedding_provider,
            "model": settings.embedding_model,
            "dimension": settings.embedding_dim,
            "distance": "cosine",
        },
        "llm": {"enabled": settings.llm_enabled, "provider": settings.llm_provider,
                "model": settings.llm_model or None},
        "limits": {
            "max_file_bytes": settings.max_file_bytes, "max_files": settings.max_files,
            "max_query_chars": settings.max_query_chars, "max_top_k": settings.max_top_k,
            "max_trace_depth": settings.max_trace_depth,
            "max_tool_calls": settings.max_tool_calls,
        },
        "retrieval": {"rrf_k": settings.rrf_k, "keyword_candidates": settings.keyword_candidates,
                      "vector_candidates": settings.vector_candidates,
                      "default_top_k": settings.default_top_k},
    }
