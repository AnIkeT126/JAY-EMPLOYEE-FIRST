from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from tracelens.api.dependencies import (
    get_embedder,
    get_llm_provider,
    get_session,
    get_settings_dep,
)
from tracelens.config import Settings
from tracelens.errors import NotFoundError
from tracelens.impact.analyzer import ImpactAnalyzer
from tracelens.llm.agent import ImpactNarrator
from tracelens.llm.provider import LLMProvider
from tracelens.models import ImpactAnalysis
from tracelens.retrieval.embeddings import Embedder
from tracelens.retrieval.service import SearchService
from tracelens.schemas.impact import ImpactReport, ImpactRequest

router = APIRouter(prefix="/api/v1/impact", tags=["impact"])


@router.post("/analyze", response_model=ImpactReport)
def analyze(body: ImpactRequest, session: Session = Depends(get_session),
            settings: Settings = Depends(get_settings_dep),
            embedder: Embedder | None = Depends(get_embedder),
            provider: LLMProvider | None = Depends(get_llm_provider)) -> ImpactReport:
    narrator = (
        ImpactNarrator(provider, session, settings, SearchService(session, settings, embedder))
        if provider is not None else None
    )
    return ImpactAnalyzer(session, settings, embedder, narrator).analyze(body)


@router.get("/analyses/{analysis_id}", response_model=ImpactReport)
def get_analysis(analysis_id: uuid.UUID, session: Session = Depends(get_session)) -> ImpactReport:
    row = session.get(ImpactAnalysis, analysis_id)
    if row is None:
        raise NotFoundError("analysis not found")
    return ImpactReport.model_validate(row.report)
