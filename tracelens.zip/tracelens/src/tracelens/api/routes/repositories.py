from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from tracelens.api.dependencies import get_indexer, get_session
from tracelens.indexing.service import Indexer, IndexResult
from tracelens.indexing.status import repository_out, repository_status
from tracelens.models import Repository
from tracelens.schemas.api import (
    IndexRequest,
    IndexResponse,
    ReindexRequest,
    RepositoryOut,
    RepositoryStatus,
)

router = APIRouter(prefix="/api/v1/repositories", tags=["repositories"])


def _response(result: IndexResult) -> IndexResponse:
    return IndexResponse(
        repository_id=result.repository_id, snapshot_id=result.snapshot_id,
        unchanged=result.unchanged, stats=result.stats,
        skipped_files=[{"path": p, "reason": r} for p, r in result.skipped[:200]])


@router.post("/index", response_model=IndexResponse)
def index_repository(body: IndexRequest, indexer: Indexer = Depends(get_indexer)) -> IndexResponse:
    return _response(indexer.index(body.name, body.subdirectory, body.force))


@router.get("", response_model=list[RepositoryOut])
def list_repositories(session: Session = Depends(get_session)) -> list[RepositoryOut]:
    repos = session.execute(select(Repository).order_by(Repository.name)).scalars().all()
    return [repository_out(r) for r in repos]


@router.get("/{repository_id}/status", response_model=RepositoryStatus)
def status(repository_id: uuid.UUID, session: Session = Depends(get_session)) -> RepositoryStatus:
    return repository_status(session, repository_id)


@router.post("/{repository_id}/reindex", response_model=IndexResponse)
def reindex(repository_id: uuid.UUID, body: ReindexRequest | None = None,
            indexer: Indexer = Depends(get_indexer)) -> IndexResponse:
    return _response(indexer.reindex(repository_id, (body or ReindexRequest()).force))
