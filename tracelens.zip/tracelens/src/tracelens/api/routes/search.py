from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from tracelens.analysis import dependency_graph as dg
from tracelens.api.dependencies import get_embedder, get_session, get_settings_dep
from tracelens.config import Settings
from tracelens.errors import TraceLensError
from tracelens.retrieval.citations import make_citation
from tracelens.retrieval.embeddings import Embedder
from tracelens.retrieval.service import SearchService
from tracelens.schemas.api import (
    SearchHitOut,
    SearchRequest,
    SearchResponse,
    TraceEdgeOut,
    TraceRequest,
    TraceResponse,
    TraceStepOut,
)
from tracelens.schemas.impact import CitationOut
from tracelens.snapshots import require_active_snapshot

router = APIRouter(prefix="/api/v1", tags=["retrieval"])


def _cite(snapshot_id, path: str, start: int, end: int) -> CitationOut:
    c = make_citation(snapshot_id, path, start, end)
    return CitationOut(id=c.id, path=c.path, start_line=c.start_line, end_line=c.end_line,
                       snapshot_id=c.snapshot_id)


@router.post("/search", response_model=SearchResponse)
def search(body: SearchRequest, session: Session = Depends(get_session),
           settings: Settings = Depends(get_settings_dep),
           embedder: Embedder | None = Depends(get_embedder)) -> SearchResponse:
    if len(body.query) > settings.max_query_chars:
        raise TraceLensError(f"query longer than {settings.max_query_chars} characters")
    if body.top_k is not None and body.top_k > settings.max_top_k:
        raise TraceLensError(f"top_k must be <= {settings.max_top_k}")
    _, snapshot_id = require_active_snapshot(session, body.repository_id)
    outcome = SearchService(session, settings, embedder).search(
        snapshot_id, body.query, mode=body.mode, top_k=body.top_k, language=body.language,
        path_prefix=body.path_prefix)
    hits = [
        SearchHitOut(
            file_path=h.file_path, symbol_name=h.symbol_name, kind=h.kind, language=h.language,
            start_line=h.start_line, end_line=h.end_line, content=h.content,
            snapshot_id=h.snapshot_id, keyword_rank=h.keyword_rank, keyword_score=h.keyword_score,
            vector_rank=h.vector_rank, vector_score=h.vector_score,
            fusion_score=h.fusion_score, final_rank=h.final_rank,
            citation=CitationOut(id=h.citation.id, path=h.citation.path,
                                 start_line=h.citation.start_line, end_line=h.citation.end_line,
                                 snapshot_id=h.citation.snapshot_id))
        for h in outcome.hits
    ]
    return SearchResponse(mode_requested=outcome.mode_requested, mode_used=outcome.mode_used,
                          warnings=outcome.warnings, hits=hits)


@router.post("/dependencies/trace", response_model=TraceResponse)
def trace_dependencies(body: TraceRequest, session: Session = Depends(get_session),
                       settings: Settings = Depends(get_settings_dep)) -> TraceResponse:
    _, snapshot_id = require_active_snapshot(session, body.repository_id)
    targets = dg.resolve_target(session, snapshot_id, symbol=body.symbol, file=body.file)
    depth = min(body.max_depth or settings.max_trace_depth, 8)
    result = dg.trace(session, snapshot_id, [t.id for t in targets], body.direction, depth,
                      settings.trace_node_limit)

    def edge_out(e: dg.EdgeInfo) -> TraceEdgeOut:
        return TraceEdgeOut(edge_type=e.edge_type, file_path=e.file_path, line=e.line,
                            snippet=e.evidence, note=e.note,
                            citation=_cite(snapshot_id, e.file_path, e.line, e.line))

    steps = [
        TraceStepOut(symbol=st.symbol.qualified_name, kind=st.symbol.kind,
                     file_path=st.symbol.file_path, start_line=st.symbol.start_line,
                     end_line=st.symbol.end_line, depth=st.depth, is_test=st.symbol.is_test,
                     path=[edge_out(e) for e in st.path])
        for st in result.steps
    ]
    unresolved = dg.unresolved_edges(
        session, snapshot_id, src_ids=[t.id for t in targets],
        name_hints=[t.name for t in targets if t.kind not in {"module", "file"}])
    return TraceResponse(snapshot_id=snapshot_id, direction=body.direction,
                         targets=[t.qualified_name for t in targets], steps=steps,
                         truncated=result.truncated, unresolved=[edge_out(e) for e in unresolved])
