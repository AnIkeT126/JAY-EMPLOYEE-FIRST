"""Helpers that resolve the active (completed, consistent) snapshot of a repository."""

from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from tracelens.errors import NoActiveSnapshotError, NotFoundError
from tracelens.models import Repository


def get_repository(session: Session, repository_id: uuid.UUID) -> Repository:
    repo = session.get(Repository, repository_id)
    if repo is None:
        raise NotFoundError("repository not found")
    return repo


def require_active_snapshot(session: Session, repository_id: uuid.UUID) -> tuple[Repository, uuid.UUID]:
    repo = get_repository(session, repository_id)
    if repo.active_snapshot_id is None:
        raise NoActiveSnapshotError(
            "repository has no completed snapshot; run indexing and check its status"
        )
    return repo, repo.active_snapshot_id
