"""Centralised, validated application settings (environment / .env driven)."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# src/tracelens/config.py -> project root is three levels up from this file.
PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _csv(value: str) -> list[str]:
    return [part.strip() for part in value.split(",") if part.strip()]


class Settings(BaseSettings):
    """All settings use the ``TRACELENS_`` environment prefix. See docs/CONFIGURATION.md."""

    model_config = SettingsConfigDict(
        env_prefix="TRACELENS_", env_file=".env", extra="ignore", frozen=True
    )

    environment: Literal["development", "test", "production"] = "development"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    api_host: str = "127.0.0.1"
    api_port: int = Field(8000, ge=1, le=65535)

    database_url: str = "postgresql+psycopg2://tracelens:tracelens@localhost:5432/tracelens"

    # Base directory that all indexed repositories must live under. Relative paths are
    # resolved against the project root, never against the caller's working directory.
    repository_root: Path = Path("demo/sample_repository")
    max_file_bytes: int = Field(500_000, ge=1_000)
    max_files: int = Field(5_000, ge=1)
    ignored_dirs: str = (
        ".git,.hg,.svn,.venv,venv,env,node_modules,build,dist,target,out,__pycache__,"
        ".mypy_cache,.pytest_cache,.ruff_cache,.idea,.vscode,.gradle,.tox"
    )
    ignored_patterns: str = "*.min.*,*_pb2.py,*.generated.*"
    max_chunk_lines: int = Field(120, ge=10)
    chunk_overlap_lines: int = Field(10, ge=0)
    index_stale_after_minutes: int = Field(30, ge=1)

    embeddings_enabled: bool = True
    embedding_provider: Literal["sentence-transformers"] = "sentence-transformers"
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_dim: int = Field(384, ge=8, le=4096)
    embedding_local_files_only: bool = False
    embedding_batch_size: int = Field(32, ge=1, le=512)

    llm_provider: Literal["none", "openai-compatible"] = "none"
    llm_model: str = ""
    llm_base_url: str = ""
    llm_api_key: SecretStr | None = None
    llm_timeout_seconds: float = Field(30.0, gt=0, le=300)
    max_tool_calls: int = Field(6, ge=0, le=20)
    llm_max_context_chars: int = Field(20_000, ge=1_000)

    keyword_candidates: int = Field(50, ge=1, le=500)
    vector_candidates: int = Field(50, ge=1, le=500)
    default_top_k: int = Field(10, ge=1)
    max_top_k: int = Field(50, ge=1)
    rrf_k: int = Field(60, ge=1)
    max_query_chars: int = Field(1_000, ge=10)
    max_trace_depth: int = Field(3, ge=1, le=8)
    trace_node_limit: int = Field(500, ge=10)

    eval_dataset_path: Path = Path("data/evaluation/cases.json")
    eval_output_dir: Path = Path("reports")

    @model_validator(mode="after")
    def _cross_field_checks(self) -> Settings:
        if self.default_top_k > self.max_top_k:
            raise ValueError("TRACELENS_DEFAULT_TOP_K must be <= TRACELENS_MAX_TOP_K")
        if self.chunk_overlap_lines >= self.max_chunk_lines:
            raise ValueError("TRACELENS_CHUNK_OVERLAP_LINES must be < TRACELENS_MAX_CHUNK_LINES")
        if self.llm_provider != "none" and not (self.llm_model and self.llm_base_url):
            raise ValueError(
                "TRACELENS_LLM_MODEL and TRACELENS_LLM_BASE_URL are required when "
                "TRACELENS_LLM_PROVIDER is not 'none'"
            )
        return self

    @property
    def ignored_dir_list(self) -> list[str]:
        return _csv(self.ignored_dirs)

    @property
    def ignored_pattern_list(self) -> list[str]:
        return _csv(self.ignored_patterns)

    @property
    def repository_base(self) -> Path:
        path = self.repository_root
        return (path if path.is_absolute() else PROJECT_ROOT / path).resolve()

    @property
    def dataset_path(self) -> Path:
        path = self.eval_dataset_path
        return path if path.is_absolute() else PROJECT_ROOT / path

    @property
    def output_dir(self) -> Path:
        path = self.eval_output_dir
        return path if path.is_absolute() else PROJECT_ROOT / path

    @property
    def llm_enabled(self) -> bool:
        return self.llm_provider != "none"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
