"""Request/response schemas for the REST API (impact schemas live in schemas/impact.py)."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from tracelens.schemas.impact import CitationOut


class IndexRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(None, min_length=1, max_length=200, pattern=r"^[A-Za-z0-9._-]+$")
    subdirectory: str = Field(
        "", max_length=300,
        description="Directory relative to TRACELENS_REPOSITORY_ROOT. Absolute paths and '..' "
                    "are rejected.")
    force: bool = Field(False, description="Create a new snapshot even if no file changed.")


class ReindexRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    force: bool = False


class IndexResponse(BaseModel):
    repository_id: uuid.UUID
    snapshot_id: uuid.UUID
    unchanged: bool
    stats: dict
    skipped_files: list[dict]


class SnapshotOut(BaseModel):
    id: uuid.UUID
    status: str
    started_at: datetime
    finished_at: datetime | None
    error: str | None
    stats: dict


class RepositoryOut(BaseModel):
    id: uuid.UUID
    name: str
    subdirectory: str
    active_snapshot_id: uuid.UUID | None
    created_at: datetime


class RepositoryStatus(BaseModel):
    repository: RepositoryOut
    active_snapshot: SnapshotOut | None
    latest_snapshot: SnapshotOut | None
    counts: dict[str, int]
    embeddings_available: bool


class SearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repository_id: uuid.UUID
    query: str = Field(..., min_length=1)
    mode: Literal["keyword", "vector", "hybrid"] = "hybrid"
    top_k: int | None = Field(None, ge=1)
    language: Literal["python", "java", "markdown"] | None = None
    path_prefix: str | None = Field(None, max_length=500)


class SearchHitOut(BaseModel):
    file_path: str
    symbol_name: str | None
    kind: str
    language: str
    start_line: int
    end_line: int
    content: str
    snapshot_id: uuid.UUID
    keyword_rank: int | None
    keyword_score: float | None
    vector_rank: int | None
    vector_score: float | None
    fusion_score: float
    final_rank: int
    citation: CitationOut


class SearchResponse(BaseModel):
    mode_requested: str
    mode_used: str
    warnings: list[str]
    hits: list[SearchHitOut]


class TraceRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repository_id: uuid.UUID
    symbol: str | None = Field(None, max_length=500)
    file: str | None = Field(None, max_length=500)
    direction: Literal["upstream", "downstream"] = "upstream"
    max_depth: int | None = Field(None, ge=1, le=8)


class TraceEdgeOut(BaseModel):
    edge_type: str
    file_path: str
    line: int
    snippet: str
    note: str | None
    citation: CitationOut


class TraceStepOut(BaseModel):
    symbol: str
    kind: str
    file_path: str
    start_line: int
    end_line: int
    depth: int
    is_test: bool
    path: list[TraceEdgeOut]


class TraceResponse(BaseModel):
    snapshot_id: uuid.UUID
    direction: str
    targets: list[str]
    steps: list[TraceStepOut]
    truncated: bool
    unresolved: list[TraceEdgeOut]


class ErrorBody(BaseModel):
    code: str
    message: str


class ErrorResponse(BaseModel):
    error: ErrorBody
