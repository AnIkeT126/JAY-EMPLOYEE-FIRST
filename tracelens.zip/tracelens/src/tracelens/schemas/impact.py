"""Request/response schemas for impact analysis (also used as the persisted report format)."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Confidence = Literal["high", "medium", "low"]


class CitationOut(BaseModel):
    id: str
    path: str
    start_line: int
    end_line: int
    snapshot_id: str


class ImpactRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repository_id: uuid.UUID
    target_file: str | None = Field(
        None, max_length=500, description="Repository-relative path of the file being changed."
    )
    target_symbol: str | None = Field(
        None, max_length=500, description="Qualified or simple name of the symbol being changed."
    )
    change_description: str = Field(..., min_length=3, max_length=2000)
    max_depth: int | None = Field(None, ge=1, le=8)
    use_llm: bool = False
    semantic_top_k: int = Field(8, ge=1, le=30)

    @model_validator(mode="after")
    def _needs_target(self) -> ImpactRequest:
        if not (self.target_file or self.target_symbol):
            raise ValueError("provide target_file and/or target_symbol")
        return self


class Evidence(BaseModel):
    kind: Literal["static_edge"] = "static_edge"
    relationship: str
    description: str
    snippet: str
    citation: CitationOut
    note: str | None = None


class TargetInfo(BaseModel):
    symbol: str
    kind: str
    file_path: str
    citation: CitationOut


class AffectedComponent(BaseModel):
    symbol: str
    name: str
    kind: str
    file_path: str
    start_line: int
    end_line: int
    relationship: str = Field(..., description="Edge type closest to the target.")
    depth: int
    evidence_kind: Literal["direct_static", "indirect_static"]
    confidence: Confidence
    confidence_reason: str
    evidence: list[Evidence]


class RelatedTest(AffectedComponent):
    pass


class SemanticCandidate(BaseModel):
    """Found by retrieval only. NOT a confirmed dependency."""

    evidence_kind: Literal["semantic"] = "semantic"
    confidence: Literal["low"] = "low"
    file_path: str
    symbol_name: str | None
    snippet: str
    citation: CitationOut
    fusion_score: float
    keyword_rank: int | None
    vector_rank: int | None
    note: str = "Semantic similarity only; verify manually before treating as a dependency."


class RelatedDoc(BaseModel):
    file_path: str
    heading: str | None
    match: Literal["mentions_target", "semantic"]
    snippet: str
    citation: CitationOut


class UnresolvedRelationship(BaseModel):
    direction: Literal["from_target", "possible_reference_to_target"]
    edge_type: str
    file_path: str
    line: int
    reference: str
    reason: str
    snippet: str
    citation: CitationOut


class ImpactReport(BaseModel):
    analysis_id: uuid.UUID
    repository_id: uuid.UUID
    repository_name: str
    snapshot_id: uuid.UUID
    target_file: str | None
    target_symbol: str | None
    resolved_targets: list[TargetInfo]
    change_description: str
    max_depth: int
    affected_components: list[AffectedComponent]
    related_tests: list[RelatedTest]
    semantic_candidates: list[SemanticCandidate]
    related_documentation: list[RelatedDoc]
    unresolved_relationships: list[UnresolvedRelationship]
    missing_information: list[str]
    limitations: list[str]
    warnings: list[str] = Field(default_factory=list)
    generated_by: Literal["deterministic", "llm+deterministic"] = "deterministic"
    llm_summary: str | None = None
    llm_notes: list[str] = Field(default_factory=list)
    duration_ms: float
    created_at: datetime
