"""Command-line interface: ``tracelens doctor|index|status|search|analyze|eval|report|serve``."""

from __future__ import annotations

import json
import sys
import uuid
from pathlib import Path

import typer
from pydantic import ValidationError
from sqlalchemy import select, text

from tracelens import __version__
from tracelens.config import Settings, get_settings
from tracelens.database.session import make_engine, make_session_factory, session_scope
from tracelens.errors import TraceLensError
from tracelens.models import ImpactAnalysis, Repository

app = typer.Typer(add_completion=False, no_args_is_help=True,
                  help="TraceLens: hybrid RAG + static analysis change-impact engine.")

OK, WARN, FAIL = "OK  ", "WARN", "FAIL"


def _settings() -> Settings:
    try:
        return get_settings()
    except ValidationError as exc:
        typer.echo("Invalid configuration (see docs/CONFIGURATION.md):", err=True)
        for err in exc.errors():
            loc = ".".join(str(p) for p in err["loc"]) or "settings"
            typer.echo(f"  - {loc}: {err['msg']}", err=True)
        raise typer.Exit(2) from exc


def _fail(exc: Exception) -> typer.Exit:
    message = exc.message if isinstance(exc, TraceLensError) else f"{type(exc).__name__}: {exc}"
    typer.echo(f"error: {message}", err=True)
    return typer.Exit(1)


def _repo_by_name(session, name: str) -> Repository:
    repo = session.execute(select(Repository).where(Repository.name == name)).scalar_one_or_none()
    if repo is None:
        raise TraceLensError(f"repository '{name}' is not indexed; run `tracelens index`")
    return repo


@app.command()
def version() -> None:
    """Print the TraceLens version."""
    typer.echo(__version__)


@app.command()
def doctor() -> None:
    """Validate prerequisites: config, database, migrations, pgvector, embedding model, parsers."""
    problems = 0

    def report(level: str, label: str, detail: str) -> None:
        nonlocal problems
        if level == FAIL:
            problems += 1
        typer.echo(f"[{level}] {label}: {detail}")

    report(OK, "python", sys.version.split()[0])  # >= 3.11 is enforced by the package metadata
    settings = _settings()
    report(OK, "configuration", f"environment={settings.environment}")
    base = settings.repository_base
    if base.is_dir():
        report(OK, "repository root", f"'{base.name}' exists")
    else:
        report(FAIL, "repository root", f"'{base.name}' is not a directory (TRACELENS_REPOSITORY_ROOT)")

    try:
        from tracelens.analysis.java_parser import parse_java

        parse_java("class A { void m() {} }", "A.java", False)
        report(OK, "java parser", "tree-sitter-java works")
    except Exception as exc:
        report(FAIL, "java parser", f"{type(exc).__name__}: {exc}")

    engine = make_engine(settings.database_url)
    db_ok = False
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        db_ok = True
        report(OK, "database", "connection succeeded")
    except Exception as exc:
        report(FAIL, "database", f"cannot connect ({type(exc).__name__}); check TRACELENS_DATABASE_URL "
                                 "and that PostgreSQL is running")
    if db_ok:
        from tracelens.database.migration_state import migration_state
        from tracelens.retrieval import vector as vector_store

        try:
            state = migration_state(engine, settings.embeddings_enabled)
            if state.up_to_date:
                report(OK, "migrations", f"at {state.current} (required {state.required}, head {state.head})")
            else:
                report(FAIL, "migrations", f"current={state.current} required={state.required}; "
                                           "run `alembic upgrade head`")
        except Exception as exc:
            report(FAIL, "migrations", f"{type(exc).__name__}")
        factory = make_session_factory(engine)
        with factory() as session:
            if settings.embeddings_enabled:
                if vector_store.table_exists(session):
                    dim = vector_store.stored_dimension(session)
                    if dim == settings.embedding_dim:
                        report(OK, "pgvector", f"chunk_embeddings present, dimension {dim}")
                    else:
                        report(FAIL, "pgvector", f"stored dimension {dim} != "
                                                 f"TRACELENS_EMBEDDING_DIM={settings.embedding_dim}")
                else:
                    report(FAIL, "pgvector", "chunk_embeddings missing (migration 0002 needs the "
                                             "pgvector extension)")
            else:
                report(WARN, "pgvector", "embeddings disabled; vector/hybrid search unavailable")
    engine.dispose()

    if settings.embeddings_enabled:
        try:
            from huggingface_hub import try_to_load_from_cache

            cached = try_to_load_from_cache(settings.embedding_model, "modules.json")
            if isinstance(cached, str):
                report(OK, "embedding model", f"{settings.embedding_model} is in the local cache")
            elif settings.embedding_local_files_only:
                report(FAIL, "embedding model", "not cached and TRACELENS_EMBEDDING_LOCAL_FILES_ONLY"
                                                "=true; pre-populate the Hugging Face cache")
            else:
                report(WARN, "embedding model", "not cached; the first index/search downloads it "
                                                "(needs network access to huggingface.co)")
        except Exception as exc:
            report(WARN, "embedding model", f"cache check unavailable ({type(exc).__name__})")
    if settings.llm_enabled:
        report(OK, "llm", f"provider={settings.llm_provider} model={settings.llm_model} "
                          "(connectivity is not tested)")
    else:
        report(OK, "llm", "disabled (deterministic mode)")
    typer.echo("doctor: all required checks passed" if not problems
               else f"doctor: {problems} check(s) failed")
    raise typer.Exit(1 if problems else 0)


@app.command()
def index(
    path: str = typer.Option("", "--path", help="Subdirectory of TRACELENS_REPOSITORY_ROOT."),
    name: str = typer.Option(None, "--name", help="Repository name (default: directory name)."),
    force: bool = typer.Option(False, "--force", help="Re-index even if nothing changed."),
) -> None:
    """Index the configured repository root (the synthetic demo by default)."""
    from tracelens.indexing.service import Indexer
    from tracelens.retrieval.embeddings import build_embedder

    settings = _settings()
    engine = make_engine(settings.database_url)
    try:
        result = Indexer(make_session_factory(engine), settings, build_embedder(settings)).index(
            name, path, force)
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()
    typer.echo(f"repository_id: {result.repository_id}")
    typer.echo(f"snapshot_id:   {result.snapshot_id}")
    typer.echo("result:        " + ("unchanged (no new snapshot)" if result.unchanged else "indexed"))
    typer.echo(json.dumps(result.stats, indent=2))
    if result.skipped:
        typer.echo(f"skipped files: {len(result.skipped)} (first: {result.skipped[0]})")


@app.command()
def status(repository: str = typer.Option(None, "--repository", "-r")) -> None:
    """Show repositories and their active snapshots."""
    from tracelens.indexing.status import repository_status

    settings = _settings()
    engine = make_engine(settings.database_url)
    try:
        with session_scope(make_session_factory(engine)) as session:
            repos = session.execute(select(Repository).order_by(Repository.name)).scalars().all()
            if repository:
                repos = [r for r in repos if r.name == repository]
            if not repos:
                typer.echo("no repositories indexed")
            for repo in repos:
                st = repository_status(session, repo.id)
                snap = st.active_snapshot
                typer.echo(f"{repo.name}  id={repo.id}")
                typer.echo(f"  active snapshot: {snap.id if snap else 'none'}  counts={st.counts}")
                latest = st.latest_snapshot
                if latest and (not snap or latest.id != snap.id):
                    typer.echo(f"  latest snapshot: {latest.id} status={latest.status} "
                               f"error={latest.error}")
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()


@app.command()
def search(query: str, repository: str = typer.Option(..., "--repository", "-r"),
           mode: str = typer.Option("hybrid", "--mode"), top_k: int = typer.Option(5, "--top-k")) -> None:
    """Search the active snapshot of a repository."""
    from tracelens.retrieval.embeddings import build_embedder
    from tracelens.retrieval.service import SearchService
    from tracelens.snapshots import require_active_snapshot

    if mode not in {"keyword", "vector", "hybrid"}:
        typer.echo("error: --mode must be keyword, vector or hybrid", err=True)
        raise typer.Exit(2)
    settings = _settings()
    engine = make_engine(settings.database_url)
    try:
        with session_scope(make_session_factory(engine)) as session:
            repo = _repo_by_name(session, repository)
            _, snap = require_active_snapshot(session, repo.id)
            outcome = SearchService(session, settings, build_embedder(settings)).search(
                snap, query, mode=mode, top_k=top_k)  # type: ignore[arg-type]
            for w in outcome.warnings:
                typer.echo(f"warning: {w}", err=True)
            for h in outcome.hits:
                typer.echo(f"{h.final_rank:>2}. {h.citation.id}  {h.symbol_name or ''}  "
                           f"rrf={h.fusion_score:.4f} kw={h.keyword_rank} vec={h.vector_rank}")
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()


@app.command()
def analyze(
    repository: str = typer.Option(..., "--repository", "-r"),
    change: str = typer.Option(..., "--change", help="Description of the proposed change."),
    symbol: str = typer.Option(None, "--symbol"), file: str = typer.Option(None, "--file"),
    depth: int = typer.Option(None, "--depth"), use_llm: bool = typer.Option(False, "--llm"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Run a change-impact analysis and print the report."""
    from tracelens.impact.analyzer import ImpactAnalyzer
    from tracelens.impact.render import render_markdown
    from tracelens.llm.agent import ImpactNarrator
    from tracelens.llm.provider import build_provider
    from tracelens.retrieval.embeddings import build_embedder
    from tracelens.retrieval.service import SearchService
    from tracelens.schemas.impact import ImpactRequest

    settings = _settings()
    engine = make_engine(settings.database_url)
    try:
        with session_scope(make_session_factory(engine)) as session:
            repo = _repo_by_name(session, repository)
            embedder = build_embedder(settings)
            provider = build_provider(settings)
            narrator = ImpactNarrator(provider, session, settings,
                                      SearchService(session, settings, embedder)) if provider else None
            request = ImpactRequest(repository_id=repo.id, target_file=file, target_symbol=symbol,
                                    change_description=change, max_depth=depth, use_llm=use_llm)
            result = ImpactAnalyzer(session, settings, embedder, narrator).analyze(request)
        typer.echo(result.model_dump_json(indent=2) if as_json else render_markdown(result))
    except ValidationError as exc:
        typer.echo(f"error: {exc.errors()[0]['msg']}", err=True)
        raise typer.Exit(2) from exc
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()


@app.command("eval")
def eval_command(k: int = typer.Option(10, "--k", min=1, max=50)) -> None:
    """Run the deterministic benchmark (index the demo repository first)."""
    from tracelens.evaluation.runner import render_markdown, run_evaluation, write_reports
    from tracelens.retrieval.embeddings import build_embedder

    settings = _settings()
    engine = make_engine(settings.database_url)
    try:
        result = run_evaluation(make_session_factory(engine), settings, build_embedder(settings),
                                settings.dataset_path, k)
        json_path, md_path = write_reports(result, settings.output_dir)
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()
    typer.echo(render_markdown(result))
    typer.echo(f"wrote {json_path.name} and {md_path.name} to {settings.output_dir.name}/")


@app.command()
def report(analysis_id: uuid.UUID,
           fmt: str = typer.Option("md", "--format", help="md or json"),
           output: Path = typer.Option(None, "--output", "-o", help="Write to a file.")) -> None:
    """Display or export a stored impact analysis."""
    from tracelens.impact.render import render_markdown
    from tracelens.schemas.impact import ImpactReport

    if fmt not in {"md", "json"}:
        typer.echo("error: --format must be md or json", err=True)
        raise typer.Exit(2)
    settings = _settings()
    engine = make_engine(settings.database_url)
    try:
        with session_scope(make_session_factory(engine)) as session:
            row = session.get(ImpactAnalysis, analysis_id)
            if row is None:
                raise TraceLensError("analysis not found")
            parsed = ImpactReport.model_validate(row.report)
        body = parsed.model_dump_json(indent=2) if fmt == "json" else render_markdown(parsed)
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()
    if output:
        output.write_text(body, encoding="utf-8")
        typer.echo(f"wrote {output}")
    else:
        typer.echo(body)


@app.command("db-reset")
def db_reset(yes: bool = typer.Option(False, "--yes", help="Confirm destroying all data.")) -> None:
    """DEVELOPMENT ONLY: drop and recreate the public schema (then run `alembic upgrade head`)."""
    settings = _settings()
    if settings.environment != "development":
        typer.echo("error: db-reset only runs when TRACELENS_ENVIRONMENT=development", err=True)
        raise typer.Exit(2)
    if not yes:
        typer.echo("refusing to reset: re-run with --yes to destroy ALL data in the configured "
                   "database", err=True)
        raise typer.Exit(2)
    engine = make_engine(settings.database_url)
    try:
        with engine.begin() as conn:
            conn.execute(text("DROP SCHEMA public CASCADE"))
            conn.execute(text("CREATE SCHEMA public"))
    except Exception as exc:
        raise _fail(exc) from exc
    finally:
        engine.dispose()
    typer.echo("schema reset; now run: alembic upgrade head")


@app.command()
def serve() -> None:
    """Run the API with uvicorn using TRACELENS_API_HOST / TRACELENS_API_PORT."""
    import uvicorn

    settings = _settings()
    uvicorn.run("tracelens.main:app", host=settings.api_host, port=settings.api_port)


if __name__ == "__main__":
    app()
