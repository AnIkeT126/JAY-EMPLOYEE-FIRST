"""Compare the database's Alembic revision with the code's head revision."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import text
from sqlalchemy.engine import Engine

from tracelens.config import PROJECT_ROOT


@dataclass(frozen=True)
class MigrationState:
    current: str | None
    head: str
    required: str  # head, or the last revision that does not need pgvector
    up_to_date: bool


def _script_directory() -> ScriptDirectory:
    cfg = Config(str(PROJECT_ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(Path(PROJECT_ROOT) / "migrations"))
    return ScriptDirectory.from_config(cfg)


def code_head() -> str:
    return _script_directory().get_current_head() or ""


def required_revision(require_vector: bool) -> str:
    """Newest revision that must be applied. Revisions flagged ``REQUIRES_PGVECTOR`` are
    optional when embeddings are disabled."""
    script = _script_directory()
    head = script.get_current_head() or ""
    if require_vector:
        return head
    for rev in script.walk_revisions():  # newest first
        if not getattr(rev.module, "REQUIRES_PGVECTOR", False):
            return rev.revision
    return head


def migration_state(engine: Engine, require_vector: bool = True) -> MigrationState:
    head = code_head()
    required = required_revision(require_vector)
    with engine.connect() as conn:
        exists = conn.execute(text("SELECT to_regclass('public.alembic_version')")).scalar()
        current = conn.execute(text("SELECT version_num FROM alembic_version")).scalar() \
            if exists else None
    return MigrationState(current=current, head=head, required=required,
                          up_to_date=current == required or current == head)
