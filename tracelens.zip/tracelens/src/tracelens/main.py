"""Application factory and ASGI entry point (``uvicorn tracelens.main:app``)."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from tracelens import __version__
from tracelens.api.errors import register_error_handlers
from tracelens.api.routes import health, impact, repositories, search
from tracelens.config import Settings, get_settings
from tracelens.database.session import make_engine, make_session_factory
from tracelens.llm.provider import build_provider
from tracelens.retrieval.embeddings import build_embedder


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()  # raises on invalid configuration at startup
    logging.basicConfig(level=settings.log_level,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        engine = make_engine(settings.database_url)
        app.state.settings = settings
        app.state.engine = engine
        app.state.session_factory = make_session_factory(engine)
        app.state.embedder = build_embedder(settings)
        app.state.llm_provider = build_provider(settings)
        yield
        engine.dispose()

    app = FastAPI(
        title="TraceLens", version=__version__, lifespan=lifespan,
        description="Hybrid RAG + static analysis change-impact engine.",
    )
    register_error_handlers(app)
    for router in (health.router, repositories.router, search.router, impact.router):
        app.include_router(router)
    return app


app = create_app()
