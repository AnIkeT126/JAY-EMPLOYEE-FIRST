"""Reciprocal Rank Fusion: score(d) = sum over lists of 1 / (k + rank_in_list(d))."""

from __future__ import annotations

from tracelens.retrieval.types import FusedHit, RankedHit


def rrf_fuse(keyword: list[RankedHit], vector: list[RankedHit], k: int,
             limit: int | None = None) -> list[FusedHit]:
    """Fuse ranked lists by rank only; raw scores are carried for diagnostics, never added.

    Candidates are deduplicated by chunk id. Ties are broken by the best (lowest) rank in any
    list, then by chunk id, so results are deterministic.
    """
    if k < 1:
        raise ValueError("RRF constant k must be >= 1")
    kw = {h.chunk_id: h for h in keyword}
    vec = {h.chunk_id: h for h in vector}
    rows: list[tuple[float, int, str, FusedHit | tuple]] = []
    for chunk_id in kw.keys() | vec.keys():
        kh, vh = kw.get(chunk_id), vec.get(chunk_id)
        score = (1.0 / (k + kh.rank) if kh else 0.0) + (1.0 / (k + vh.rank) if vh else 0.0)
        best = min(h.rank for h in (kh, vh) if h is not None)
        rows.append((score, best, str(chunk_id), (chunk_id, kh, vh)))
    rows.sort(key=lambda r: (-r[0], r[1], r[2]))
    fused: list[FusedHit] = []
    for position, (score, _best, _id, payload) in enumerate(rows, start=1):
        chunk_id, kh, vh = payload  # type: ignore[misc]
        fused.append(FusedHit(
            chunk_id=chunk_id, fusion_score=score, final_rank=position,
            keyword_rank=kh.rank if kh else None, keyword_score=kh.score if kh else None,
            vector_rank=vh.rank if vh else None, vector_score=vh.score if vh else None,
        ))
    return fused[:limit] if limit is not None else fused
