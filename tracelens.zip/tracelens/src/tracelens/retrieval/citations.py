"""Citations: stable references to a line range of an indexed file in a specific snapshot.

Format: ``<rel_path>#L<start>-L<end>@<snapshot-id-first-8-chars>``. A citation is valid only
if the file exists in that snapshot and the range lies inside the file's indexed content.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from tracelens.models import IndexedFile

_CITATION_RE = re.compile(r"^(?P<path>.+)#L(?P<start>\d+)-L(?P<end>\d+)@(?P<snap>[0-9a-f]{8})$")


@dataclass(frozen=True)
class Citation:
    id: str
    path: str
    start_line: int
    end_line: int
    snapshot_id: str


def make_citation(snapshot_id: uuid.UUID, path: str, start: int, end: int) -> Citation:
    cid = f"{path}#L{start}-L{end}@{str(snapshot_id)[:8]}"
    return Citation(id=cid, path=path, start_line=start, end_line=end, snapshot_id=str(snapshot_id))


def parse_citation(citation_id: str) -> tuple[str, int, int, str] | None:
    m = _CITATION_RE.match(citation_id)
    if not m:
        return None
    return m["path"], int(m["start"]), int(m["end"]), m["snap"]


def validate_citation(session: Session, snapshot_id: uuid.UUID, citation_id: str) -> bool:
    """True when the citation resolves to real indexed source in ``snapshot_id``."""
    parsed = parse_citation(citation_id)
    if parsed is None:
        return False
    path, start, end, snap_prefix = parsed
    if not str(snapshot_id).startswith(snap_prefix) or not 1 <= start <= end:
        return False
    line_count = session.execute(
        select(IndexedFile.line_count).where(
            IndexedFile.snapshot_id == snapshot_id, IndexedFile.rel_path == path
        )
    ).scalar()
    return line_count is not None and end <= line_count
