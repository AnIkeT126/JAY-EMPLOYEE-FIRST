"""Embedding provider interface and the real local Sentence Transformers implementation.

There is intentionally no fake/random provider in this module. Tests that need one define a
clearly named fixture inside the test suite.
"""

from __future__ import annotations

from typing import Protocol

from tracelens.config import Settings
from tracelens.errors import EmbeddingError


class Embedder(Protocol):
    model_name: str
    dimension: int

    def embed(self, texts: list[str]) -> list[list[float]]: ...


def validate_dimensions(vectors: list[list[float]], expected: int) -> None:
    for i, vec in enumerate(vectors):
        if len(vec) != expected:
            raise EmbeddingError(
                f"embedding {i} has dimension {len(vec)} but TRACELENS_EMBEDDING_DIM={expected}; "
                "the model and the configured/stored vector dimension must match"
            )


class SentenceTransformerEmbedder:
    """Loads the model lazily on first use (first run downloads it unless cached locally)."""

    def __init__(self, model_name: str, dimension: int, batch_size: int = 32,
                 local_files_only: bool = False) -> None:
        self.model_name = model_name
        self.dimension = dimension
        self._batch_size = batch_size
        self._local_only = local_files_only
        self._model = None

    def _load(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer

                self._model = SentenceTransformer(
                    self.model_name, device="cpu", local_files_only=self._local_only
                )
            except Exception as exc:  # network failure, missing files, bad model name...
                raise EmbeddingError(
                    f"could not load embedding model '{self.model_name}': {type(exc).__name__}. "
                    "Check network access for the first download, or set "
                    "TRACELENS_EMBEDDING_LOCAL_FILES_ONLY=false / pre-populate the Hugging Face "
                    "cache (see docs/TROUBLESHOOTING.md)."
                ) from exc
        return self._model

    def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        model = self._load()
        try:
            matrix = model.encode(
                texts, batch_size=self._batch_size, normalize_embeddings=True,
                show_progress_bar=False, convert_to_numpy=True,
            )
        except Exception as exc:
            raise EmbeddingError(f"embedding failed: {type(exc).__name__}") from exc
        vectors = [[float(x) for x in row] for row in matrix]
        validate_dimensions(vectors, self.dimension)
        return vectors


def build_embedder(settings: Settings) -> Embedder | None:
    if not settings.embeddings_enabled:
        return None
    return SentenceTransformerEmbedder(
        settings.embedding_model, settings.embedding_dim, settings.embedding_batch_size,
        settings.embedding_local_files_only,
    )
