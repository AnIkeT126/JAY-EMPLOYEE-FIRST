"""Hybrid search: keyword + vector retrieval fused with RRF, returned with citations."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Literal

from sqlalchemy import select
from sqlalchemy.orm import Session

from tracelens.config import Settings
from tracelens.errors import VectorUnavailableError
from tracelens.models import Chunk, IndexedFile
from tracelens.retrieval import vector as vector_store
from tracelens.retrieval.citations import Citation, make_citation
from tracelens.retrieval.embeddings import Embedder, validate_dimensions
from tracelens.retrieval.fusion import rrf_fuse
from tracelens.retrieval.keyword import keyword_search
from tracelens.retrieval.types import FusedHit, RankedHit

SearchMode = Literal["keyword", "vector", "hybrid"]


@dataclass
class SearchHit:
    chunk_id: uuid.UUID
    file_path: str
    symbol_name: str | None
    kind: str
    language: str
    start_line: int
    end_line: int
    content: str
    snapshot_id: uuid.UUID
    keyword_rank: int | None
    keyword_score: float | None
    vector_rank: int | None
    vector_score: float | None
    fusion_score: float
    final_rank: int
    citation: Citation


@dataclass
class SearchOutcome:
    mode_requested: str
    mode_used: str
    hits: list[SearchHit]
    warnings: list[str] = field(default_factory=list)


class SearchService:
    def __init__(self, session: Session, settings: Settings, embedder: Embedder | None) -> None:
        self.session = session
        self.settings = settings
        self.embedder = embedder

    def search(self, snapshot_id: uuid.UUID, query: str, *, mode: SearchMode = "hybrid",
               top_k: int | None = None, language: str | None = None,
               path_prefix: str | None = None) -> SearchOutcome:
        s = self.settings
        top_k = min(top_k or s.default_top_k, s.max_top_k)
        warnings: list[str] = []
        keyword: list[RankedHit] = []
        vec: list[RankedHit] = []
        used = mode

        if mode in ("keyword", "hybrid"):
            keyword = keyword_search(self.session, snapshot_id, query, s.keyword_candidates,
                                     language, path_prefix)
        if mode in ("vector", "hybrid"):
            try:
                vec = self._vector(snapshot_id, query, language, path_prefix)
            except VectorUnavailableError as exc:
                if mode == "vector":
                    raise
                # Explicit, visible degradation: never pretend vector results were included.
                used = "keyword"
                warnings.append(f"vector retrieval unavailable, keyword results only: {exc.message}")

        if used == "keyword" and mode != "vector":
            fused = rrf_fuse(keyword, [], s.rrf_k, top_k)
        elif mode == "vector":
            fused = rrf_fuse([], vec, s.rrf_k, top_k)
        else:
            fused = rrf_fuse(keyword, vec, s.rrf_k, top_k)
        return SearchOutcome(mode, used, self._assemble(snapshot_id, fused), warnings)

    def _vector(self, snapshot_id: uuid.UUID, query: str, language: str | None,
                path_prefix: str | None) -> list[RankedHit]:
        if self.embedder is None:
            raise VectorUnavailableError("embeddings are disabled (TRACELENS_EMBEDDINGS_ENABLED=false)")
        vector_store.ensure_available(self.session, self.settings.embedding_dim)
        qvec = self.embedder.embed([query])
        validate_dimensions(qvec, self.settings.embedding_dim)
        return vector_store.vector_search(self.session, snapshot_id, qvec[0],
                                          self.settings.vector_candidates, language, path_prefix)

    def _assemble(self, snapshot_id: uuid.UUID, fused: list[FusedHit]) -> list[SearchHit]:
        if not fused:
            return []
        ids = [f.chunk_id for f in fused]
        rows = self.session.execute(
            select(Chunk, IndexedFile.rel_path)
            .join(IndexedFile, IndexedFile.id == Chunk.file_id)
            .where(Chunk.id.in_(ids), Chunk.snapshot_id == snapshot_id)
        ).all()
        by_id = {chunk.id: (chunk, path) for chunk, path in rows}
        hits: list[SearchHit] = []
        for f in fused:
            if f.chunk_id not in by_id:
                continue
            chunk, path = by_id[f.chunk_id]
            hits.append(SearchHit(
                chunk_id=chunk.id, file_path=path, symbol_name=chunk.symbol_name,
                kind=chunk.kind, language=chunk.language, start_line=chunk.start_line,
                end_line=chunk.end_line, content=chunk.content, snapshot_id=snapshot_id,
                keyword_rank=f.keyword_rank, keyword_score=f.keyword_score,
                vector_rank=f.vector_rank, vector_score=f.vector_score,
                fusion_score=f.fusion_score, final_rank=f.final_rank,
                citation=make_citation(snapshot_id, path, chunk.start_line, chunk.end_line),
            ))
        return hits
