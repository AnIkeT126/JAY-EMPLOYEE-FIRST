"""PostgreSQL full-text keyword retrieval over pre-tokenised chunk text."""

from __future__ import annotations

import uuid

from sqlalchemy import text
from sqlalchemy.orm import Session

from tracelens.indexing.chunker import search_tokens
from tracelens.retrieval.types import RankedHit


def build_tsquery(query: str) -> str | None:
    """OR-join the same tokens used at index time. Tokens are alphanumeric only, and the
    result is still passed as a bound parameter, so no query text reaches the SQL string."""
    seen: list[str] = []
    for token in search_tokens(query):
        if token not in seen:
            seen.append(token)
    return " | ".join(seen) if seen else None


def like_prefix(prefix: str) -> str:
    escaped = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return escaped + "%"


def keyword_search(session: Session, snapshot_id: uuid.UUID, query: str, limit: int,
                   language: str | None = None, path_prefix: str | None = None) -> list[RankedHit]:
    tsquery = build_tsquery(query)
    if tsquery is None:
        return []
    sql = (
        "SELECT c.id, ts_rank_cd(c.tsv, q) AS score "
        "FROM chunks c JOIN indexed_files f ON f.id = c.file_id, "
        "to_tsquery('simple', :q) q "
        "WHERE c.snapshot_id = :sid AND c.tsv @@ q"
    )
    params: dict = {"q": tsquery, "sid": snapshot_id, "n": limit}
    if language:
        sql += " AND c.language = :lang"
        params["lang"] = language
    if path_prefix:
        sql += " AND f.rel_path LIKE :prefix ESCAPE '\\'"
        params["prefix"] = like_prefix(path_prefix)
    sql += " ORDER BY score DESC, c.id LIMIT :n"
    rows = session.execute(text(sql), params).all()
    return [RankedHit(chunk_id=r[0], rank=i, score=float(r[1])) for i, r in enumerate(rows, 1)]
