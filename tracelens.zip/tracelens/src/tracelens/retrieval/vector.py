"""pgvector storage and cosine-distance search (``<=>`` matches the HNSW cosine index)."""

from __future__ import annotations

import uuid

from sqlalchemy import text
from sqlalchemy.orm import Session

from tracelens.errors import VectorUnavailableError
from tracelens.retrieval.types import RankedHit


def vector_literal(vec: list[float]) -> str:
    return "[" + ",".join(f"{x:.8g}" for x in vec) + "]"


def table_exists(session: Session) -> bool:
    return bool(session.execute(text("SELECT to_regclass('public.chunk_embeddings')")).scalar())


def stored_dimension(session: Session) -> int | None:
    """Dimension of the chunk_embeddings.embedding column (pgvector stores it as typmod)."""
    row = session.execute(text(
        "SELECT a.atttypmod FROM pg_attribute a "
        "WHERE a.attrelid = to_regclass('public.chunk_embeddings') AND a.attname = 'embedding'"
    )).scalar()
    return int(row) if row is not None and int(row) > 0 else None


def ensure_available(session: Session, expected_dim: int) -> None:
    if not table_exists(session):
        raise VectorUnavailableError(
            "vector search needs migration 0002 (pgvector); run `alembic upgrade head` against a "
            "PostgreSQL server that has the pgvector extension"
        )
    dim = stored_dimension(session)
    if dim is not None and dim != expected_dim:
        raise VectorUnavailableError(
            f"database vectors have dimension {dim} but TRACELENS_EMBEDDING_DIM={expected_dim}"
        )


def insert_embeddings(session: Session, snapshot_id: uuid.UUID, model: str,
                      rows: list[tuple[uuid.UUID, list[float]]]) -> None:
    stmt = text(
        "INSERT INTO chunk_embeddings (chunk_id, snapshot_id, model, embedding) "
        "VALUES (:chunk_id, :snapshot_id, :model, CAST(:embedding AS vector))"
    )
    for start in range(0, len(rows), 500):
        session.execute(stmt, [
            {"chunk_id": cid, "snapshot_id": snapshot_id, "model": model,
             "embedding": vector_literal(vec)}
            for cid, vec in rows[start:start + 500]
        ])


def reusable_embeddings(session: Session, previous_snapshot_id: uuid.UUID | None,
                        model: str) -> dict[str, list[float]]:
    """content_sha -> embedding from the previous snapshot (unchanged chunks are not re-embedded)."""
    if previous_snapshot_id is None or not table_exists(session):
        return {}
    rows = session.execute(text(
        "SELECT c.content_sha, ce.embedding::text FROM chunk_embeddings ce "
        "JOIN chunks c ON c.id = ce.chunk_id WHERE ce.snapshot_id = :sid AND ce.model = :model"
    ), {"sid": previous_snapshot_id, "model": model}).all()
    return {sha: [float(x) for x in emb.strip("[]").split(",")] for sha, emb in rows}


def vector_search(session: Session, snapshot_id: uuid.UUID, query_vec: list[float], limit: int,
                  language: str | None = None, path_prefix: str | None = None) -> list[RankedHit]:
    sql = (
        "SELECT ce.chunk_id, 1 - (ce.embedding <=> CAST(:q AS vector)) AS score "
        "FROM chunk_embeddings ce JOIN chunks c ON c.id = ce.chunk_id "
        "JOIN indexed_files f ON f.id = c.file_id WHERE ce.snapshot_id = :sid"
    )
    params: dict = {"q": vector_literal(query_vec), "sid": snapshot_id, "n": limit}
    if language:
        sql += " AND c.language = :lang"
        params["lang"] = language
    if path_prefix:
        sql += " AND f.rel_path LIKE :prefix ESCAPE '\\'"
        params["prefix"] = _like_prefix(path_prefix)
    sql += " ORDER BY ce.embedding <=> CAST(:q AS vector), ce.chunk_id LIMIT :n"
    rows = session.execute(text(sql), params).all()
    return [RankedHit(chunk_id=r[0], rank=i, score=float(r[1])) for i, r in enumerate(rows, 1)]


def _like_prefix(prefix: str) -> str:
    escaped = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return escaped + "%"
