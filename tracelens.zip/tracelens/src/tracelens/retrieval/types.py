from __future__ import annotations

import uuid
from dataclasses import dataclass


@dataclass(frozen=True)
class RankedHit:
    chunk_id: uuid.UUID
    rank: int  # 1-based position in the source list
    score: float  # raw, source-specific score (not comparable across sources)


@dataclass(frozen=True)
class FusedHit:
    chunk_id: uuid.UUID
    fusion_score: float
    final_rank: int
    keyword_rank: int | None
    keyword_score: float | None
    vector_rank: int | None
    vector_score: float | None
