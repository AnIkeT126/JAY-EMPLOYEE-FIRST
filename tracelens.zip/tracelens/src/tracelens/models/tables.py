"""SQLAlchemy models. Every derived row belongs to exactly one snapshot.

The ``chunks.tsv`` tsvector column and the ``chunk_embeddings`` table are created by
migrations and accessed with SQL, not mapped here (see docs/DATABASE.md).
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID

from tracelens.database.session import Base

SNAPSHOT_RUNNING = "RUNNING"
SNAPSHOT_COMPLETED = "COMPLETED"
SNAPSHOT_FAILED = "FAILED"

EDGE_TYPES = ("DEFINES", "IMPORTS", "CALLS", "EXTENDS", "IMPLEMENTS", "TESTS")
EDGE_RESOLVED = "RESOLVED"
EDGE_UNRESOLVED = "UNRESOLVED"


def _uuid_pk() -> Column:
    return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


def _snapshot_fk() -> Column:
    return Column(
        UUID(as_uuid=True),
        ForeignKey("snapshots.id", ondelete="CASCADE"),
        nullable=False,
    )


class Repository(Base):
    __tablename__ = "repositories"

    id = _uuid_pk()
    name = Column(String(200), nullable=False, unique=True)
    # Directory relative to TRACELENS_REPOSITORY_ROOT ("" = the root itself).
    subdirectory = Column(Text, nullable=False, default="")
    active_snapshot_id = Column(
        UUID(as_uuid=True),
        ForeignKey(
            "snapshots.id",
            use_alter=True,
            name="fk_repositories_active_snapshot",
            ondelete="SET NULL",
        ),
        nullable=True,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class Snapshot(Base):
    __tablename__ = "snapshots"
    __table_args__ = (
        CheckConstraint("status IN ('RUNNING','COMPLETED','FAILED')", name="ck_snapshot_status"),
        Index("ix_snapshots_repo_started", "repository_id", "started_at"),
    )

    id = _uuid_pk()
    repository_id = Column(
        UUID(as_uuid=True), ForeignKey("repositories.id", ondelete="CASCADE"), nullable=False
    )
    status = Column(String(16), nullable=False, default=SNAPSHOT_RUNNING)
    started_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    finished_at = Column(DateTime(timezone=True))
    error = Column(Text)
    stats = Column(JSONB, nullable=False, default=dict)


class IndexedFile(Base):
    __tablename__ = "indexed_files"
    __table_args__ = (UniqueConstraint("snapshot_id", "rel_path", name="uq_file_snapshot_path"),)

    id = _uuid_pk()
    snapshot_id = _snapshot_fk()
    rel_path = Column(Text, nullable=False)
    language = Column(String(16), nullable=False)
    sha256 = Column(String(64), nullable=False)
    size_bytes = Column(BigInteger, nullable=False)
    line_count = Column(Integer, nullable=False)
    is_test = Column(Boolean, nullable=False, default=False)
    parse_error = Column(Text)
    content = Column(Text, nullable=False)
    indexed_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class Symbol(Base):
    __tablename__ = "symbols"
    __table_args__ = (
        UniqueConstraint(
            "snapshot_id", "file_id", "qualified_name", "start_line", name="uq_symbol_identity"
        ),
        Index("ix_symbols_snapshot_qname", "snapshot_id", "qualified_name"),
        Index("ix_symbols_snapshot_name", "snapshot_id", "name"),
    )

    id = _uuid_pk()
    snapshot_id = _snapshot_fk()
    file_id = Column(
        UUID(as_uuid=True), ForeignKey("indexed_files.id", ondelete="CASCADE"), nullable=False
    )
    parent_id = Column(UUID(as_uuid=True), ForeignKey("symbols.id", ondelete="CASCADE"))
    kind = Column(String(24), nullable=False)
    name = Column(Text, nullable=False)
    qualified_name = Column(Text, nullable=False)
    signature = Column(Text)
    language = Column(String(16), nullable=False)
    start_line = Column(Integer, nullable=False)
    end_line = Column(Integer, nullable=False)
    is_test = Column(Boolean, nullable=False, default=False)


class Edge(Base):
    __tablename__ = "edges"
    __table_args__ = (
        CheckConstraint(
            "edge_type IN ('DEFINES','IMPORTS','CALLS','EXTENDS','IMPLEMENTS','TESTS')",
            name="ck_edge_type",
        ),
        CheckConstraint("status IN ('RESOLVED','UNRESOLVED')", name="ck_edge_status"),
        CheckConstraint(
            "(status = 'RESOLVED' AND dst_symbol_id IS NOT NULL) OR status = 'UNRESOLVED'",
            name="ck_edge_resolved_has_target",
        ),
        Index("ix_edges_snapshot_src", "snapshot_id", "src_symbol_id"),
        Index("ix_edges_snapshot_dst", "snapshot_id", "dst_symbol_id"),
    )

    id = _uuid_pk()
    snapshot_id = _snapshot_fk()
    edge_type = Column(String(16), nullable=False)
    status = Column(String(16), nullable=False)
    src_symbol_id = Column(
        UUID(as_uuid=True), ForeignKey("symbols.id", ondelete="CASCADE"), nullable=False
    )
    dst_symbol_id = Column(UUID(as_uuid=True), ForeignKey("symbols.id", ondelete="CASCADE"))
    dst_ref = Column(Text)  # the unresolved textual reference, e.g. "processor.process"
    file_id = Column(
        UUID(as_uuid=True), ForeignKey("indexed_files.id", ondelete="CASCADE"), nullable=False
    )
    line = Column(Integer, nullable=False)
    evidence = Column(Text, nullable=False)
    note = Column(Text)


class Chunk(Base):
    __tablename__ = "chunks"
    __table_args__ = (
        Index("ix_chunks_snapshot_file", "snapshot_id", "file_id"),
        Index("ix_chunks_snapshot_language", "snapshot_id", "language"),
    )

    id = _uuid_pk()
    snapshot_id = _snapshot_fk()
    file_id = Column(
        UUID(as_uuid=True), ForeignKey("indexed_files.id", ondelete="CASCADE"), nullable=False
    )
    symbol_id = Column(UUID(as_uuid=True), ForeignKey("symbols.id", ondelete="SET NULL"))
    kind = Column(String(24), nullable=False)
    symbol_name = Column(Text)
    language = Column(String(16), nullable=False)
    start_line = Column(Integer, nullable=False)
    end_line = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    content_sha = Column(String(64), nullable=False)
    name_text = Column(Text, nullable=False, default="")  # tokens of the symbol/heading/file name
    search_text = Column(Text, nullable=False)


class ImpactAnalysis(Base):
    __tablename__ = "impact_analyses"

    id = _uuid_pk()
    repository_id = Column(
        UUID(as_uuid=True), ForeignKey("repositories.id", ondelete="CASCADE"), nullable=False
    )
    snapshot_id = Column(UUID(as_uuid=True), ForeignKey("snapshots.id", ondelete="SET NULL"))
    request = Column(JSONB, nullable=False)
    report = Column(JSONB, nullable=False)
    generated_by = Column(String(32), nullable=False)
    duration_ms = Column(Float, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
