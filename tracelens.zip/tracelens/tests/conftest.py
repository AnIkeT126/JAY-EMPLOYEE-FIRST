"""Shared fixtures. Integration tests need TRACELENS_TEST_DATABASE_URL (see docs/SETUP_AND_RUN.md)."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import text

from tracelens.config import PROJECT_ROOT, Settings
from tracelens.database.session import make_engine, make_session_factory

DEMO = PROJECT_ROOT / "demo" / "sample_repository"
TEST_DB_URL = os.environ.get("TRACELENS_TEST_DATABASE_URL")


def make_settings(**overrides) -> Settings:
    base = dict(
        environment="test", database_url=TEST_DB_URL or "postgresql+psycopg2://x:x@localhost/x",
        repository_root=DEMO, embeddings_enabled=False,
    )
    base.update(overrides)
    return Settings(_env_file=None, **base)


def pytest_collection_modifyitems(config, items):
    if TEST_DB_URL:
        return
    skip = pytest.mark.skip(reason="TRACELENS_TEST_DATABASE_URL is not set")
    for item in items:
        if "integration" in item.keywords or "pgvector" in item.keywords:
            item.add_marker(skip)


@pytest.fixture(scope="session")
def database():
    """A clean schema migrated as far as the server allows. Yields (engine, has_pgvector)."""
    engine = make_engine(TEST_DB_URL)
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
    cfg = Config(str(PROJECT_ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(PROJECT_ROOT / "migrations"))
    cfg.set_main_option("sqlalchemy.url", TEST_DB_URL.replace("%", "%%"))
    command.upgrade(cfg, "0001")
    has_pgvector = True
    try:
        command.upgrade(cfg, "head")
    except Exception:  # pgvector extension not installable on this server
        has_pgvector = False
    yield engine, has_pgvector
    engine.dispose()


@pytest.fixture()
def settings() -> Settings:
    return make_settings()


@pytest.fixture()
def factory(database):
    engine, _ = database
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE repositories, snapshots, impact_analyses CASCADE"))
    return make_session_factory(engine)


@pytest.fixture()
def demo_copy(tmp_path: Path) -> Path:
    """A writable copy of the demo repository so tests can modify files."""
    dst = tmp_path / "repo"
    shutil.copytree(DEMO, dst)
    return dst
