from __future__ import annotations

import pytest

from tracelens.config import PROJECT_ROOT
from tracelens.evaluation.runner import load_dataset, render_markdown, run_evaluation, write_reports
from tracelens.indexing.service import Indexer

pytestmark = pytest.mark.integration

DATASET = PROJECT_ROOT / "data" / "evaluation" / "cases.json"


def test_dataset_is_well_formed():
    data = load_dataset(DATASET)
    assert len(data["retrieval_cases"]) + len(data["impact_cases"]) >= 20
    assert all(c["relevant"] for c in data["retrieval_cases"])


def test_benchmark_runs_and_skips_unavailable_modes_honestly(factory, settings, tmp_path):
    Indexer(factory, settings, None).index("sample_repository")
    result = run_evaluation(factory, settings, None, DATASET, k=10)
    assert result["retrieval"]["keyword"]["status"] == "measured"
    assert result["retrieval"]["vector"]["status"] == "skipped"  # embeddings disabled here
    assert result["retrieval"]["hybrid"]["status"] == "skipped"
    kw = result["retrieval"]["keyword"]
    assert 0.0 <= kw["recall@10"] <= 1.0 and kw["citation_validity"] == 1.0
    sym = result["impact"]["static_analysis_symbol_level"]
    assert 0.0 <= sym["precision"] <= 1.0 and sym["citation_validity"] == 1.0
    assert len(sym["per_case"]) == 12
    json_path, md_path = write_reports(result, tmp_path)
    assert json_path.exists() and "skipped" in md_path.read_text()
    assert "Recall@10" in render_markdown(result)
