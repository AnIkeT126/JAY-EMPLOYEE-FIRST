"""LLM orchestration with a scripted provider (a test double, not an LLM integration)."""

from __future__ import annotations

import json

import pytest

from tests.conftest import make_settings
from tracelens.errors import LLMError
from tracelens.impact.analyzer import ImpactAnalyzer
from tracelens.indexing.service import Indexer
from tracelens.llm.agent import ImpactNarrator
from tracelens.retrieval.service import SearchService
from tracelens.schemas.impact import ImpactRequest

pytestmark = pytest.mark.integration


class ScriptedProvider:
    """Test double that replays canned assistant messages."""

    def __init__(self, replies):
        self.replies = list(replies)
        self.seen: list[list[dict]] = []

    def chat(self, messages, tools):
        self.seen.append(list(messages))
        reply = self.replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply


def tool_call(name, args, cid="c1"):
    return {"content": None, "tool_calls": [{"id": cid, "type": "function",
                                             "function": {"name": name, "arguments": json.dumps(args)}}]}


def run(factory, settings, provider, request_kwargs):
    with factory() as s:
        narrator = ImpactNarrator(provider, s, settings, SearchService(s, settings, None))
        report = ImpactAnalyzer(s, settings, None, narrator).analyze(
            ImpactRequest(use_llm=True, **request_kwargs))
        s.commit()
        return report


@pytest.fixture()
def repo(factory, settings):
    return Indexer(factory, settings, None).index("demo")


def kwargs(repo):
    return dict(repository_id=repo.repository_id, target_symbol="tax_rate_for",
                change_description="unknown regions should raise", max_depth=2)


def test_llm_summary_keeps_only_verified_citations(factory, settings, repo):
    good = "python/billing/tax.py#L14-L14@" + str(repo.snapshot_id)[:8]  # apply_tax -> tax_rate_for call
    fake = "python/billing/tax.py#L1-L9999@" + str(repo.snapshot_id)[:8]
    provider = ScriptedProvider([
        tool_call("find_symbol", {"name": "apply_tax"}),
        {"content": f"apply_tax calls tax_rate_for [cite:{good}] and also [cite:{fake}] "
                    "[cite:made/up.py#L1-L2@deadbeef]"},
    ])
    report = run(factory, settings, provider, kwargs(repo))
    assert report.generated_by == "llm+deterministic"
    assert f"[cite:{good}]" in report.llm_summary  # backed by report evidence and valid
    assert fake not in report.llm_summary and "made/up.py" not in report.llm_summary
    assert any("2 citation(s) removed" in n for n in report.llm_notes)
    # tool output reached the model labelled as untrusted data
    tool_msgs = [m for m in provider.seen[-1] if m["role"] == "tool"]
    assert json.loads(tool_msgs[0]["content"])["untrusted_content"] is True
    # the deterministic structure is untouched by the LLM
    assert {c.name for c in report.affected_components} >= {"apply_tax"}


def test_tool_call_budget_is_enforced(factory, repo):
    settings = make_settings(max_tool_calls=2)
    provider = ScriptedProvider(
        [tool_call("search_code", {"query": "tax"}, f"c{i}") for i in range(3)]
        + [{"content": "done"}])
    report = run(factory, settings, provider, kwargs(repo))
    assert report.generated_by == "llm+deterministic"
    results = [json.loads(m["content"]) for m in provider.seen[-1] if m["role"] == "tool"]
    assert len(results) == 3  # third call is answered, but with a budget error
    assert results[2] == {"error": "tool-call budget exhausted"}
    assert any("tool calls used: 2" in n for n in report.llm_notes)


def test_prompt_injection_in_tool_result_cannot_change_policy(factory, settings, repo):
    provider = ScriptedProvider([
        tool_call("get_source_range", {"path": "../../etc/passwd", "start_line": 1, "end_line": 5}),
        tool_call("get_source_range", {"path": "docs/billing.md", "start_line": 1, "end_line": 3}),
        {"content": "summary"},
    ])
    report = run(factory, settings, provider, kwargs(repo))
    msgs = [json.loads(m["content"]) for m in provider.seen[-1] if m["role"] == "tool"]
    assert msgs[0]["data"] == {"error": "file is not part of the indexed snapshot"}
    assert "Billing" in msgs[1]["data"]["source"]
    assert report.llm_summary == "summary"


def test_provider_failure_falls_back_to_deterministic_report(factory, settings, repo):
    provider = ScriptedProvider([LLMError("LLM request timed out")])
    report = run(factory, settings, provider, kwargs(repo))
    assert report.generated_by == "deterministic" and report.llm_summary is None
    assert any("LLM narration failed" in w for w in report.warnings)
    assert report.affected_components  # still a useful report


def test_use_llm_without_provider_is_reported_not_faked(factory, settings, repo):
    with factory() as s:
        report = ImpactAnalyzer(s, settings, None, None).analyze(
            ImpactRequest(use_llm=True, **kwargs(repo)))
    assert report.generated_by == "deterministic"
    assert any("no provider is configured" in w for w in report.warnings)
