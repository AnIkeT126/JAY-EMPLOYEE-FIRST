"""pgvector round-trip using a clearly labelled TEST FIXTURE embedder (not a real model).

Requires a PostgreSQL server with the pgvector extension; skipped otherwise.
"""

from __future__ import annotations

import hashlib
import math

import pytest

from tests.conftest import make_settings
from tracelens.indexing.service import Indexer
from tracelens.retrieval.service import SearchService

pytestmark = [pytest.mark.integration, pytest.mark.pgvector]

DIM = 384


class HashedBagOfWordsTestEmbedder:
    """TEST FIXTURE ONLY: deterministic hashed bag-of-words vectors."""

    model_name = "test-fixture-hashed-bow"
    dimension = DIM

    def embed(self, texts):
        out = []
        for text in texts:
            vec = [0.0] * DIM
            for word in text.lower().split():
                vec[int(hashlib.md5(word.encode()).hexdigest(), 16) % DIM] += 1.0
            norm = math.sqrt(sum(x * x for x in vec)) or 1.0
            out.append([x / norm for x in vec])
        return out


def test_embeddings_are_stored_reused_and_searchable(database, factory, demo_copy):
    _, has_pgvector = database
    if not has_pgvector:
        pytest.skip("pgvector extension is not available on this PostgreSQL server")
    settings = make_settings(repository_root=demo_copy, embeddings_enabled=True)
    embedder = HashedBagOfWordsTestEmbedder()
    indexer = Indexer(factory, settings, embedder)
    first = indexer.index("demo")
    assert first.stats["embeddings"] == first.stats["chunks"] > 0
    (demo_copy / "python/billing/tax.py").write_text(
        (demo_copy / "python/billing/tax.py").read_text() + "\n\ndef extra():\n    return 1\n")
    second = indexer.index("demo")
    assert 0 < second.stats["embeddings_reused"] < second.stats["chunks"]
    with factory() as s:
        svc = SearchService(s, settings, embedder)
        out = svc.search(second.snapshot_id, "calculate total with discount", mode="hybrid", top_k=5)
        assert out.mode_used == "hybrid" and not out.warnings
        assert any(h.vector_rank for h in out.hits)
        vec_only = svc.search(second.snapshot_id, "format money currency", mode="vector", top_k=3)
        assert vec_only.hits and all(h.keyword_rank is None for h in vec_only.hits)
