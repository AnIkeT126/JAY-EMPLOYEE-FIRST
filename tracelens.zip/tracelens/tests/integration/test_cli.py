from __future__ import annotations

import json

import pytest
from typer.testing import CliRunner

from tests.conftest import DEMO, TEST_DB_URL
from tracelens.cli import app
from tracelens.config import get_settings

pytestmark = pytest.mark.integration

runner = CliRunner()


@pytest.fixture()
def cli_env(factory, monkeypatch):
    monkeypatch.setenv("TRACELENS_DATABASE_URL", TEST_DB_URL)
    monkeypatch.setenv("TRACELENS_REPOSITORY_ROOT", str(DEMO))
    monkeypatch.setenv("TRACELENS_EMBEDDINGS_ENABLED", "false")
    monkeypatch.setenv("TRACELENS_ENVIRONMENT", "development")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def test_doctor_index_status_search_analyze_report(cli_env, tmp_path):
    doctor = runner.invoke(app, ["doctor"])
    assert doctor.exit_code == 0, doctor.output
    assert "[OK  ] database" in doctor.output

    idx = runner.invoke(app, ["index", "--name", "sample_repository"])
    assert idx.exit_code == 0 and "indexed" in idx.output
    assert "unchanged" in runner.invoke(app, ["index", "--name", "sample_repository"]).output

    assert "active snapshot" in runner.invoke(app, ["status"]).output
    assert "sample_repository" in runner.invoke(app, ["status", "-r", "sample_repository"]).output

    found = runner.invoke(app, ["search", "calculate_total", "-r", "sample_repository",
                                "--mode", "keyword"])
    assert found.exit_code == 0 and "pricing.py" in found.output
    assert runner.invoke(app, ["search", "x", "-r", "sample_repository", "--mode", "bogus"]
                         ).exit_code == 2

    analysis = runner.invoke(app, ["analyze", "-r", "sample_repository", "--symbol",
                                   "ShippingService", "--change", "estimate gets a new argument",
                                   "--json"])
    assert analysis.exit_code == 0, analysis.output
    data = json.loads(analysis.output)
    assert data["generated_by"] == "deterministic"

    md = runner.invoke(app, ["report", data["analysis_id"]])
    assert md.exit_code == 0 and "Affected components" in md.output and "Limitations" in md.output
    out = tmp_path / "r.json"
    assert runner.invoke(app, ["report", data["analysis_id"], "--format", "json", "-o", str(out)]
                         ).exit_code == 0
    assert json.loads(out.read_text())["analysis_id"] == data["analysis_id"]
    assert runner.invoke(app, ["report", "00000000-0000-0000-0000-000000000000"]).exit_code == 1


def test_analyze_unknown_target_exits_nonzero(cli_env):
    runner.invoke(app, ["index", "--name", "sample_repository"])
    result = runner.invoke(app, ["analyze", "-r", "sample_repository", "--symbol", "nope_nope",
                                 "--change", "whatever change"])
    assert result.exit_code == 1 and "not found" in result.output


def test_eval_command_writes_reports(cli_env, monkeypatch, tmp_path):
    monkeypatch.setenv("TRACELENS_EVAL_OUTPUT_DIR", str(tmp_path))
    get_settings.cache_clear()
    runner.invoke(app, ["index", "--name", "sample_repository"])
    result = runner.invoke(app, ["eval"])
    assert result.exit_code == 0, result.output
    assert (tmp_path / "evaluation.json").exists() and (tmp_path / "evaluation.md").exists()


def test_db_reset_requires_flag_and_development(cli_env, monkeypatch):
    assert runner.invoke(app, ["db-reset"]).exit_code == 2  # no --yes
    monkeypatch.setenv("TRACELENS_ENVIRONMENT", "production")
    get_settings.cache_clear()
    assert runner.invoke(app, ["db-reset", "--yes"]).exit_code == 2


def test_invalid_configuration_exit_code(monkeypatch):
    monkeypatch.setenv("TRACELENS_API_PORT", "99999")
    get_settings.cache_clear()
    try:
        assert runner.invoke(app, ["doctor"]).exit_code == 2
    finally:
        get_settings.cache_clear()
