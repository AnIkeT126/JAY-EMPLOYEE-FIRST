from __future__ import annotations

import pytest
from sqlalchemy import select

from tracelens.analysis import dependency_graph as dg
from tracelens.errors import AmbiguousTargetError, NotFoundError, VectorUnavailableError
from tracelens.impact.analyzer import ImpactAnalyzer
from tracelens.indexing.service import Indexer
from tracelens.models import Repository
from tracelens.retrieval.citations import validate_citation
from tracelens.retrieval.service import SearchService
from tracelens.schemas.impact import ImpactRequest

pytestmark = pytest.mark.integration


@pytest.fixture()
def indexed(factory, settings):
    result = Indexer(factory, settings, None).index("demo")
    return result


def test_keyword_search_finds_exact_identifier_with_valid_citation(factory, settings, indexed):
    with factory() as s:
        out = SearchService(s, settings, None).search(indexed.snapshot_id, "calculate_total",
                                                      mode="keyword", top_k=5)
        top = out.hits[0]
        assert top.symbol_name == "calculate_total"
        assert top.file_path == "python/billing/pricing.py"
        assert top.keyword_rank == 1 and top.vector_rank is None
        assert validate_citation(s, indexed.snapshot_id, top.citation.id)
        assert not validate_citation(s, indexed.snapshot_id, "python/billing/pricing.py#L1-L9999@"
                                     + str(indexed.snapshot_id)[:8])
        assert not validate_citation(s, indexed.snapshot_id, "nope.py#L1-L1@"
                                     + str(indexed.snapshot_id)[:8])


def test_keyword_search_filters_and_natural_language(factory, settings, indexed):
    with factory() as s:
        svc = SearchService(s, settings, None)
        docs = svc.search(indexed.snapshot_id, "tax rate region", mode="keyword", language="markdown")
        assert docs.hits and all(h.language == "markdown" for h in docs.hits)
        java = svc.search(indexed.snapshot_id, "ShippingProvider quote parcel", mode="keyword",
                          path_prefix="java/src/main")
        assert java.hits and all(h.file_path.startswith("java/src/main") for h in java.hits)
        assert svc.search(indexed.snapshot_id, "zzzzqqqq", mode="keyword").hits == []
        assert svc.search(indexed.snapshot_id, "!!! ???", mode="keyword").hits == []


def test_search_survives_sql_metacharacters(factory, settings, indexed):
    with factory() as s:
        svc = SearchService(s, settings, None)
        for q in ["'; DROP TABLE chunks; --", "a & b | !c", "path_prefix%_"]:
            svc.search(indexed.snapshot_id, q, mode="keyword")
        assert s.execute(select(Repository)).scalars().all()  # tables intact


def test_vector_mode_reports_unavailable_and_hybrid_degrades_visibly(factory, settings, indexed):
    with factory() as s:
        svc = SearchService(s, settings, None)  # embeddings disabled
        with pytest.raises(VectorUnavailableError):
            svc.search(indexed.snapshot_id, "total", mode="vector")
        out = svc.search(indexed.snapshot_id, "calculate_total", mode="hybrid")
        assert out.mode_used == "keyword" and out.warnings
        assert "keyword results only" in out.warnings[0]


def test_dependency_trace_upstream_and_downstream(factory, settings, indexed):
    with factory() as s:
        target = dg.resolve_target(s, indexed.snapshot_id, symbol="tax_rate_for", file=None)
        up = dg.trace(s, indexed.snapshot_id, [t.id for t in target], "upstream", 3)
        depths = {st.symbol.name: st.depth for st in up.steps}
        assert depths["apply_tax"] == 1 and depths["calculate_total"] == 2
        assert depths["total"] == 3 and depths["monthly_report"] == 3
        assert "render" not in depths  # depth 4 is beyond the bound
        down = dg.trace(s, indexed.snapshot_id,
                        [dg.resolve_target(s, indexed.snapshot_id, symbol="checkout",
                                           file=None)[0].id], "downstream", 1)
        assert {st.symbol.name for st in down.steps} >= {"total", "charge", "__init__"}
        for st in up.steps:  # every step carries evidence with a location
            assert all(e.line >= 1 and e.evidence for e in st.path)


def test_target_resolution_errors(factory, indexed):
    with factory() as s:
        with pytest.raises(NotFoundError):
            dg.resolve_target(s, indexed.snapshot_id, symbol="does_not_exist", file=None)
        with pytest.raises(AmbiguousTargetError):
            dg.resolve_target(s, indexed.snapshot_id, symbol="process", file=None)


def _analyze(factory, settings, repo_id, **kw):
    with factory() as s:
        report = ImpactAnalyzer(s, settings, None).analyze(ImpactRequest(repository_id=repo_id, **kw))
        s.commit()
        return report


def test_impact_report_for_python_function(factory, settings, indexed):
    report = _analyze(factory, settings, indexed.repository_id, target_symbol="tax_rate_for",
                      change_description="unknown regions should raise an error", max_depth=3)
    comps = {c.name: c for c in report.affected_components if c.kind != "module"}
    assert comps["apply_tax"].confidence == "high" and comps["apply_tax"].depth == 1
    assert comps["calculate_total"].confidence == "medium"
    assert {"total", "monthly_report"} <= set(comps)
    tests = {t.name for t in report.related_tests}
    assert {"test_tax_rate_known_region", "test_apply_tax_adds_rate",
            "test_calculate_total_includes_tax"} <= tests
    assert report.generated_by == "deterministic" and report.llm_summary is None
    assert report.related_documentation and report.related_documentation[0].file_path == "docs/billing.md"
    for comp in report.affected_components:
        assert comp.evidence and all(e.citation.path and e.snippet for e in comp.evidence)
    with factory() as s:
        for c in report.affected_components:
            assert all(validate_citation(s, report.snapshot_id, e.citation.id) for e in c.evidence)
    assert report.semantic_candidates == [] or all(
        sc.evidence_kind == "semantic" and sc.confidence == "low" for sc in report.semantic_candidates)


def test_impact_interface_change_reaches_implementors_and_flags_unresolved(factory, settings, indexed):
    report = _analyze(factory, settings, indexed.repository_id,
                      target_symbol="com.acme.shipping.ShippingProvider.quote",
                      change_description="quote returns a money object", max_depth=3)
    names = {c.name for c in report.affected_components}
    assert {"FlatRateProvider", "ExpressProvider", "estimate", "fulfill"} <= names
    impl = next(c for c in report.affected_components if c.name == "FlatRateProvider")
    assert impl.relationship == "IMPLEMENTS" and impl.confidence == "high"
    assert {t.name for t in report.related_tests} >= {"quoteIncludesWeightSurcharge"}
    assert any(u.reference == "provider.quote" and u.direction == "possible_reference_to_target"
               for u in report.unresolved_relationships)
    assert any("unresolved" in m.lower() for m in report.missing_information)


def test_impact_reports_reflection_as_unresolved_and_no_tests(factory, settings, indexed):
    report = _analyze(factory, settings, indexed.repository_id,
                      target_file="java/src/main/java/com/acme/shipping/ShippingFactory.java",
                      change_description="factory reads kind from configuration", max_depth=2)
    assert any(u.direction == "from_target" and "forName" in u.reference
               for u in report.unresolved_relationships)
    assert report.related_tests == []
    assert any("No tests" in m for m in report.missing_information)


def test_analysis_is_persisted_and_retrievable(factory, settings, indexed):
    report = _analyze(factory, settings, indexed.repository_id, target_symbol="format_money",
                      change_description="format with locale")
    from tracelens.models import ImpactAnalysis
    from tracelens.schemas.impact import ImpactReport

    with factory() as s:
        row = s.get(ImpactAnalysis, report.analysis_id)
        assert row is not None and row.generated_by == "deterministic"
        assert ImpactReport.model_validate(row.report).analysis_id == report.analysis_id
