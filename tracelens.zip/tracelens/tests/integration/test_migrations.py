from __future__ import annotations

import pytest
from sqlalchemy import text

pytestmark = pytest.mark.integration


def test_core_schema_present(database):
    engine, _ = database
    with engine.connect() as conn:
        tables = {r[0] for r in conn.execute(text(
            "SELECT table_name FROM information_schema.tables WHERE table_schema='public'"))}
        assert {"repositories", "snapshots", "indexed_files", "symbols", "edges", "chunks",
                "impact_analyses", "alembic_version"} <= tables
        gen = conn.execute(text(
            "SELECT is_generated FROM information_schema.columns "
            "WHERE table_name='chunks' AND column_name='tsv'")).scalar()
        assert gen == "ALWAYS"
        idx = {r[0] for r in conn.execute(text(
            "SELECT indexname FROM pg_indexes WHERE tablename='chunks'"))}
        assert "ix_chunks_tsv" in idx


def test_edge_constraints_reject_resolved_edge_without_target(database, factory):
    from sqlalchemy.exc import IntegrityError

    engine, _ = database
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO repositories (id, name) VALUES "
                          "('00000000-0000-0000-0000-000000000001','r')"))
        conn.execute(text("INSERT INTO snapshots (id, repository_id, status) VALUES "
                          "('00000000-0000-0000-0000-000000000002',"
                          "'00000000-0000-0000-0000-000000000001','RUNNING')"))
        conn.execute(text(
            "INSERT INTO indexed_files (id, snapshot_id, rel_path, language, sha256, size_bytes,"
            " line_count, content) VALUES ('00000000-0000-0000-0000-000000000003',"
            "'00000000-0000-0000-0000-000000000002','a.py','python','x',1,1,'x')"))
        conn.execute(text(
            "INSERT INTO symbols (id, snapshot_id, file_id, kind, name, qualified_name, language,"
            " start_line, end_line) VALUES ('00000000-0000-0000-0000-000000000004',"
            "'00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000003',"
            "'function','f','a.f','python',1,1)"))
    with pytest.raises(IntegrityError):
        with engine.begin() as conn:
            conn.execute(text(
                "INSERT INTO edges (id, snapshot_id, edge_type, status, src_symbol_id, file_id,"
                " line, evidence) VALUES (gen_random_uuid(),"
                "'00000000-0000-0000-0000-000000000002','CALLS','RESOLVED',"
                "'00000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000003',"
                "1,'x')"))
    with pytest.raises(IntegrityError):  # invalid snapshot status
        with engine.begin() as conn:
            conn.execute(text("UPDATE snapshots SET status='DONE'"))
