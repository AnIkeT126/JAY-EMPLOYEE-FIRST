from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from tests.conftest import make_settings
from tracelens.main import create_app

pytestmark = pytest.mark.integration


@pytest.fixture()
def client(factory, settings):
    with TestClient(create_app(settings)) as c:
        yield c


def test_health_and_system_info(client):
    assert client.get("/health/live").json() == {"status": "ok"}
    ready = client.get("/health/ready")
    assert ready.status_code in (200, 503)
    assert ready.json()["checks"]["database"] == "ok"
    info = client.get("/api/v1/system/info").json()
    assert info["llm"]["enabled"] is False and info["embeddings"]["dimension"] == 384
    assert "/" not in info["repository_root_name"]  # no filesystem path leaks


def test_index_search_trace_impact_flow(client):
    r = client.post("/api/v1/repositories/index", json={"name": "demo"})
    assert r.status_code == 200, r.text
    repo_id = r.json()["repository_id"]
    again = client.post("/api/v1/repositories/index", json={"name": "demo"}).json()
    assert again["unchanged"] is True

    assert [x["name"] for x in client.get("/api/v1/repositories").json()] == ["demo"]
    status = client.get(f"/api/v1/repositories/{repo_id}/status").json()
    assert status["active_snapshot"]["status"] == "COMPLETED" and status["counts"]["files"] == 27

    hits = client.post("/api/v1/search", json={
        "repository_id": repo_id, "query": "apply_tax", "mode": "keyword", "top_k": 3}).json()
    assert hits["hits"][0]["symbol_name"] == "apply_tax"
    assert hits["hits"][0]["citation"]["path"] == "python/billing/tax.py"

    hybrid = client.post("/api/v1/search", json={"repository_id": repo_id, "query": "apply_tax"}).json()
    assert hybrid["mode_used"] == "keyword" and hybrid["warnings"]

    trace = client.post("/api/v1/dependencies/trace", json={
        "repository_id": repo_id, "symbol": "tax_rate_for", "direction": "upstream",
        "max_depth": 2}).json()
    assert {s["symbol"].split(".")[-1] for s in trace["steps"]} >= {"apply_tax", "calculate_total"}

    impact = client.post("/api/v1/impact/analyze", json={
        "repository_id": repo_id, "target_symbol": "tax_rate_for",
        "change_description": "unknown regions raise an error"})
    assert impact.status_code == 200, impact.text
    body = impact.json()
    assert body["generated_by"] == "deterministic"
    fetched = client.get(f"/api/v1/impact/analyses/{body['analysis_id']}")
    assert fetched.status_code == 200 and fetched.json()["analysis_id"] == body["analysis_id"]


def test_errors_use_safe_envelope(client):
    missing = client.get("/api/v1/repositories/00000000-0000-0000-0000-000000000000/status")
    assert missing.status_code == 404 and missing.json()["error"]["code"] == "not_found"
    bad = client.post("/api/v1/search", json={"query": "x"})
    assert bad.status_code == 422 and bad.json()["error"]["code"] == "validation_error"
    traversal = client.post("/api/v1/repositories/index", json={"subdirectory": "../.."})
    assert traversal.status_code == 400 and traversal.json()["error"]["code"] == "path_policy_violation"
    absolute = client.post("/api/v1/repositories/index", json={"subdirectory": "/etc"})
    assert absolute.status_code == 400
    extra = client.post("/api/v1/repositories/index", json={"path": "/etc"})
    assert extra.status_code == 422  # unknown fields are rejected, no raw path parameter exists


def test_no_active_snapshot_and_unknown_target(client):
    from sqlalchemy import text

    with client.app.state.engine.begin() as conn:
        conn.execute(text("INSERT INTO repositories (id, name) VALUES "
                          "('00000000-0000-0000-0000-0000000000aa','empty')"))
    r = client.post("/api/v1/search", json={
        "repository_id": "00000000-0000-0000-0000-0000000000aa", "query": "x", "mode": "keyword"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "no_active_snapshot"


def test_query_limits(client):
    repo_id = client.post("/api/v1/repositories/index", json={"name": "demo"}).json()["repository_id"]
    long_query = "a" * (make_settings().max_query_chars + 1)
    r = client.post("/api/v1/search", json={"repository_id": repo_id, "query": long_query})
    assert r.status_code == 400
    r = client.post("/api/v1/search", json={"repository_id": repo_id, "query": "x", "top_k": 5000})
    assert r.status_code == 400
