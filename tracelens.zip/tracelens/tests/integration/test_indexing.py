from __future__ import annotations

import pytest
from sqlalchemy import func, select

from tests.conftest import make_settings
from tracelens.errors import IndexingFailedError, IndexingInProgressError, PathPolicyError
from tracelens.indexing.service import Indexer, recover_stale_snapshots
from tracelens.models import (
    SNAPSHOT_COMPLETED,
    SNAPSHOT_FAILED,
    SNAPSHOT_RUNNING,
    Chunk,
    Edge,
    IndexedFile,
    Repository,
    Snapshot,
    Symbol,
)

pytestmark = pytest.mark.integration


def _count(session, model, snapshot_id):
    return session.execute(select(func.count()).select_from(model).where(
        model.snapshot_id == snapshot_id)).scalar_one()


def test_index_demo_repository(factory, settings):
    result = Indexer(factory, settings, None).index("demo")
    assert not result.unchanged
    assert result.stats["by_language"] == {"python": 13, "java": 10, "markdown": 4}
    assert result.stats["embeddings_enabled"] is False
    with factory() as s:
        repo = s.execute(select(Repository)).scalar_one()
        assert repo.active_snapshot_id == result.snapshot_id
        snap = s.get(Snapshot, result.snapshot_id)
        assert snap.status == SNAPSHOT_COMPLETED and snap.finished_at is not None
        assert _count(s, IndexedFile, snap.id) == 27
        assert _count(s, Symbol, snap.id) > 50
        assert _count(s, Chunk, snap.id) > 50
        unresolved = s.execute(select(func.count()).select_from(Edge).where(
            Edge.snapshot_id == snap.id, Edge.status == "UNRESOLVED")).scalar_one()
        assert unresolved >= 5


def test_reindex_without_changes_creates_no_snapshot(factory, settings):
    indexer = Indexer(factory, settings, None)
    first = indexer.index("demo")
    second = indexer.index("demo")
    assert second.unchanged and second.snapshot_id == first.snapshot_id
    with factory() as s:
        assert s.execute(select(func.count()).select_from(Snapshot)).scalar_one() == 1


def test_modification_creates_new_consistent_snapshot_and_drops_stale_edges(
        factory, demo_copy):
    settings = make_settings(repository_root=demo_copy)
    indexer = Indexer(factory, settings, None)
    first = indexer.index("demo")
    pricing = demo_copy / "python/billing/pricing.py"
    pricing.write_text(pricing.read_text().replace("return apply_tax(discounted, region)",
                                                   "return discounted"))
    (demo_copy / "docs/refunds.md").unlink()
    second = indexer.index("demo")
    assert not second.unchanged and second.snapshot_id != first.snapshot_id
    assert second.stats["changes"]["modified"] == 1 and second.stats["changes"]["deleted"] == 1
    with factory() as s:
        repo = s.execute(select(Repository)).scalar_one()
        assert repo.active_snapshot_id == second.snapshot_id
        # the removed call must not survive from the previous snapshot
        stale = s.execute(
            select(func.count()).select_from(Edge).join(Symbol, Symbol.id == Edge.src_symbol_id)
            .where(Edge.snapshot_id == second.snapshot_id, Edge.edge_type == "CALLS",
                   Symbol.qualified_name.like("%pricing.calculate_total"),
                   Edge.dst_symbol_id.in_(select(Symbol.id).where(
                       Symbol.qualified_name.like("%tax.apply_tax"))))).scalar_one()
        assert stale == 0
        # every derived row belongs to exactly one snapshot with matching file ownership
        mismatched = s.execute(
            select(func.count()).select_from(Symbol).join(IndexedFile, IndexedFile.id == Symbol.file_id)
            .where(Symbol.snapshot_id != IndexedFile.snapshot_id)).scalar_one()
        assert mismatched == 0


def test_failure_marks_snapshot_failed_and_keeps_previous_active(factory, demo_copy, monkeypatch):
    settings = make_settings(repository_root=demo_copy)
    indexer = Indexer(factory, settings, None)
    first = indexer.index("demo")
    (demo_copy / "python/billing/new_module.py").write_text("def added():\n    return 1\n")

    import tracelens.indexing.service as svc

    def boom(*args, **kwargs):
        raise RuntimeError("simulated failure while chunking")

    monkeypatch.setattr(svc, "chunk_file", boom)
    with pytest.raises(IndexingFailedError):
        indexer.index("demo")
    monkeypatch.undo()
    with factory() as s:
        repo = s.execute(select(Repository)).scalar_one()
        assert repo.active_snapshot_id == first.snapshot_id
        failed = s.execute(select(Snapshot).where(Snapshot.status == SNAPSHOT_FAILED)).scalar_one()
        assert "simulated failure" in failed.error
        assert _count(s, IndexedFile, failed.id) == 0  # nothing partial persisted
    third = indexer.index("demo")  # recovery: a later run succeeds
    assert third.snapshot_id not in (first.snapshot_id, failed.id)


def test_running_snapshot_blocks_then_stale_one_is_recovered(factory, settings):
    indexer = Indexer(factory, settings, None)
    first = indexer.index("demo")
    with factory() as s:
        repo = s.execute(select(Repository)).scalar_one()
        s.add(Snapshot(repository_id=repo.id, status=SNAPSHOT_RUNNING, stats={}))
        s.commit()
    with pytest.raises(IndexingInProgressError):
        indexer.index("demo", force=True)
    with factory() as s:  # simulate an interrupted run older than the threshold
        s.execute(Snapshot.__table__.update().where(Snapshot.status == SNAPSHOT_RUNNING)
                  .values(started_at=func.now() - func.make_interval(0, 0, 0, 0, 0, 120)))
        repo = s.execute(select(Repository)).scalar_one()
        assert recover_stale_snapshots(s, repo.id, 30) == 1
        s.commit()
    again = indexer.index("demo", force=True)
    assert again.snapshot_id != first.snapshot_id


def test_subdirectory_policy_is_enforced(factory, settings):
    indexer = Indexer(factory, settings, None)
    with pytest.raises(PathPolicyError):
        indexer.index("x", subdirectory="../outside")
    with pytest.raises(PathPolicyError):
        indexer.index("x", subdirectory="/etc")
