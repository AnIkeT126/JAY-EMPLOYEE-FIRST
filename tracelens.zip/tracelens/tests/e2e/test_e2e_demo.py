"""End-to-end acceptance: migrate -> index demo -> search -> trace -> analyze -> verify -> eval."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from tracelens.config import PROJECT_ROOT
from tracelens.main import create_app

pytestmark = pytest.mark.integration


def test_full_workflow(factory, settings, tmp_path):
    from tracelens.evaluation.runner import run_evaluation, write_reports

    with TestClient(create_app(settings)) as client:
        assert client.get("/health/ready").json()["checks"]["database"] == "ok"
        repo_id = client.post("/api/v1/repositories/index",
                              json={"name": "sample_repository"}).json()["repository_id"]
        found = client.post("/api/v1/search", json={
            "repository_id": repo_id, "query": "ShippingService estimate", "mode": "keyword"}).json()
        assert any(h["file_path"].endswith("ShippingService.java") for h in found["hits"])
        trace = client.post("/api/v1/dependencies/trace", json={
            "repository_id": repo_id, "symbol": "estimate",
            "file": "java/src/main/java/com/acme/shipping/ShippingService.java",
            "direction": "upstream", "max_depth": 2}).json()
        assert any(s["symbol"].endswith("OrderFulfillment.fulfill") for s in trace["steps"])
        report = client.post("/api/v1/impact/analyze", json={
            "repository_id": repo_id, "target_symbol": "ShippingService",
            "change_description": "ShippingService.estimate gains a destination argument",
            "max_depth": 2}).json()
        assert report["affected_components"] and report["related_tests"]
        sid = report["snapshot_id"][:8]
        for comp in report["affected_components"] + report["related_tests"]:
            for ev in comp["evidence"]:
                assert ev["citation"]["id"].endswith("@" + sid)
    result = run_evaluation(factory, settings, None, PROJECT_ROOT / "data/evaluation/cases.json")
    assert result["impact"]["static_analysis_symbol_level"]["citation_validity"] == 1.0
    write_reports(result, tmp_path)
    assert (tmp_path / "evaluation.md").exists()
