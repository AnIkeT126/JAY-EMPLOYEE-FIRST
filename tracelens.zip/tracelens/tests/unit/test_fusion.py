from __future__ import annotations

import math
import uuid

import pytest

from tracelens.retrieval.fusion import rrf_fuse
from tracelens.retrieval.types import RankedHit

A, B, C, D = (uuid.UUID(int=i) for i in range(1, 5))


def hits(*ids, score=1.0):
    return [RankedHit(i, rank, score / rank) for rank, i in enumerate(ids, start=1)]


def test_rrf_scores_match_formula():
    fused = rrf_fuse(hits(A, B, C), hits(B, D), k=60)
    score = {f.chunk_id: f.fusion_score for f in fused}
    assert score[A] == pytest.approx(1 / 61)
    assert score[B] == pytest.approx(1 / 62 + 1 / 61)
    assert score[D] == pytest.approx(1 / 62)
    assert [f.chunk_id for f in fused] == [B, A, D, C]
    assert [f.final_rank for f in fused] == [1, 2, 3, 4]


def test_rrf_deduplicates_and_keeps_raw_diagnostics():
    kw, vec = hits(A, B), hits(A)
    fused = rrf_fuse(kw, vec, k=10)
    assert len(fused) == 2
    top = fused[0]
    assert top.chunk_id == A and top.keyword_rank == 1 and top.vector_rank == 1
    assert top.keyword_score == 1.0 and top.vector_score == 1.0
    assert fused[1].vector_rank is None and fused[1].vector_score is None


def test_rrf_single_list_preserves_order_and_limit():
    fused = rrf_fuse(hits(C, A, B), [], k=60, limit=2)
    assert [f.chunk_id for f in fused] == [C, A]


def test_rrf_is_deterministic_on_ties():
    first = rrf_fuse(hits(A), hits(B), k=60)
    second = rrf_fuse(hits(A), hits(B), k=60)
    assert [f.chunk_id for f in first] == [f.chunk_id for f in second]


def test_rrf_rejects_invalid_k_and_handles_empty():
    with pytest.raises(ValueError):
        rrf_fuse([], [], k=0)
    assert rrf_fuse([], [], k=60) == []


def test_raw_scores_do_not_influence_fusion():
    low = [RankedHit(A, 1, 0.0001)]
    high = [RankedHit(B, 1, 999.0)]
    scores = {f.chunk_id: f.fusion_score for f in rrf_fuse(low, high, k=60)}
    assert math.isclose(scores[A], scores[B])
