from __future__ import annotations

import math

import pytest

from tracelens.evaluation import metrics as m


def test_recall_and_mrr():
    assert m.recall_at_k([0, 3, 0, 2], 2, 5) == 1.0
    assert m.recall_at_k([0, 3, 0, 2], 2, 2) == 0.5
    assert m.reciprocal_rank([0, 0, 1]) == pytest.approx(1 / 3)
    assert m.reciprocal_rank([0, 0]) == 0.0
    with pytest.raises(ValueError):
        m.recall_at_k([1], 0, 5)


def test_ndcg_known_value():
    # grades 3,0,2 retrieved; ideal ordering is 3,2
    dcg = (2 ** 3 - 1) / math.log2(2) + (2 ** 2 - 1) / math.log2(4)
    ideal = (2 ** 3 - 1) / math.log2(2) + (2 ** 2 - 1) / math.log2(3)
    assert m.ndcg_at_k([3, 0, 2], [3, 2], 3) == pytest.approx(dcg / ideal)
    assert m.ndcg_at_k([3, 2], [3, 2], 5) == pytest.approx(1.0)
    assert m.ndcg_at_k([], [0], 3) == 0.0


def test_set_precision_recall_edge_cases():
    assert m.set_precision_recall({"a", "b"}, {"a", "c"}) == (0.5, 0.5)
    assert m.set_precision_recall(set(), set()) == (1.0, 1.0)
    assert m.set_precision_recall(set(), {"a"}) == (1.0, 0.0)
    assert m.set_precision_recall({"a"}, set()) == (0.0, 1.0)


def test_mean_empty():
    assert m.mean([]) == 0.0
