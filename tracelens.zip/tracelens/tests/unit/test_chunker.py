from __future__ import annotations

from tracelens.analysis.python_parser import parse_python
from tracelens.indexing.chunker import chunk_file, search_tokens
from tracelens.indexing.discovery import SourceFile

PY = '''"""doc"""
import os

X = 1


class A:
    """cls"""

    def m(self):
        return 1

    def n(self):
        return 2


def f():
    return 3
'''


def _src(content, path="a.py", lang="python"):
    return SourceFile(path, lang, content, "0" * 64, len(content), len(content.splitlines()), False)


def test_search_tokens_split_identifiers_and_keep_whole():
    assert "calculatetotal" in search_tokens("calculateTotal")
    assert search_tokens("calculate_total") == ["calculatetotal", "calculate", "total"]
    assert search_tokens("HTTPServer2") == ["httpserver2", "http", "server", "2"]


def test_python_chunks_follow_symbols():
    src = _src(PY)
    chunks = chunk_file(src, parse_python(PY, "a.py", False), 120, 10)
    by_name = {c.symbol_name: c for c in chunks}
    assert by_name["m"].start_line == 10 and by_name["m"].end_line == 11
    assert by_name["A"].end_line < by_name["m"].start_line  # class header only
    assert by_name["f"].content.strip().startswith("def f")
    assert by_name["module"].kind == "module"  # imports / constants gap
    assert all(c.content.strip() for c in chunks)


def test_oversized_symbol_is_windowed_with_overlap():
    body = "def big():\n" + "".join(f"    x{i} = {i}\n" for i in range(50))
    src = _src(body)
    chunks = chunk_file(src, parse_python(body, "a.py", False), 20, 5)
    assert len(chunks) >= 3
    assert all(c.end_line - c.start_line + 1 <= 20 for c in chunks)
    assert chunks[1].start_line == chunks[0].end_line - 5 + 1


def test_markdown_sections_ignore_headings_in_code_fences():
    md = "intro\n\n# One\ntext\n```\n# not a heading\n```\n## Two\nmore\n"
    chunks = chunk_file(_src(md, "d.md", "markdown"), None, 120, 10)
    assert [c.symbol_name for c in chunks] == ["(preamble)", "One", "Two"]


def test_parse_failure_falls_back_to_window():
    bad = "def broken(:\n    pass\n"
    chunks = chunk_file(_src(bad), parse_python(bad, "a.py", False), 120, 10)
    assert len(chunks) == 1 and chunks[0].kind == "window"
