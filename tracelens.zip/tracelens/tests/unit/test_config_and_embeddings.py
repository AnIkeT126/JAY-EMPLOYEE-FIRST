from __future__ import annotations

import uuid

import pytest
from pydantic import ValidationError

from tracelens.config import Settings
from tracelens.errors import EmbeddingError
from tracelens.retrieval.citations import make_citation, parse_citation
from tracelens.retrieval.embeddings import validate_dimensions


def test_defaults_work_without_llm():
    s = Settings(_env_file=None)
    assert s.llm_provider == "none" and not s.llm_enabled
    assert s.embedding_dim == 384 and s.rrf_k == 60


def test_invalid_configuration_is_rejected():
    with pytest.raises(ValidationError):
        Settings(_env_file=None, api_port=0)
    with pytest.raises(ValidationError):
        Settings(_env_file=None, default_top_k=100, max_top_k=10)
    with pytest.raises(ValidationError):
        Settings(_env_file=None, llm_provider="openai-compatible")  # model/base URL missing
    with pytest.raises(ValidationError):
        Settings(_env_file=None, chunk_overlap_lines=500, max_chunk_lines=120)


def test_embedding_dimension_validation():
    validate_dimensions([[0.0] * 4, [1.0] * 4], 4)
    with pytest.raises(EmbeddingError):
        validate_dimensions([[0.0] * 3], 4)


def test_citation_roundtrip():
    sid = uuid.uuid4()
    c = make_citation(sid, "a/b.py", 3, 9)
    assert parse_citation(c.id) == ("a/b.py", 3, 9, str(sid)[:8])
    assert parse_citation("garbage") is None
