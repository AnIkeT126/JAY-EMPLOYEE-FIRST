"""Static analysis of the synthetic demo repository (no database needed)."""

from __future__ import annotations

import pytest

from tests.conftest import DEMO
from tracelens.analysis.resolver import build_edges
from tracelens.indexing.discovery import discover_files
from tracelens.indexing.service import _parse


@pytest.fixture(scope="module")
def graph():
    found = discover_files(DEMO, ignored_dirs=[], ignored_patterns=[], max_file_bytes=500_000,
                           max_files=1000)
    parsed = [p for p in (_parse(f) for f in found.files) if p is not None]
    edges = build_edges(parsed)
    names = {s.id: s.qualified_name for p in parsed for s in p.symbols}
    starts = {s.id: s.start_line for p in parsed for s in p.symbols}
    return edges, names, starts


def _has(graph, etype, src, dst, status="RESOLVED"):
    edges, names, _ = graph
    return any(e.edge_type == etype and e.status == status and names[e.src_id].endswith(src)
               and e.dst_id is not None and names[e.dst_id].endswith(dst) for e in edges)


def test_python_calls_resolved(graph):
    assert _has(graph, "CALLS", "tax.apply_tax", "tax.tax_rate_for")
    assert _has(graph, "CALLS", "pricing.calculate_total", "tax.apply_tax")  # via from-import
    assert _has(graph, "CALLS", "Invoice.total", "pricing.calculate_total")
    assert _has(graph, "CALLS", "Invoice.render", "Invoice.total")  # self.method
    assert _has(graph, "CALLS", "reporting.monthly_report", "pricing.calculate_total")  # module alias
    assert _has(graph, "CALLS", "checkout.checkout", "Invoice.total")  # variable of constructed type
    assert _has(graph, "CALLS", "checkout.checkout", "StripeLikeGateway.charge")
    assert _has(graph, "CALLS", "checkout.checkout", "Invoice.__init__")


def test_python_inheritance_and_tests(graph):
    assert _has(graph, "EXTENDS", "StripeLikeGateway", "BaseGateway")
    assert _has(graph, "TESTS", "test_tax.test_tax_rate_known_region", "tax.tax_rate_for")
    assert _has(graph, "TESTS", "test_invoice.test_invoice_total_positive", "Invoice.total")
    assert not _has(graph, "CALLS", "test_tax.test_tax_rate_known_region", "tax.tax_rate_for")


def test_java_resolution(graph):
    assert _has(graph, "IMPLEMENTS", "FlatRateProvider", "ShippingProvider")
    assert _has(graph, "IMPLEMENTS", "ExpressProvider", "ShippingProvider")
    assert _has(graph, "CALLS", "ShippingService.estimate", "ShippingProvider.quote")
    assert _has(graph, "CALLS", "OrderFulfillment.fulfill", "ShippingService.estimate")
    assert _has(graph, "CALLS", "ShippingFactory.create", "ExpressProvider")
    assert _has(graph, "CALLS", "OrderFulfillment.quickQuote", "ShippingFactory.create")
    assert _has(graph, "IMPORTS", "OrderFulfillment.java", "ShippingService")
    assert _has(graph, "TESTS", "FlatRateProviderTest.quoteIncludesWeightSurcharge",
                "FlatRateProvider.quote")


def test_java_overloads_resolved_by_arity_only(graph):
    edges, names, _ = graph
    self_call = [e for e in edges if e.edge_type == "CALLS" and e.status == "RESOLVED"
                 and names[e.src_id].endswith("ExpressProvider.quote")
                 and e.dst_id is not None and names[e.dst_id].endswith("ExpressProvider.quote")]
    assert len(self_call) == 1  # quote(parcel, 2) picks the 2-argument overload
    interface_edge = next(e for e in edges if e.note and "dynamic dispatch" in e.note)
    assert "FlatRateProvider" in interface_edge.note and "ExpressProvider" in interface_edge.note


def test_unresolved_relationships_are_recorded_not_guessed(graph):
    edges, names, _ = graph
    unresolved = {(names[e.src_id], e.dst_ref) for e in edges if e.status == "UNRESOLVED"}
    assert any(s.endswith("refunds.refund") and r == "processor.process" for s, r in unresolved)
    assert any(r == "importlib.import_module" for _s, r in unresolved)
    assert any(r == "getattr" for _s, r in unresolved)
    assert any(s.endswith("ShippingFactory.createByName") and r == "Class.forName"
               for s, r in unresolved)
    assert any(s.endswith("OrderFulfillment.quickQuote") and r == "provider.quote"
               for s, r in unresolved)
    # the ambiguous call must not have produced a resolved edge to either processor
    assert not any(names[e.src_id].endswith("refunds.refund") and e.status == "RESOLVED"
                   and e.edge_type == "CALLS" for e in edges)


def test_every_resolved_edge_has_a_target_and_unresolved_has_reason(graph):
    edges, _, _ = graph
    for e in edges:
        if e.status == "RESOLVED":
            assert e.dst_id is not None
        else:
            assert e.dst_id is None and e.note


def test_calls_inside_overloads_are_attributed_to_the_correct_overload(graph):
    edges, names, starts = graph
    # ShippingService: estimate(Parcel) is declared before estimate(Parcel, double)
    estimates = sorted((starts[e.src_id], e) for e in edges
                       if names[e.src_id].endswith("ShippingService.estimate")
                       and e.edge_type == "CALLS" and e.dst_id is not None)
    by_start = {}
    for start, e in estimates:
        by_start.setdefault(start, []).append(names[e.dst_id])
    first, second = sorted(by_start)
    assert by_start[first] == ["com.acme.shipping.ShippingProvider.quote"]  # 1-arg calls provider
    assert by_start[second] == ["com.acme.shipping.ShippingService.estimate"]  # 2-arg calls 1-arg
    called = next(e for s, e in estimates if s == second)
    assert starts[called.dst_id] == first  # and resolves to the one-argument overload by arity
