"""LLM tool schemas are strict and read-only (no database needed for validation paths)."""

from __future__ import annotations

import json
import uuid

import pytest
from pydantic import ValidationError

from tracelens.llm.tools import (
    FindSymbolArgs,
    GetSourceRangeArgs,
    SearchCodeArgs,
    TraceDependenciesArgs,
    tool_definitions,
)


def test_exactly_the_five_documented_tools():
    names = {t["function"]["name"] for t in tool_definitions()}
    assert names == {"search_code", "find_symbol", "get_source_range", "trace_dependencies",
                     "find_related_tests"}


@pytest.mark.parametrize("model,payload", [
    (SearchCodeArgs, {"query": "x"}),  # too short
    (SearchCodeArgs, {"query": "ok query", "top_k": 99}),
    (SearchCodeArgs, {"query": "ok query", "root": "/etc"}),  # unknown field (extra=forbid)
    (FindSymbolArgs, {"name": ""}),
    (GetSourceRangeArgs, {"path": "a.py", "start_line": 0, "end_line": 3}),
    (TraceDependenciesArgs, {"symbol": "f", "depth": 50}),
    (TraceDependenciesArgs, {"symbol": "f", "direction": "sideways"}),
])
def test_invalid_tool_arguments_rejected(model, payload):
    with pytest.raises(ValidationError):
        model.model_validate(payload)


def test_executor_returns_error_json_for_bad_calls():
    from tests.conftest import make_settings
    from tracelens.llm.tools import ToolExecutor

    executor = ToolExecutor(None, make_settings(), None, uuid.uuid4())  # type: ignore[arg-type]
    for name, args in [("rm_rf", "{}"), ("search_code", '{"query": "x"}'),
                       ("get_source_range", "not json")]:
        out = json.loads(executor.run(name, args))
        assert out["untrusted_content"] is True and "error" in out["data"]
