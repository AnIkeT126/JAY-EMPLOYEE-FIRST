from __future__ import annotations

from tracelens.analysis.python_parser import module_name_for, parse_python

SRC = '''
import os
from pkg.util import helper as h

class Base:
    pass

class Child(Base):
    def __init__(self):
        self.repo = Repo()

    def run(self, x):
        h(x)
        self.repo.save(x)
        return self.other()

def top(a: "Repo"):
    r = Repo()
    r.save(a)
    getattr(os, "x")()
'''


def test_module_name_for():
    assert module_name_for("pkg/mod.py") == "pkg.mod"
    assert module_name_for("pkg/__init__.py") == "pkg"


def test_symbols_and_lines():
    parsed = parse_python(SRC, "pkg/mod.py", False)
    by_q = {s.qualified_name: s for s in parsed.symbols}
    assert by_q["pkg.mod"].kind == "module"
    assert by_q["pkg.mod.Child"].kind == "class"
    assert by_q["pkg.mod.Child.run"].kind == "method"
    assert by_q["pkg.mod.Child.run"].arity == 1
    assert by_q["pkg.mod.top"].kind == "function"
    assert by_q["pkg.mod.top"].start_line < by_q["pkg.mod.top"].end_line


def test_refs_extracted():
    parsed = parse_python(SRC, "pkg/mod.py", False)
    kinds = {(r.kind, r.target) for r in parsed.refs}
    assert ("EXTENDS", "Base") in kinds
    assert ("IMPORT", "os") in kinds
    assert ("CALL", "self.repo.save") in kinds
    assert ("CALL", "getattr") in kinds
    imp = next(r for r in parsed.refs if r.kind == "IMPORT" and r.target == "pkg.util")
    assert imp.names == ["helper"]
    assert parsed.attr_types["pkg.mod.Child"] == {"repo": "Repo"}
    save = next(r for r in parsed.refs if r.target == "r.save")
    assert save.receiver_type == "Repo"


def test_syntax_error_is_reported_not_raised():
    parsed = parse_python("def broken(:\n", "bad.py", False)
    assert parsed.error and parsed.symbols == []


def test_decorator_included_in_symbol_range():
    parsed = parse_python("@deco\ndef f():\n    pass\n", "m.py", False)
    f = next(s for s in parsed.symbols if s.name == "f")
    assert f.start_line == 1
