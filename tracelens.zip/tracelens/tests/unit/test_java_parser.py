from __future__ import annotations

from tracelens.analysis.java_parser import parse_java

SRC = '''package com.acme.x;

import com.acme.y.Dep;
import static org.junit.Assert.assertEquals;
import java.util.*;

public class A extends B implements C, D {
    private final Dep dep;
    private final List<Dep> many = new ArrayList<>();

    public A(Dep dep) { this.dep = dep; }

    public int run(int a) {
        var local = new Dep();
        dep.go(a);
        local.stop();
        return helper(a, 2);
    }

    int helper(int a, int b) { return a + b; }
    int helper(int a) { return a; }
}

interface C extends E { void m(); }
'''


def test_symbols():
    parsed = parse_java(SRC, "A.java", False)
    q = {s.qualified_name: s for s in parsed.symbols}
    assert parsed.module_qname == "com.acme.x"
    assert q["com.acme.x.A"].kind == "class"
    assert q["com.acme.x.C"].kind == "interface"
    assert q["com.acme.x.A.run"].kind == "method"
    assert q["com.acme.x.A.A"].kind == "constructor"
    assert q["com.acme.x.A.run"].arity == 1
    assert q["com.acme.x.A.run"].start_line == 13


def test_inheritance_and_imports():
    parsed = parse_java(SRC, "A.java", False)
    refs = {(r.kind, r.src_qname, r.target) for r in parsed.refs}
    assert ("EXTENDS", "com.acme.x.A", "B") in refs
    assert ("IMPLEMENTS", "com.acme.x.A", "C") in refs
    assert ("IMPLEMENTS", "com.acme.x.A", "D") in refs
    assert ("EXTENDS", "com.acme.x.C", "E") in refs
    imports = {r.target: r for r in parsed.refs if r.kind == "IMPORT"}
    assert imports["com.acme.y.Dep"].static is False
    assert imports["org.junit.Assert.assertEquals"].static is True
    assert imports["java.util"].names == ["*"]


def test_calls_carry_receiver_types_and_arity():
    parsed = parse_java(SRC, "A.java", False)
    calls = {r.target: r for r in parsed.refs if r.kind == "CALL"}
    assert calls["dep.go"].receiver_type == "Dep"
    assert calls["local.stop"].receiver_type == "Dep"  # var inferred from `new Dep()`
    assert calls["helper"].arg_count == 2
    assert calls["new Dep"].receiver_type == "Dep"


def test_syntax_errors_are_flagged():
    parsed = parse_java("class { void ( }", "Bad.java", False)
    assert parsed.error
