"""Security-focused unit tests (no database)."""

from __future__ import annotations

import json
import os

import pytest

from tracelens.api.errors import register_error_handlers
from tracelens.config import Settings
from tracelens.errors import PathPolicyError
from tracelens.indexing.discovery import discover_files, resolve_within
from tracelens.retrieval.keyword import build_tsquery, like_prefix


def test_tsquery_contains_only_safe_tokens():
    q = build_tsquery("'; DROP TABLE chunks; -- & | ! ( ) :*")
    assert q is not None
    assert all(tok.isalnum() for tok in q.replace(" | ", " ").split())
    assert build_tsquery("!!! ???") is None


def test_like_prefix_escapes_wildcards():
    assert like_prefix("a%b_c\\") == "a\\%b\\_c\\\\%"


def test_secrets_are_not_printed_in_settings_repr():
    s = Settings(_env_file=None, llm_provider="openai-compatible", llm_model="m",
                 llm_base_url="http://localhost:1", llm_api_key="super-secret-value")
    assert "super-secret-value" not in repr(s) and "super-secret-value" not in str(s.model_dump())


def test_symlinked_directory_is_not_followed(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.py").write_text("PASSWORD = 'x'\n")
    root = tmp_path / "root"
    root.mkdir()
    os.symlink(outside, root / "linkdir")
    (root / "ok.py").write_text("x = 1\n")
    found = discover_files(root, ignored_dirs=[], ignored_patterns=[], max_file_bytes=10_000,
                           max_files=10)
    assert [f.rel_path for f in found.files] == ["ok.py"]


@pytest.mark.parametrize("bad", ["..", "../", "a/../..", "..\\..", "/abs"])
def test_traversal_variants_rejected(tmp_path, bad):
    with pytest.raises(PathPolicyError):
        resolve_within(tmp_path, bad)


def test_error_envelope_hides_internal_details():
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    app = FastAPI()
    register_error_handlers(app)

    @app.get("/boom")
    def boom():
        raise RuntimeError("password=hunter2 at /home/user/secret.py")

    r = TestClient(app, raise_server_exceptions=False).get("/boom")
    assert r.status_code == 500
    assert json.dumps(r.json()) == '{"error": {"code": "internal_error", "message": "internal server error"}}'
