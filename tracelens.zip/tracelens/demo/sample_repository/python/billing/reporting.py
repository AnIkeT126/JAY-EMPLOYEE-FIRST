"""Reporting helpers."""

import importlib

from billing import pricing


def monthly_report(orders, region):
    """Sum the totals of all orders for the month."""
    totals = [pricing.calculate_total(o["items"], region) for o in orders]
    return sum(totals)


def dynamic_rule(name):
    """Load a pricing rule plug-in by name (resolved only at runtime)."""
    module = importlib.import_module("billing.rules." + name)
    return getattr(module, "apply")()
