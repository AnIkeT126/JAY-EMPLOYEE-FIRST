"""Tax calculation helpers."""

TAX_RATES = {"US": 0.07, "EU": 0.20, "UK": 0.20}
DEFAULT_RATE = 0.10


def tax_rate_for(region):
    """Return the tax rate for a region code."""
    return TAX_RATES.get(region, DEFAULT_RATE)


def apply_tax(amount, region):
    """Return the amount including tax for the region."""
    rate = tax_rate_for(region)
    return round(amount * (1 + rate), 2)
