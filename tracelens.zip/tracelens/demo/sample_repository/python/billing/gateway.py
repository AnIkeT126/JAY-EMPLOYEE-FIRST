"""Payment gateways."""


class BaseGateway:
    """Abstract payment gateway."""

    def charge(self, amount):
        raise NotImplementedError

    def refund(self, amount):
        raise NotImplementedError


class StripeLikeGateway(BaseGateway):
    """Gateway that simulates a card processor (no network access)."""

    def charge(self, amount):
        return {"status": "charged", "amount": amount}
