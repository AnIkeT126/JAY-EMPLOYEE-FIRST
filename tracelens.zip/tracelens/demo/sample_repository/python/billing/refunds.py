"""Refund processing."""


class RefundProcessor:
    def process(self, order):
        return {"refunded": order["id"]}


class LegacyRefundProcessor:
    def process(self, order):
        return {"legacy": True, "refunded": order["id"]}


def refund(order, processor):
    """Refund an order with whichever processor the caller supplies."""
    return processor.process(order)
