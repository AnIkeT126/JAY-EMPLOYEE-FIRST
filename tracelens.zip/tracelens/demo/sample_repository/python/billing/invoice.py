"""Invoices."""

from billing.formatting import format_money
from billing.pricing import calculate_total


class Invoice:
    """A customer invoice made of line items."""

    def __init__(self, items, region, discount_code=None):
        self.items = items
        self.region = region
        self.discount_code = discount_code

    def total(self):
        """Total payable amount."""
        return calculate_total(self.items, self.region, self.discount_code)

    def render(self):
        """Human readable invoice summary."""
        return "Invoice total: " + format_money(self.total())
