"""Money formatting."""


def format_money(amount, currency="USD"):
    """Format an amount for display, e.g. 'USD 1,234.50'."""
    return f"{currency} {amount:,.2f}"
