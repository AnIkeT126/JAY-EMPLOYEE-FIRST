"""Checkout flow."""

from billing.gateway import StripeLikeGateway
from billing.invoice import Invoice


def checkout(items, region, discount_code=None):
    """Create an invoice and charge it."""
    invoice = Invoice(items, region, discount_code)
    gateway = StripeLikeGateway()
    return gateway.charge(invoice.total())
