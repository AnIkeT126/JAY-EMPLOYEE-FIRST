"""Billing package of the synthetic sample repository."""
