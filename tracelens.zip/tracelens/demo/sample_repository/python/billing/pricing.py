"""Pricing: discounts and totals."""

from billing.tax import apply_tax

DISCOUNT_CODES = {"WELCOME10": 0.10, "VIP20": 0.20}


def apply_discount(subtotal, code=None):
    """Apply a discount code to a subtotal."""
    rate = DISCOUNT_CODES.get(code, 0.0)
    return subtotal * (1 - rate)


def calculate_total(items, region, discount_code=None):
    """Compute the payable total: subtotal, discount, then tax."""
    subtotal = sum(item["price"] * item["qty"] for item in items)
    discounted = apply_discount(subtotal, discount_code)
    return apply_tax(discounted, region)
