from billing.invoice import Invoice


def test_invoice_total_positive():
    invoice = Invoice([{"price": 5, "qty": 1}], "US")
    assert invoice.total() > 0


def test_invoice_render_mentions_total():
    invoice = Invoice([{"price": 5, "qty": 1}], "US")
    assert "Invoice total" in invoice.render()
