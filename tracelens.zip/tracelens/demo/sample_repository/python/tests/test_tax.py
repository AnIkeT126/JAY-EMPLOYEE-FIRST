from billing.tax import apply_tax, tax_rate_for


def test_tax_rate_known_region():
    assert tax_rate_for("US") == 0.07


def test_apply_tax_adds_rate():
    assert apply_tax(100, "US") == 107.0
