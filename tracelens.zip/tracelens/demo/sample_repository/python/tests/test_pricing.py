from billing.pricing import apply_discount, calculate_total


def test_discount_code_reduces_subtotal():
    assert apply_discount(100, "VIP20") == 80


def test_calculate_total_includes_tax():
    items = [{"price": 10, "qty": 2}]
    assert calculate_total(items, "US") == 21.4
