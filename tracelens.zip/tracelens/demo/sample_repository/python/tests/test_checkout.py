from billing.checkout import checkout


def test_checkout_charges_the_invoice_total():
    result = checkout([{"price": 10, "qty": 1}], "US")
    assert result["status"] == "charged"
