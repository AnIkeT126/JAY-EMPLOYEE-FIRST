package com.acme.shipping;

/** Flat base rate plus a per-kilogram surcharge. */
public class FlatRateProvider implements ShippingProvider {
    private static final double RATE = 4.5;

    @Override
    public double quote(Parcel parcel) {
        return RATE + parcel.getWeightKg() * 0.5;
    }
}
