package com.acme.shipping;

/** Express delivery; price falls with the number of delivery days. */
public class ExpressProvider implements ShippingProvider {
    @Override
    public double quote(Parcel parcel) {
        return quote(parcel, 2);
    }

    public double quote(Parcel parcel, int days) {
        return 12.0 + parcel.getWeightKg() * 1.5 / days;
    }
}
