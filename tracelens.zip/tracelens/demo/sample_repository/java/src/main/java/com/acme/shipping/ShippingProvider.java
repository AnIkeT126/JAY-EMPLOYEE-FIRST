package com.acme.shipping;

/** A carrier that can price the shipment of a parcel. */
public interface ShippingProvider {
    double quote(Parcel parcel);
}
