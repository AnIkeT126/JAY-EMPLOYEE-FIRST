package com.acme.orders;

import com.acme.shipping.Parcel;
import com.acme.shipping.ShippingFactory;
import com.acme.shipping.ShippingService;

/** Fulfils orders by estimating their shipping cost. */
public class OrderFulfillment {
    private final ShippingService shipping;

    public OrderFulfillment(ShippingService shipping) {
        this.shipping = shipping;
    }

    public double fulfill(Parcel parcel) {
        return shipping.estimate(parcel);
    }

    public double quickQuote(String kind, Parcel parcel) {
        var provider = ShippingFactory.create(kind);
        return provider.quote(parcel);
    }
}
