package com.acme.shipping;

/** Creates shipping providers. */
public final class ShippingFactory {
    private ShippingFactory() {
    }

    public static ShippingProvider create(String kind) {
        if ("express".equals(kind)) {
            return new ExpressProvider();
        }
        return new FlatRateProvider();
    }

    public static ShippingProvider createByName(String className) throws Exception {
        return (ShippingProvider) Class.forName(className).getDeclaredConstructor().newInstance();
    }
}
