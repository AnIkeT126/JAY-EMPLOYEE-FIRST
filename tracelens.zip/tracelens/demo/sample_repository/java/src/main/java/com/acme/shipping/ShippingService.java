package com.acme.shipping;

/** Estimates shipping cost through a pluggable provider. */
public class ShippingService {
    private final ShippingProvider provider;

    public ShippingService(ShippingProvider provider) {
        this.provider = provider;
    }

    public double estimate(Parcel parcel) {
        return provider.quote(parcel);
    }

    public double estimate(Parcel parcel, double handlingFee) {
        return estimate(parcel) + handlingFee;
    }
}
