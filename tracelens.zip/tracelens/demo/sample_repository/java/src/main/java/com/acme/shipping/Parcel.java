package com.acme.shipping;

/** A parcel to be shipped. */
public class Parcel {
    private final double weightKg;

    public Parcel(double weightKg) {
        this.weightKg = weightKg;
    }

    public double getWeightKg() {
        return weightKg;
    }
}
