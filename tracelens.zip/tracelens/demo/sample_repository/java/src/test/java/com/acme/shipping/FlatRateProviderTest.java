package com.acme.shipping;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FlatRateProviderTest {
    @Test
    public void quoteIncludesWeightSurcharge() {
        FlatRateProvider provider = new FlatRateProvider();
        assertEquals(5.0, provider.quote(new Parcel(1.0)), 0.001);
    }
}
