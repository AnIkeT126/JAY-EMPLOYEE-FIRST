package com.acme.orders;

import static org.junit.Assert.assertEquals;

import com.acme.shipping.FlatRateProvider;
import com.acme.shipping.Parcel;
import com.acme.shipping.ShippingService;
import org.junit.Test;

public class OrderFulfillmentTest {
    @Test
    public void fulfillReturnsTheShippingQuote() {
        OrderFulfillment fulfillment = new OrderFulfillment(new ShippingService(new FlatRateProvider()));
        assertEquals(5.0, fulfillment.fulfill(new Parcel(1.0)), 0.001);
    }
}
