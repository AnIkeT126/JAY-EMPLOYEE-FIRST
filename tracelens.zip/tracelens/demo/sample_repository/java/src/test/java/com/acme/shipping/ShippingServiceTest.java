package com.acme.shipping;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ShippingServiceTest {
    @Test
    public void estimateUsesTheProvider() {
        ShippingService service = new ShippingService(new FlatRateProvider());
        assertEquals(5.0, service.estimate(new Parcel(1.0)), 0.001);
    }

    @Test
    public void estimateAddsHandlingFee() {
        ShippingService service = new ShippingService(new ExpressProvider());
        double value = service.estimate(new Parcel(2.0), 1.5);
        assertEquals(14.0, value, 0.001);
    }
}
