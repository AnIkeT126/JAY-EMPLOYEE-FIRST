# Sample repository (synthetic)

Synthetic code used to demonstrate and evaluate TraceLens. It is not a real system.
It contains a small Python billing library, a small Java shipping/order library, tests, and
Markdown documentation. Some references are intentionally ambiguous or reflective so that
TraceLens' "unresolved relationship" handling can be demonstrated.
