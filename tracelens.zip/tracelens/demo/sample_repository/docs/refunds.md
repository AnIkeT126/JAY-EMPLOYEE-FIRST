# Refunds

`refund` hands an order to a processor object supplied by the caller. Two processors exist:
`RefundProcessor` and `LegacyRefundProcessor`; both expose `process`. Because the processor
is passed in, it is not possible to tell statically which one a given call will use.
