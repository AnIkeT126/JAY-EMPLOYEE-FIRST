# Billing

## Totals

`calculate_total` computes the payable amount for a list of line items: it sums the
subtotal, applies an optional discount code with `apply_discount`, and finally adds tax with
`apply_tax`. Invoices expose the result through `Invoice.total`.

## Tax rules

`tax_rate_for` returns the tax rate for a region code (US 7%, EU and UK 20%, 10% default).
`apply_tax` multiplies an amount by one plus that rate and rounds to two decimals.

## Checkout

`checkout` builds an `Invoice`, then asks the payment gateway to charge `Invoice.total`.
`StripeLikeGateway` is a simulated gateway and never contacts a network.
