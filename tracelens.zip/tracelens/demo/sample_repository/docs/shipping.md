# Shipping

## Providers

`ShippingProvider` is the interface every carrier implements through its `quote` method.
`FlatRateProvider` charges a base rate plus a per-kilogram surcharge. `ExpressProvider`
prices faster delivery and offers an overload that takes the number of delivery days.

## Estimating cost

`ShippingService.estimate` delegates to the configured provider and can add a handling fee.
`ShippingFactory.create` picks a provider by name; `createByName` loads one by class name
using reflection, so its target is only known at runtime.

## Orders

`OrderFulfillment.fulfill` returns the shipping estimate for the parcel of an order.
