"""Alembic environment. The URL is taken from settings so no secrets live in alembic.ini."""

from __future__ import annotations

import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name, disable_existing_loggers=False)

target_metadata = None  # migrations are explicit; autogenerate is not used


def _url() -> str:
    # Allow tests to override through the Alembic config; otherwise use app settings.
    override = config.get_main_option("sqlalchemy.url")
    if override:
        return override
    env_url = os.environ.get("TRACELENS_DATABASE_URL")
    if env_url:
        return env_url
    from tracelens.config import get_settings

    return get_settings().database_url


def run_migrations_online() -> None:
    engine = create_engine(_url(), future=True)
    with engine.connect() as connection:
        # One transaction per migration: if the optional pgvector migration fails on a server
        # without the extension, the core schema migration stays applied.
        context.configure(connection=connection, target_metadata=target_metadata,
                          transaction_per_migration=True)
        with context.begin_transaction():
            context.run_migrations()
    engine.dispose()


def run_migrations_offline() -> None:
    context.configure(url=_url(), literal_binds=True, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
