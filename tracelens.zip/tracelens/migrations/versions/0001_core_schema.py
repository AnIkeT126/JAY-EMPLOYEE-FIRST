"""Core schema: repositories, snapshots, files, symbols, edges, chunks, analyses.

Revision ID: 0001
Revises:
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def _uuid_pk() -> sa.Column:
    return sa.Column("id", pg.UUID(as_uuid=True), primary_key=True)


def _snapshot_fk() -> sa.Column:
    return sa.Column(
        "snapshot_id",
        pg.UUID(as_uuid=True),
        sa.ForeignKey("snapshots.id", ondelete="CASCADE"),
        nullable=False,
    )


def _ts(name: str, nullable: bool = False) -> sa.Column:
    return sa.Column(
        name,
        sa.DateTime(timezone=True),
        server_default=None if nullable else sa.func.now(),
        nullable=nullable,
    )


def upgrade() -> None:
    op.create_table(
        "repositories",
        _uuid_pk(),
        sa.Column("name", sa.String(200), nullable=False, unique=True),
        sa.Column("subdirectory", sa.Text, nullable=False, server_default=""),
        sa.Column("active_snapshot_id", pg.UUID(as_uuid=True), nullable=True),
        _ts("created_at"),
    )
    op.create_table(
        "snapshots",
        _uuid_pk(),
        sa.Column(
            "repository_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("repositories.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("status", sa.String(16), nullable=False),
        _ts("started_at"),
        _ts("finished_at", nullable=True),
        sa.Column("error", sa.Text),
        sa.Column("stats", pg.JSONB, nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.CheckConstraint("status IN ('RUNNING','COMPLETED','FAILED')", name="ck_snapshot_status"),
    )
    op.create_index("ix_snapshots_repo_started", "snapshots", ["repository_id", "started_at"])
    op.create_foreign_key(
        "fk_repositories_active_snapshot",
        "repositories",
        "snapshots",
        ["active_snapshot_id"],
        ["id"],
        ondelete="SET NULL",
    )

    op.create_table(
        "indexed_files",
        _uuid_pk(),
        _snapshot_fk(),
        sa.Column("rel_path", sa.Text, nullable=False),
        sa.Column("language", sa.String(16), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("size_bytes", sa.BigInteger, nullable=False),
        sa.Column("line_count", sa.Integer, nullable=False),
        sa.Column("is_test", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("parse_error", sa.Text),
        sa.Column("content", sa.Text, nullable=False),
        _ts("indexed_at"),
        sa.UniqueConstraint("snapshot_id", "rel_path", name="uq_file_snapshot_path"),
    )

    op.create_table(
        "symbols",
        _uuid_pk(),
        _snapshot_fk(),
        sa.Column(
            "file_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("indexed_files.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "parent_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("symbols.id", ondelete="CASCADE"),
        ),
        sa.Column("kind", sa.String(24), nullable=False),
        sa.Column("name", sa.Text, nullable=False),
        sa.Column("qualified_name", sa.Text, nullable=False),
        sa.Column("signature", sa.Text),
        sa.Column("language", sa.String(16), nullable=False),
        sa.Column("start_line", sa.Integer, nullable=False),
        sa.Column("end_line", sa.Integer, nullable=False),
        sa.Column("is_test", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.UniqueConstraint(
            "snapshot_id", "file_id", "qualified_name", "start_line", name="uq_symbol_identity"
        ),
    )
    op.create_index("ix_symbols_snapshot_qname", "symbols", ["snapshot_id", "qualified_name"])
    op.create_index("ix_symbols_snapshot_name", "symbols", ["snapshot_id", "name"])

    op.create_table(
        "edges",
        _uuid_pk(),
        _snapshot_fk(),
        sa.Column("edge_type", sa.String(16), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column(
            "src_symbol_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("symbols.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "dst_symbol_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("symbols.id", ondelete="CASCADE"),
        ),
        sa.Column("dst_ref", sa.Text),
        sa.Column(
            "file_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("indexed_files.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("line", sa.Integer, nullable=False),
        sa.Column("evidence", sa.Text, nullable=False),
        sa.Column("note", sa.Text),
        sa.CheckConstraint(
            "edge_type IN ('DEFINES','IMPORTS','CALLS','EXTENDS','IMPLEMENTS','TESTS')",
            name="ck_edge_type",
        ),
        sa.CheckConstraint("status IN ('RESOLVED','UNRESOLVED')", name="ck_edge_status"),
        sa.CheckConstraint(
            "(status = 'RESOLVED' AND dst_symbol_id IS NOT NULL) OR status = 'UNRESOLVED'",
            name="ck_edge_resolved_has_target",
        ),
    )
    op.create_index("ix_edges_snapshot_src", "edges", ["snapshot_id", "src_symbol_id"])
    op.create_index("ix_edges_snapshot_dst", "edges", ["snapshot_id", "dst_symbol_id"])

    op.create_table(
        "chunks",
        _uuid_pk(),
        _snapshot_fk(),
        sa.Column(
            "file_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("indexed_files.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "symbol_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("symbols.id", ondelete="SET NULL"),
        ),
        sa.Column("kind", sa.String(24), nullable=False),
        sa.Column("symbol_name", sa.Text),
        sa.Column("language", sa.String(16), nullable=False),
        sa.Column("start_line", sa.Integer, nullable=False),
        sa.Column("end_line", sa.Integer, nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("content_sha", sa.String(64), nullable=False),
        sa.Column("name_text", sa.Text, nullable=False, server_default=""),
        sa.Column("search_text", sa.Text, nullable=False),
    )
    # Generated tsvector over pre-tokenised text ('simple' = no stemming/stopwords, which
    # keeps identifiers intact). Symbol/heading names get weight A so a definition outranks
    # chunks that merely mention it (weight C). See docs/DATABASE.md.
    op.execute(
        "ALTER TABLE chunks ADD COLUMN tsv tsvector GENERATED ALWAYS AS ("
        "setweight(to_tsvector('simple', name_text), 'A') || "
        "setweight(to_tsvector('simple', search_text), 'C')) STORED"
    )
    op.execute("CREATE INDEX ix_chunks_tsv ON chunks USING GIN (tsv)")
    op.create_index("ix_chunks_snapshot_file", "chunks", ["snapshot_id", "file_id"])
    op.create_index("ix_chunks_snapshot_language", "chunks", ["snapshot_id", "language"])

    op.create_table(
        "impact_analyses",
        _uuid_pk(),
        sa.Column(
            "repository_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("repositories.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "snapshot_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("snapshots.id", ondelete="SET NULL"),
        ),
        sa.Column("request", pg.JSONB, nullable=False),
        sa.Column("report", pg.JSONB, nullable=False),
        sa.Column("generated_by", sa.String(32), nullable=False),
        sa.Column("duration_ms", sa.Float, nullable=False),
        _ts("created_at"),
    )


def downgrade() -> None:
    for table in (
        "impact_analyses",
        "chunks",
        "edges",
        "symbols",
        "indexed_files",
    ):
        op.drop_table(table)
    op.drop_constraint("fk_repositories_active_snapshot", "repositories", type_="foreignkey")
    op.drop_table("snapshots")
    op.drop_table("repositories")
