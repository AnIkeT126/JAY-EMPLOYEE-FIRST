"""pgvector extension and chunk_embeddings table.

Requires the pgvector extension to be installable in the target PostgreSQL server
(the provided docker-compose uses the pgvector/pgvector image). The vector dimension is
read from TRACELENS_EMBEDDING_DIM at migration time; changing the embedding model to one
with a different dimension needs a new migration (see docs/DATABASE.md).

Revision ID: 0002
Revises: 0001
"""

import os

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg
from sqlalchemy.types import UserDefinedType

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

# Read by tracelens.database.migration_state: with embeddings disabled this revision is optional.
REQUIRES_PGVECTOR = True


class Vector(UserDefinedType):
    """Minimal pgvector column type (avoids an extra runtime dependency)."""

    cache_ok = True

    def __init__(self, dim: int) -> None:
        self.dim = int(dim)

    def get_col_spec(self, **kw) -> str:
        return f"vector({self.dim})"


def _dim() -> int:
    raw = os.environ.get("TRACELENS_EMBEDDING_DIM", "384")
    dim = int(raw)
    if not 8 <= dim <= 4096:
        raise ValueError(f"TRACELENS_EMBEDDING_DIM out of range: {dim}")
    return dim


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    op.create_table(
        "chunk_embeddings",
        sa.Column("chunk_id", pg.UUID(as_uuid=True),
                  sa.ForeignKey("chunks.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("snapshot_id", pg.UUID(as_uuid=True),
                  sa.ForeignKey("snapshots.id", ondelete="CASCADE"), nullable=False),
        sa.Column("model", sa.Text, nullable=False),
        sa.Column("embedding", Vector(_dim()), nullable=False),
    )
    op.create_index("ix_chunk_embeddings_snapshot", "chunk_embeddings", ["snapshot_id"])
    # Cosine distance, matching the query operator (<=>) used in retrieval/vector.py.
    op.execute(
        "CREATE INDEX ix_chunk_embeddings_hnsw ON chunk_embeddings "
        "USING hnsw (embedding vector_cosine_ops)"
    )


def downgrade() -> None:
    op.drop_table("chunk_embeddings")
