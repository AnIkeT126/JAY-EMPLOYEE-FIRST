# TraceLens

**Hybrid RAG + static code analysis + optional GenAI change-impact engine.**
Point TraceLens at a Python/Java/Markdown repository, ask "what breaks if I change X?", and get an
evidence-backed report: every claim carries a file path, line range, and a citation that
resolves to indexed source. It runs fully locally and **needs no paid API key**.

> Status: working prototype. Read [Known limitations](#known-limitations) and
> [docs/HANDOFF.md](docs/HANDOFF.md) (what was and was not verified) before relying on it.

## What it does

- Indexes `.py`, `.java`, `.md` files into immutable, consistent **snapshots** (PostgreSQL).
- Extracts symbols and dependency edges (`DEFINES IMPORTS CALLS EXTENDS IMPLEMENTS TESTS`) with
  Python `ast` and tree-sitter-java. Ambiguous references are stored as **unresolved** edges, never guessed.
- **Hybrid retrieval**: PostgreSQL full-text search + pgvector cosine search, fused with
  Reciprocal Rank Fusion; results carry citations.
- **Impact analysis**: bounded upstream traversal of the dependency graph + related tests + docs +
  semantic candidates, with an interpretable `high/medium/low` confidence rule.
- **Optional LLM** (OpenAI-compatible endpoint) with five read-only tools and a hard tool-call budget.
  It only writes a summary; citations are verified; failures fall back to the deterministic report.
- CLI, REST API (Swagger UI), deterministic evaluation benchmark (25 labelled cases).

## Stack

Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy (1.4/2.0-compatible API), Alembic, PostgreSQL 16 + pgvector,
Sentence Transformers (`all-MiniLM-L6-v2`, 384-d), tree-sitter-java, Typer, pytest, Ruff, mypy, Docker Compose.

## Fastest path (Linux/macOS; Docker + Python 3.11+)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"            # needs network once (PyPI)
cp .env.example .env
docker compose up -d db            # PostgreSQL 16 + pgvector on localhost:5432
alembic upgrade head               # creates tables (+ pgvector table)
tracelens doctor                   # prerequisite check
tracelens index --name sample_repository      # first run downloads the embedding model
tracelens search "calculate total discount" -r sample_repository
tracelens analyze -r sample_repository --symbol tax_rate_for \
  --change "Unknown regions must raise an error instead of using the default rate"
tracelens eval                     # benchmark -> reports/evaluation.{json,md}
tracelens serve                    # API + Swagger UI at http://127.0.0.1:8000/docs
```

No Docker, or no network for the model? See the **no-embeddings mode** in
[docs/SETUP_AND_RUN.md](docs/SETUP_AND_RUN.md#no-embeddings-mode): set
`TRACELENS_EMBEDDINGS_ENABLED=false`; keyword search, static analysis and impact reports still work.
Windows PowerShell commands are in the same document.

## Example requests

```bash
curl -s localhost:8000/api/v1/repositories      # copy the repository id
curl -s -X POST localhost:8000/api/v1/search -H 'Content-Type: application/json' \
  -d '{"repository_id":"<ID>","query":"apply_tax","mode":"hybrid","top_k":3}'
curl -s -X POST localhost:8000/api/v1/impact/analyze -H 'Content-Type: application/json' \
  -d '{"repository_id":"<ID>","target_symbol":"tax_rate_for",
       "change_description":"unknown regions raise an error","max_depth":3}'
```

## Tests and quality

```bash
pytest tests/unit tests/security                  # no database needed
TRACELENS_TEST_DATABASE_URL=postgresql+psycopg2://tracelens:tracelens@localhost:5432/tracelens_test \
  pytest                                          # + integration/e2e (needs a THROW-AWAY database)
ruff check src tests migrations && mypy src
```

Integration tests **drop and recreate the `public` schema** of the test database.

## Documentation

| Doc | Purpose |
|---|---|
| [docs/PROJECT_EXPLAINED.md](docs/PROJECT_EXPLAINED.md) | **Start here**: plain-language tour of the concepts, algorithms and code |
| [docs/SETUP_AND_RUN.md](docs/SETUP_AND_RUN.md) | Authoritative, ordered setup for a clean machine |
| [docs/HANDOFF.md](docs/HANDOFF.md) | Transfer checklist + what was verified |
| [docs/AI_AGENT_GUIDE.md](docs/AI_AGENT_GUIDE.md) / [AGENTS.md](AGENTS.md) | Operating guide for coding agents |
| [docs/CODE_FLOW.md](docs/CODE_FLOW.md) | Real runtime flow, function by function |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Modules, decisions, degradation behaviour |
| [docs/API_REFERENCE.md](docs/API_REFERENCE.md) | Every endpoint |
| [docs/DATABASE.md](docs/DATABASE.md) | Schema, migrations, consistency |
| [docs/CONFIGURATION.md](docs/CONFIGURATION.md) | Every environment variable |
| [docs/EVALUATION.md](docs/EVALUATION.md) | Dataset, metrics, measured results |
| [docs/SECURITY.md](docs/SECURITY.md) / [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) | Security model / fixes |
| [docs/VERIFICATION_REPORT.md](docs/VERIFICATION_REPORT.md) | Exact commands run and outcomes |

## Known limitations

- Static analysis only (no reflection, DI containers, runtime dispatch). Java overloads resolve by name + argument count.
- Supports Python, Java, Markdown only. The impact graph is bounded by depth (default 3) and a node limit.
- Indexing runs synchronously inside the request/CLI call. No authentication: bind to localhost only.
- Vector search, real embeddings and Docker flows are implemented but were **not executed** in the
  development sandbox (no pgvector, no model download, no Docker). See docs/HANDOFF.md.
- Retrieval/impact numbers come from a tiny synthetic repository and say little about real codebases.
