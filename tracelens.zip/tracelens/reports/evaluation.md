# TraceLens evaluation report

Generated: 2026-10-26T13:53:00+00:00  
Dataset: `cases.json` (sha256 `8e0ec5baa864`), 13 retrieval + 12 impact cases  
Snapshot: `e4e61b96-8f42-498f-96c0-84c71a4aa9a7`  
Embedding model: `None`  

## Retrieval (K=10)

| Mode | Recall@10 | MRR | nDCG@10 | Citation validity | Mean latency (ms) |
|---|---|---|---|---|---|
| keyword | 0.923 | 0.790 | 0.820 | 1.000 | 3.3 |
| vector | skipped | | | | |
| hybrid | skipped | | | | |

- `vector` skipped: VectorUnavailableError: embeddings are disabled (TRACELENS_EMBEDDINGS_ENABLED=false)

- `hybrid` skipped: TraceLensError: vector retrieval unavailable, keyword results only: embeddings are disabled (TRACELENS_EMBEDDINGS_ENABLED=false)

## Impact analysis (file-level precision/recall)

| Mode | Precision | Recall | Mean latency (ms) |
|---|---|---|---|
| keyword | 0.283 | 0.485 | 3.7 |
| vector | skipped | | |
| hybrid | skipped | | |
| deps_only | 0.990 | 0.847 | 29.7 |
| hybrid+deps | skipped | | |

- `vector` skipped: VectorUnavailableError: embeddings are disabled (TRACELENS_EMBEDDINGS_ENABLED=false)

- `hybrid` skipped: TraceLensError: vector retrieval unavailable, keyword results only: embeddings are disabled (TRACELENS_EMBEDDINGS_ENABLED=false)

- `hybrid+deps` skipped: TraceLensError: vector retrieval unavailable, keyword results only: embeddings are disabled (TRACELENS_EMBEDDINGS_ENABLED=false)

## Static analysis + retrieval report (symbol-level)

- Precision: 0.992
- Recall: 0.917
- Citation validity: 1.000
- Unresolved-reference recall: 1.000

Per-case predictions and expectations are in the JSON report.
