#!/usr/bin/env bash
# Start a throw-away PostgreSQL for tests WITHOUT Docker (needs postgres/initdb/pg_ctl on PATH).
# NOTE: this uses whatever PostgreSQL is installed; pgvector is only present if that install has
# the extension, otherwise migration 0002 / vector tests cannot run (use docker-compose instead).
set -euo pipefail
DIR="${TRACELENS_LOCAL_PG_DIR:-.local-postgres}"
PORT="${TRACELENS_LOCAL_PG_PORT:-54329}"
case "${1:-start}" in
  start)
    if [ ! -d "$DIR/data" ]; then
      mkdir -p "$DIR"
      initdb -D "$DIR/data" -U tracelens --auth=trust >/dev/null
    fi
    pg_ctl -D "$DIR/data" -o "-p $PORT -k $PWD/$DIR -c listen_addresses=127.0.0.1" \
      -l "$DIR/postgres.log" -w start
    createdb -h 127.0.0.1 -p "$PORT" -U tracelens tracelens_test 2>/dev/null || true
    echo "TRACELENS_TEST_DATABASE_URL=postgresql+psycopg2://tracelens@127.0.0.1:$PORT/tracelens_test"
    ;;
  stop)
    pg_ctl -D "$DIR/data" -m fast stop
    ;;
  *) echo "usage: $0 [start|stop]" >&2; exit 2 ;;
esac
