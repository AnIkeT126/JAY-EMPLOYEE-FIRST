#!/usr/bin/env bash
# One-shot demo (Linux/macOS): migrate, index the synthetic repo, run a sample impact analysis.
set -euo pipefail
alembic upgrade head
tracelens doctor || true
tracelens index --name sample_repository
tracelens search "calculate total discount" -r sample_repository --mode keyword
tracelens analyze -r sample_repository --symbol tax_rate_for \
  --change "Unknown regions must raise an error instead of using the default rate"
