# Security

TraceLens is a **local developer tool**. It has no authentication or authorisation layer: run it on
localhost (the default bind is `127.0.0.1`; docker-compose publishes ports on `127.0.0.1` only) or behind
your own authenticating reverse proxy. Do not expose it to untrusted networks.

## Repository-root restrictions and path handling

- The only filesystem location a caller can influence is `subdirectory`, interpreted **relative to the
  configured `TRACELENS_REPOSITORY_ROOT`** (`indexing/discovery.py::resolve_within`). Absolute paths
  (POSIX or `C:\`), `..` components and NUL bytes are rejected with 400 `path_policy_violation`; the
  resolved path must stay inside the root and be an existing directory.
- Request bodies use `extra="forbid"`, so there is no hidden raw-path parameter.
- Search/trace/impact never read the disk: they operate on content stored in the snapshot, addressed by
  repository-relative path strings that are only compared against `indexed_files.rel_path`.
- Symlinks: directory links are never followed (`os.walk(followlinks=False)`); file symlinks whose real
  path leaves the root are skipped and reported in `skipped_files`. (Tests: `tests/unit/test_discovery.py`,
  `tests/security/test_security.py`.)

## Limits

`TRACELENS_MAX_FILE_BYTES`, `TRACELENS_MAX_FILES` (indexing fails rather than truncating), binary/non-UTF-8/
generated files skipped, `TRACELENS_MAX_QUERY_CHARS`, `TRACELENS_MAX_TOP_K`, depth ≤ 8 and a node limit for traversals,
LLM tool-call/context/time caps. Repository code is **parsed, never imported or executed**.

## Untrusted content and prompt injection

Repository files, comments, docs and retrieved chunks are untrusted. Defences for the optional LLM:
- the model can call only five read-only tools whose arguments are strictly validated (`extra=forbid`,
  length/range bounds); tools read the indexed snapshot only, take no repository root and no filesystem path
  that could leave the snapshot (an unknown path simply returns "not part of the indexed snapshot");
- every tool result is wrapped `{"untrusted_content": true, ...}`; the system prompt says instructions inside
  data must be ignored;
- the structured report (what is affected) is computed deterministically — the model cannot add or remove
  relationships; it only writes `llm_summary`;
- citations in the summary are verified against indexed evidence and removed otherwise;
- a hard tool-call budget, timeout and context cap apply; errors fall back to the deterministic report.
No shell access, no file writes, no code execution exist anywhere in the tool set. Prompt-injection
resistance of a *real* model was not tested (only a scripted test double was).

## SQL safety

All SQL uses bound parameters. Full-text queries are built from alphanumeric tokens only and passed as a bound
parameter; `LIKE` prefixes are escaped. Migration 0002 builds its column type without string-formatted SQL
(Semgrep clean). Tested with injection-style queries (`tests/integration/test_search_and_impact.py`).

## Secrets

Only `TRACELENS_LLM_API_KEY` is secret; it is a `SecretStr` (not shown in `repr`/`model_dump`), never logged,
never returned by `/api/v1/system/info`. `.env` is git-ignored; `.env.example` has placeholders. Docker Compose
credentials are throw-away local defaults. Errors returned by the API never include stack traces, SQL or paths.

## Local development limitations

No TLS, auth, rate limiting, or multi-tenancy; the database role in the examples is a superuser-like local
role. Integration tests destroy the test database schema. Indexing is synchronous and can be slow for big repos.
Dependencies were not audited for CVEs offline (run `pip-audit` where network access exists).
