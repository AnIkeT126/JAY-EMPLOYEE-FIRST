# Implementation and verification report

Date: 2026-10-26. Environment: Linux, Python 3.14.6, PostgreSQL 16.15 **without pgvector** (local throw-away cluster
via `scripts/local_postgres.sh`), no Docker, PyPI/Hugging Face/Go-style package hosts blocked by the sandbox.
All dependencies were already installed in the interpreter (FastAPI 0.135.3, SQLAlchemy **1.4.54**, Pydantic 2.13.4,
Alembic 1.18.4, tree-sitter 0.26.0 + tree-sitter-java 0.23.5, pytest 8.4.2, ruff 0.15.8, mypy 1.20.0).

## Implemented functionality

Indexing with snapshots/change detection/recovery; Python (ast) and Java (tree-sitter) symbol and edge extraction with
explicit unresolved edges; source-aware chunking; PostgreSQL full-text retrieval with name-weighted ranking; pgvector
retrieval and RRF fusion; citations with validation; bounded dependency tracing; impact analysis (confidence rule,
tests, docs, semantic candidates, unresolved relationships, inheritance propagation); optional OpenAI-compatible LLM
narration with five read-only tools, budget and citation verification; REST API (11 paths); CLI (`doctor index status
search analyze eval report db-reset serve version`); 25-case benchmark; 107 tests.

## Repository structure (actual)

`src/tracelens/` {`config.py errors.py snapshots.py main.py cli.py`, `models/ database/ indexing/ analysis/ retrieval/ impact/ llm/
evaluation/ schemas/ api/{routes}`} · `migrations/versions/{0001_core_schema,0002_pgvector_embeddings}.py` · `tests/{unit,security,
integration,e2e}` · `demo/sample_repository/` (13 Python, 10 Java, 4 Markdown files) · `data/evaluation/cases.json` · `docs/` (12 files)
· `scripts/` · `Dockerfile docker-compose.yml Makefile .env.example requirements.lock alembic.ini AGENTS.md README.md`.
About 5,000 lines of Python in `src/`.

## Commands executed and actual outcomes

| Command | Outcome |
|---|---|
| `pytest tests/unit tests/security -q` | **70 passed** |
| `TRACELENS_TEST_DATABASE_URL=…54329/tracelens_test pytest tests -q -rs` | **106 passed, 1 skipped** (`test_pgvector.py`: extension unavailable) — 60 unit, 10 security, 36 integration (migrations, indexing, search/impact, LLM double, CLI, API, evaluation), 1 e2e |
| `ruff check src tests migrations` | All checks passed |
| `mypy src` | Success: no issues found in 51 source files |
| Semgrep MCP `security_check` on all 64 Python files | First pass: 2 findings (string-built SQL in migration 0002) → fixed → later full re-scan after all edits: no findings |
| `alembic upgrade head` on empty DB (no pgvector) | `0001` applied; `0002` failed with `extension "vector" is not available`; 0001 remains (`transaction_per_migration`) |
| `python -m tracelens.cli doctor` (embeddings disabled) | all required checks passed, exit 0 |
| `python -m tracelens.cli doctor` (embeddings enabled) | exit 1: migrations at 0001 vs required 0002, `chunk_embeddings` missing, model not cached (expected here) |
| `tracelens index --name sample_repository` | indexed: 27 files, 81 symbols, 130 edges (6 unresolved), 91 chunks; second run `unchanged`; `--force` creates a new snapshot |
| `tracelens search`, `analyze`, `report`, `eval` (via `python -m`) | worked; outputs reproduced in docs/EVALUATION.md and API_REFERENCE.md |
| `uvicorn tracelens.main:app` + curl: live, ready, info, openapi, /docs (200), index, status, search (keyword, degraded hybrid), trace, impact, error cases | worked as documented (11 OpenAPI paths) |

Defects found and fixed during verification (kept visible on purpose): overloaded methods shared a qualified name so calls
were attributed to the wrong overload (fixed with `RawRef.src_start_line`; regression test added); ambiguous target
resolution for class vs constructor and module vs function; keyword ranking put a test above the definition (fixed by weighting
symbol names); `render_markdown` crash (`UnboundLocalError`; covered by CLI test); migrations ran in one transaction so a
failed optional migration rolled back the core schema (fixed).

## API endpoints implemented

`GET /health/live`, `GET /health/ready`, `GET /api/v1/system/info`, `POST /api/v1/repositories/index`, `GET /api/v1/repositories`,
`GET /api/v1/repositories/{id}/status`, `POST /api/v1/repositories/{id}/reindex`, `POST /api/v1/search`,
`POST /api/v1/dependencies/trace`, `POST /api/v1/impact/analyze`, `GET /api/v1/impact/analyses/{id}`.

## Benchmark results actually measured

See [EVALUATION.md](EVALUATION.md): keyword Recall@10 0.923 / MRR 0.790 / nDCG@10 0.820; impact file-level deps_only precision 0.990 /
recall 0.847; symbol-level precision 0.992 / recall 0.917; citation validity 1.0. Vector, hybrid and hybrid+deps were **not measured**.

## Status matrix

- **Implemented and verified:** everything listed under "Commands executed", i.e. the full deterministic (no-embedding) workflow.
- **Implemented but not executed:** migration 0002 success path, pgvector storage/search/reuse (`tests/integration/test_pgvector.py` is written
  and skipped here), the real Sentence Transformers embedder, the real LLM HTTP provider, Dockerfile/compose, PowerShell scripts,
  `pip install -e .`/console script, SQLAlchemy 2.x.
- **Partially implemented:** none of the required components were left as stubs; evaluation of vector modes awaits a pgvector server.
- **Not implemented:** authentication; async/background indexing; LLM-judge metrics; `uv.lock`; Java generics-aware type resolution;
  Python type inference beyond constructor/annotation/`self.attr` heuristics.

## Deviations from the brief (explicit)

1. SQLAlchemy 2.x was unavailable offline; code is written to the 1.4/2.0-compatible API and verified on 1.4.54 only.
2. No `uv.lock`; `requirements.lock` pins direct dependencies to verified versions instead.
3. pgvector, the embedding model, Docker and the LLM provider could not be exercised, so "real embeddings" are implemented, not demonstrated.

## Remaining steps on a fresh machine

Follow [HANDOFF.md](HANDOFF.md) §3–§9, then run `tracelens eval` and replace the "not measured" rows in EVALUATION.md.
