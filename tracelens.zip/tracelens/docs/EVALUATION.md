# Evaluation

## Dataset

`data/evaluation/cases.json` (sha256 of the version used below starts `8e0ec5baa864`) over the bundled synthetic
repository `demo/sample_repository`:
- **13 retrieval cases** (`R01–R13`): a natural-language/identifier query and graded relevance labels
  (`grade` 1–3) given as `{path, symbol|null}`; a hit matches a label when the path equals and the symbol
  is null or equals the chunk's symbol name; each label can be credited by one hit only.
- **12 impact cases** (`I01–I12`): a target (symbol and/or file), a change description, a depth, and
  `expected_affected`/`expected_tests` as `{path, symbol(simple name)}`, plus `expected_unresolved`
  (substrings of references that must appear in `unresolved_relationships`).
Labels were written by hand from the demo code, not generated from tool output. One exception, disclosed:
`I07`'s labels were widened after the first run (see the `note` field) once subtype propagation made `checkout`
reachable and it was judged genuinely affected. Intentional hard cases: ambiguous receivers (`I11`),
reflection (`I10`, `I12`), interface dispatch (`I08`), overloads.

## Metrics (`evaluation/metrics.py`)

- **Recall@K** = labels credited in the top K / number of labels. **MRR** = 1 / rank of the first relevant hit
  (0 if none). **nDCG@K** with gain `2^grade − 1`, discount `log2(rank+1)`, ideal = labels sorted by grade
  (0 if the ideal DCG is 0). Retrieval cases without labels are rejected by the loader.
- **Impact precision/recall** = |predicted ∩ expected| / |predicted| and / |expected|. Edge cases: empty
  prediction → precision 1.0; empty expectation → recall 1.0 (so "no tests expected, none found" scores 1/1).
  *File-level* scoring (all modes) compares the files of predicted vs expected symbols, excluding the target's own
  files; *symbol-level* scoring (static analysis report) compares `(path, simple name)` pairs and ignores
  module/file-level import entries.
- **Citation validity** = fraction of returned citations that `validate_citation` accepts.
- **Latency** = wall-clock ms per case (single local run; indicative only).
- Modes: `keyword`, `vector`, `hybrid` (RRF), `deps_only` (static graph alone; an extra baseline) and
  `hybrid+deps` (hybrid retrieval files ∪ graph files). Optional LLM-judge metrics are **not implemented**; the
  benchmark never calls an LLM.

## Run

```bash
tracelens index --name sample_repository     # the dataset expects this repository name
tracelens eval --k 10                        # writes reports/evaluation.json + reports/evaluation.md
```
Modes that cannot run (vector/hybrid without pgvector or the model) are reported as `skipped` with the reason.

## Measured results

**Conditions (important):** run 2026-10-26 in the development sandbox with `TRACELENS_EMBEDDINGS_ENABLED=false`
on PostgreSQL 16.15 without pgvector. Therefore **vector, hybrid and hybrid+deps were NOT measured** — they are
implemented and require a pgvector server plus the downloaded model (run `tracelens eval` on a configured machine).
Tiny synthetic corpus (27 files, 91 chunks): these numbers do not predict real-world quality.

| Retrieval K=10 | Recall@10 | MRR | nDCG@10 | Citation validity | Mean latency |
|---|---|---|---|---|---|
| keyword | 0.923 | 0.790 | 0.820 | 1.000 | 3.3 ms |
| vector | not measured | | | | |
| hybrid | not measured | | | | |

| Impact (file level) | Precision | Recall | Mean latency |
|---|---|---|---|
| keyword | 0.283 | 0.485 | 3.7 ms |
| deps_only | 0.990 | 0.847 | 29.7 ms |
| vector / hybrid / hybrid+deps | not measured | | |

| Static analysis report (symbol level) | Value |
|---|---|
| Precision | 0.992 |
| Recall | 0.917 |
| Citation validity | 1.000 |
| Unresolved-reference recall | 1.000 |

Known misses/over-approximations visible in `reports/evaluation.json`: `I11` recall 0 (the call
`processor.process(order)` is deliberately left unresolved; the analysis flags it under
`unresolved_relationships` instead — see unresolved recall), `I08` precision < 1 (`ShippingFactory.create` is
reported through the implementor chain although it does not call `quote`).
For transparency: before name-weighted ranking was added to the full-text index, keyword retrieval measured
Recall@10 0.962 / MRR 0.750; the table above is the final configuration.

## Limitations

Synthetic, hand-labelled, single repository; the corpus is far smaller than the candidate limits, so
ranking effects are muted. No confidence intervals. Latency numbers include Python start-up effects
and a warm local database.
