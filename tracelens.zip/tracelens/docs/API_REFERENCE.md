# API reference

Base URL `http://127.0.0.1:8000`. Interactive docs: `/docs` (Swagger UI), `/openapi.json`.
These are exactly the endpoints implemented in `src/tracelens/api/routes/` (11 paths). Example
responses below were captured from a running server (UUIDs/timestamps shortened where noted).

**No authentication is implemented — bind to localhost only** (see [SECURITY.md](SECURITY.md)).

## Error format

Every error uses `{"error": {"code": "<code>", "message": "<text>"}}` (validation errors add `details`).
Stack traces and internal paths are never returned.

| HTTP | `code` | Meaning |
|---|---|---|
| 400 | `path_policy_violation` | Absolute path, `..`, or symlink escape in `subdirectory`; also `tracelens_error` for query/top_k limits |
| 404 | `not_found` | Unknown repository / analysis / target symbol or file |
| 409 | `no_active_snapshot`, `indexing_in_progress` | Repository not indexed yet / another index run is active |
| 422 | `validation_error`, `ambiguous_target`, `index_limit_exceeded` | Bad body (unknown fields rejected), ambiguous symbol, too many files |
| 500 | `internal_error`, `indexing_failed` | Unexpected error / indexing failure (snapshot marked FAILED) |
| 503 | `vector_search_unavailable`, `embedding_error` | `mode=vector` without pgvector/embeddings or model failure |

---

## Health and info

### `GET /health/live`
Liveness; no dependencies. → `200 {"status":"ok"}`

### `GET /health/ready`
Checks the database connection, that migrations are applied up to what the configuration requires
(with `TRACELENS_EMBEDDINGS_ENABLED=false` revision `0001` is enough), and reports vector availability.
```json
{"status":"ready","checks":{"database":"ok","migrations":"ok","vector_search":"unavailable"}}
```
`503` with `"status":"unavailable"` (DB unreachable) or `"not_ready"` (migrations behind).

### `GET /api/v1/system/info`
Version, environment, embedding/LLM configuration (no secrets), limits, retrieval constants and
`repository_root_name` (directory *name* only). Always `200`.

---

## Repositories

### `POST /api/v1/repositories/index`
Index (or re-index) a repository located **under `TRACELENS_REPOSITORY_ROOT`**. Synchronous.

| Field | Type | Rules |
|---|---|---|
| `name` | string, optional | 1–200 chars, `[A-Za-z0-9._-]`; default = directory name |
| `subdirectory` | string, default `""` | relative to the configured root; no absolute paths, no `..`, must be an existing directory that does not escape via symlinks |
| `force` | bool, default false | create a new snapshot even if nothing changed |

Unknown fields → 422 (there is deliberately no raw filesystem path parameter).
```bash
curl -s -X POST localhost:8000/api/v1/repositories/index -H 'Content-Type: application/json' \
  -d '{"name":"sample_repository"}'
```
Response `200` (`IndexResponse`): `repository_id`, `snapshot_id`, `unchanged`, `stats`, `skipped_files[]`.
Second call with no changes: `"unchanged": true` and `stats.changes = {"added":0,"deleted":0,"modified":0,"unchanged":27}`.
Errors: 400, 409, 422, 500.

### `GET /api/v1/repositories`
List of `{id, name, subdirectory, active_snapshot_id, created_at}`.

### `GET /api/v1/repositories/{repository_id}/status`
```json
{"repository":{"id":"aa55c802-…","name":"sample_repository","subdirectory":"","active_snapshot_id":"e4e61b96-…","created_at":"…"},
 "active_snapshot":{"id":"e4e61b96-…","status":"COMPLETED","started_at":"…","finished_at":"…","error":null,"stats":{"files":27,"symbols":81,"edges":130,"chunks":91,"…":"…"}},
 "latest_snapshot":{"…":"same shape; shows FAILED/RUNNING runs"},
 "counts":{"files":27,"symbols":81,"edges":130,"chunks":91},
 "embeddings_available":false}
```
Errors: 404.

### `POST /api/v1/repositories/{repository_id}/reindex`
Body (optional) `{"force": false}`. Same response/behaviour as `index`, for an existing repository. Errors: 404, 409, 422, 500.

---

## Retrieval

### `POST /api/v1/search`
| Field | Type | Rules |
|---|---|---|
| `repository_id` | uuid | required; must have an active snapshot |
| `query` | string | 1–`TRACELENS_MAX_QUERY_CHARS` (1000) |
| `mode` | `keyword`\|`vector`\|`hybrid` | default `hybrid` |
| `top_k` | int, optional | 1–`TRACELENS_MAX_TOP_K` (50); default `TRACELENS_DEFAULT_TOP_K` |
| `language` | `python`\|`java`\|`markdown`, optional | filter |
| `path_prefix` | string, optional | repository-relative prefix filter (LIKE-escaped) |

```bash
curl -s -X POST localhost:8000/api/v1/search -H 'Content-Type: application/json' \
  -d '{"repository_id":"<ID>","query":"apply_tax","mode":"keyword","top_k":1}'
```
```json
{"mode_requested":"keyword","mode_used":"keyword","warnings":[],
 "hits":[{"file_path":"python/billing/tax.py","symbol_name":"apply_tax","kind":"function","language":"python",
          "start_line":12,"end_line":15,"content":"def apply_tax(amount, region): …","snapshot_id":"e4e61b96-…",
          "keyword_rank":1,"keyword_score":4.8,"vector_rank":null,"vector_score":null,
          "fusion_score":0.01639344262295082,"final_rank":1,
          "citation":{"id":"python/billing/tax.py#L12-L15@e4e61b96","path":"python/billing/tax.py","start_line":12,"end_line":15,"snapshot_id":"e4e61b96-…"}}]}
```
With embeddings unavailable, `mode=hybrid` returns `"mode_used":"keyword"` and a warning
(`vector retrieval unavailable, keyword results only: …`); `mode=vector` returns 503.
Errors: 400 (length/top_k), 404, 409, 422, 503.

### `POST /api/v1/dependencies/trace`
| Field | Type | Rules |
|---|---|---|
| `repository_id` | uuid | required |
| `symbol` | string, optional | qualified name (exact) or simple name; ambiguous names → 422 `ambiguous_target` |
| `file` | string, optional | repository-relative path; alone = all symbols of the file; with `symbol` narrows it. At least one of `symbol`/`file` |
| `direction` | `upstream`\|`downstream` | default `upstream` (who depends on the target) |
| `max_depth` | int 1–8, optional | default `TRACELENS_MAX_TRACE_DEPTH` (3) |

Response: `snapshot_id`, `direction`, `targets[]`, `truncated`, `steps[]` (symbol, kind, file, lines, `depth`,
`is_test`, `path[]` of edges each with `edge_type`, `file_path`, `line`, `snippet`, `note`, `citation`), and `unresolved[]`
(unresolved edges leaving the target or whose reference ends in the target's name). Captured example
(`symbol=tax_rate_for`, depth 2) steps: `apply_tax`(1), `test_tax_rate_known_region`(1), `calculate_total`(2), `test_apply_tax_adds_rate`(2), plus module-level import steps.
Errors: 404, 409, 422.

---

## Impact analysis

### `POST /api/v1/impact/analyze`
| Field | Type | Rules |
|---|---|---|
| `repository_id` | uuid | required |
| `target_file` / `target_symbol` | string, optional | at least one; same resolution as `trace` |
| `change_description` | string | 3–2000 chars |
| `max_depth` | int 1–8, optional | default 3 |
| `use_llm` | bool, default false | request LLM narration; ignored (with a warning) if no provider is configured |
| `semantic_top_k` | int 1–30, default 8 | semantic candidates to return |

```bash
curl -s -X POST localhost:8000/api/v1/impact/analyze -H 'Content-Type: application/json' \
  -d '{"repository_id":"<ID>","target_symbol":"tax_rate_for","change_description":"unknown regions raise an error","max_depth":2}'
```
Response (`ImpactReport`, abridged from a real run):
```json
{"analysis_id":"01a369e7-…","repository_name":"sample_repository","snapshot_id":"e4e61b96-…",
 "target_symbol":"tax_rate_for","max_depth":2,"generated_by":"deterministic","llm_summary":null,
 "affected_components":[{"symbol":"python.billing.tax.apply_tax","name":"apply_tax","kind":"function",
   "file_path":"python/billing/tax.py","start_line":12,"end_line":15,"relationship":"CALLS","depth":1,
   "evidence_kind":"direct_static","confidence":"high","confidence_reason":"direct resolved CALLS edge to the target",
   "evidence":[{"kind":"static_edge","relationship":"CALLS","description":"CALLS edge at python/billing/tax.py:14",
     "snippet":"rate = tax_rate_for(region)","citation":{"id":"python/billing/tax.py#L14-L14@e4e61b96","path":"python/billing/tax.py","start_line":14,"end_line":14,"snapshot_id":"e4e61b96-…"},"note":null}]}],
 "related_tests":[{"symbol":"python.tests.test_tax.test_tax_rate_known_region","relationship":"TESTS","depth":1,"confidence":"high","…":"…"}],
 "semantic_candidates":[], "related_documentation":[], "unresolved_relationships":[],
 "missing_information":[], "limitations":["Static analysis only: …"], "warnings":[], "duration_ms":32.67, "created_at":"…"}
```
Report fields: `resolved_targets`, `affected_components`, `related_tests`, `semantic_candidates` (always
`evidence_kind:"semantic"`, `confidence:"low"`, unconfirmed), `related_documentation`
(`match`: `mentions_target`|`semantic`), `unresolved_relationships` (`from_target` | `possible_reference_to_target`),
`missing_information`, `limitations`, `warnings`, `generated_by` (`deterministic`|`llm+deterministic`),
`llm_summary`, `llm_notes`, `duration_ms`. Confidence rule: see [ARCHITECTURE.md](ARCHITECTURE.md).
The analysis is stored. Errors: 404, 409, 422 (incl. `ambiguous_target`).

### `GET /api/v1/impact/analyses/{analysis_id}`
Returns the stored `ImpactReport`. Errors: 404.
