# TraceLens explained (read this first)

A guided tour of what TraceLens is, how it works inside, and how the code is organised. No prior
knowledge of the project is assumed. For exact commands see [SETUP_AND_RUN.md](SETUP_AND_RUN.md).

---

## 1. What problem does it solve?

You are about to change a function. Questions you would normally answer by grepping and guessing:

- Who calls this? Who depends on those callers?
- Which tests exercise it?
- Which docs describe it?
- What am I *not* sure about?

TraceLens answers these with **evidence**: every statement points to a file, a line range and a
*citation* that resolves to real indexed source. It combines three techniques:

| Technique | What it gives | Where |
|---|---|---|
| **Static analysis** | Exact, rule-based relationships (A calls B, A extends B, test T tests B) | `analysis/` |
| **Hybrid RAG retrieval** | "Find related code/docs by words *and* meaning" | `retrieval/` |
| **Optional GenAI** | A readable summary written from the evidence | `llm/` |

Design rule: **static analysis decides what is affected; retrieval suggests what to double-check;
the LLM only explains.** A semantic match is never presented as a confirmed dependency, and the
program works fully without any LLM or paid API.

---

## 2. Key ideas in plain words

- **Snapshot** – a frozen, consistent copy of the analysed repository's index (files, symbols,
  edges, chunks). New indexing builds a *new* snapshot and switches to it atomically. This is why
  you never see half-old/half-new results.
- **Symbol** – a named thing in code: module, class, interface, function, method, constructor.
- **Edge** – a relationship between two symbols: `DEFINES`, `IMPORTS`, `CALLS`, `EXTENDS`,
  `IMPLEMENTS`, `TESTS`. Each edge stores the line and source text that proves it.
- **Unresolved edge** – a reference we *could not* pin down (e.g. `processor.process(order)` where
  two classes have `process`). We store it with the reason instead of guessing. Honesty over recall.
- **Chunk** – a slice of source (one function, one class header, one markdown section) that gets
  searched and embedded.
- **Keyword search** – PostgreSQL full-text search; great for exact identifiers.
- **Vector search** – each chunk becomes a 384-number *embedding* (from a local model) so similar
  *meaning* is close in space; stored with pgvector; compared with cosine distance.
- **RRF (Reciprocal Rank Fusion)** – merges the two ranked lists using only ranks:
  `score = Σ 1 / (k + rank)` (k = 60). Raw scores from the two engines are not comparable, so they
  are never added.
- **Citation** – `path#Lstart-Lend@snapshot8`, e.g. `python/billing/tax.py#L14-L14@e4e61b96`.
  Valid only if that file exists in that snapshot and the range is inside it.
- **Confidence** – a rule, not a probability (section 7).

---

## 3. Big picture

```mermaid
flowchart LR
    Repo[(Repository files)] -->|discover, parse, resolve, chunk, embed| IDX[Indexer]
    IDX --> DB[(PostgreSQL + pgvector\nsnapshots)]
    Q[Query / change request] --> SRCH[Search: keyword + vector -> RRF]
    Q --> IMP[Impact analyzer]
    SRCH --> DB
    IMP --> GRAPH[Dependency graph traversal] --> DB
    IMP --> SRCH
    IMP -.optional.-> LLM[LLM narrator]
    IMP --> REPORT[Impact report with citations]
```

It is a **modular monolith**: one Python package, one database. No Kafka/Redis/microservices.
Entry points: the **CLI** (`tracelens ...`) and the **REST API** (FastAPI, Swagger at `/docs`).
Both call the same service classes; route handlers and CLI commands contain no business logic.

---

## 4. Dependencies (what you must install on a new machine)

**System**

| Need | Why |
|---|---|
| Python 3.11 or newer | the app |
| Docker + Docker Compose v2 (recommended) | runs PostgreSQL 16 with the pgvector extension via `docker compose up -d db` |
| *or* PostgreSQL 14+ with the pgvector extension | alternative to Docker (without pgvector use "no-embeddings mode") |
| Internet, once | PyPI packages, the Docker image, and the embedding model (~90 MB from Hugging Face) |

**Python packages** (installed automatically by `pip install -e ".[dev]"`; exact tested versions in
`requirements.lock`)

| Package | Used for |
|---|---|
| fastapi, uvicorn | REST API + server |
| pydantic, pydantic-settings | request/response schemas, validated configuration |
| sqlalchemy, psycopg2-binary | database access (PostgreSQL driver) |
| alembic | schema migrations |
| sentence-transformers (pulls in torch) | local embedding model `all-MiniLM-L6-v2` (384 dims). Big install (~1–2 GB disk) |
| tree-sitter, tree-sitter-java | Java parsing (Python uses the standard-library `ast`) |
| httpx | calls the optional LLM endpoint |
| typer | CLI |
| dev: pytest, ruff, mypy | tests, lint, type-check |

No paid API key is needed. An LLM is optional.

**Honest caveat:** in the original sandbox, Docker, pgvector, the model download, `pip install -e .` and
SQLAlchemy 2.x could not be exercised; everything else was run (see [HANDOFF.md](HANDOFF.md) §8). Expect
to do a first-run check on your machine with `tracelens doctor`.

---

## 5. Repository layout

```
tracelens/
├── src/tracelens/          the application (details below)
├── migrations/versions/    0001 core schema, 0002 pgvector table
├── demo/sample_repository/ synthetic Python+Java+Markdown code to analyse
├── data/evaluation/        25 labelled benchmark cases
├── tests/                  unit, security, integration, e2e
├── docs/                   all documentation
├── scripts/                demo + local-postgres helpers
├── docker-compose.yml, Dockerfile, Makefile, .env.example, requirements.lock, alembic.ini
├── README.md, AGENTS.md
```

### `src/tracelens/` module by module

| Path | What it does |
|---|---|
| `config.py` | `Settings` (env vars with `TRACELENS_` prefix), validation, cross-field checks. `get_settings()` is cached |
| `errors.py` | Domain exceptions, each with an HTTP status and code (`PathPolicyError` → 400, `NotFoundError` → 404 ...) |
| `models/tables.py` | SQLAlchemy tables: repositories, snapshots, indexed_files, symbols, edges, chunks, impact_analyses |
| `database/session.py` | engine/session factories, `session_scope` (commit or roll back) |
| `database/migration_state.py` | compares DB revision with code; knows pgvector migration is optional when embeddings are off |
| `indexing/discovery.py` | safe file walk, path-policy checks (`resolve_within`), filters |
| `indexing/chunker.py` | chunking + `search_tokens` (shared tokeniser) |
| `indexing/service.py` | `Indexer`: snapshot lifecycle, change detection, atomic write, embedding reuse |
| `indexing/status.py` | read-side status helpers |
| `analysis/types.py` | `ParsedSymbol`, `RawRef`, `ParsedFile` dataclasses |
| `analysis/python_parser.py` | Python `ast` → symbols + raw references |
| `analysis/java_parser.py` | tree-sitter → symbols + raw references |
| `analysis/resolver.py` | raw references → resolved/unresolved edges |
| `analysis/dependency_graph.py` | target lookup, breadth-first traversal, unresolved lookup |
| `retrieval/keyword.py` | full-text search |
| `retrieval/vector.py` | pgvector insert/search/availability checks |
| `retrieval/fusion.py` | `rrf_fuse` |
| `retrieval/citations.py` | make / parse / validate citations |
| `retrieval/embeddings.py` | `Embedder` protocol + `SentenceTransformerEmbedder` |
| `retrieval/service.py` | `SearchService` (orchestrates keyword + vector + fusion + assembly) |
| `impact/analyzer.py` | `ImpactAnalyzer`: builds the report |
| `impact/render.py` | report → Markdown |
| `llm/provider.py` | `LLMProvider` protocol + OpenAI-compatible HTTP client |
| `llm/tools.py` | the five read-only tools, argument schemas, `ToolExecutor` |
| `llm/agent.py` | `ImpactNarrator`: bounded tool loop + citation validation |
| `evaluation/metrics.py`, `runner.py` | metrics, benchmark runner, report writers |
| `schemas/` | Pydantic request/response models |
| `api/` + `main.py` | FastAPI app factory, routes, error envelope |
| `cli.py` | Typer commands |

---

## 6. Indexing pipeline in detail

Entry: `Indexer.index()` → `Indexer._run()` in `indexing/service.py`.

1. **Path check.** The caller can only supply a `subdirectory` *relative to* `TRACELENS_REPOSITORY_ROOT`.
   `resolve_within` rejects absolute paths, `..`, NUL bytes and symlink escapes.
2. **Discovery** (`discover_files`). Walks the tree *without following directory symlinks*, skips ignored dirs
   (`.git`, `node_modules`, ...), oversized, binary, non-UTF-8, generated files and symlinks that point outside the root.
   Computes SHA-256, line count, and whether the file is a test (by name/path rules). Too many files → error, never silent truncation.
3. **Change detection.** Hashes are compared with the active snapshot (added / modified / deleted / unchanged).
   No change and no `--force` → "unchanged", nothing is written.
4. **Snapshot row** is created as `RUNNING` while the repository row is locked (prevents two simultaneous runs → HTTP 409).
   RUNNING snapshots older than 30 minutes are treated as crashed and marked `FAILED`.
5. **Parsing** (`parse_python`, `parse_java`). Nothing is executed or imported. Output = symbols with line ranges and *raw
   references* (what each function calls, imports, extends) with the source line as evidence.
6. **Edge resolution** (`build_edges`), see below.
7. **Chunking** (`chunk_file`): one chunk per function/method, one per class header (up to its first member), markdown sections by heading
   (ignoring `#` inside code fences), leftovers (imports/constants) as `module` chunks, oversized chunks split into overlapping windows.
8. **Embedding** (if enabled): chunks whose `content_sha` + model already have a vector in the previous snapshot reuse it; only new text is embedded.
   Every vector's length is checked against `TRACELENS_EMBEDDING_DIM`.
9. **One transaction** inserts files, symbols, edges, chunks, embeddings, marks the snapshot `COMPLETED` and updates
   `repositories.active_snapshot_id`; older snapshots beyond the previous one are pruned.
   Any error → rollback, snapshot marked `FAILED`, previous index stays active.

### How edges are resolved (`analysis/resolver.py`)

The hard part. Principle: *resolve only when declarations/imports/types identify the target; otherwise record "unresolved" with the reason.*

Order: `DEFINES` (from structure) → imports → **inheritance** (needed for method lookup) → **calls**.

Python examples (all from the demo):
- `apply_tax()` in `pricing.py` after `from billing.tax import apply_tax` → resolved through the import map.
- `self.total()` → looked up on the enclosing class and its resolved base classes.
- `pricing.calculate_total()` with `from billing import pricing` → module alias.
- `invoice = Invoice(...); invoice.total()` → receiver type remembered from the constructor assignment.
- `processor.process(order)` (parameter, no type) with two classes defining `process` → **unresolved**, note lists the 4/2 candidates.
- `importlib.import_module(...)`, `getattr(...)` → unresolved, "dynamic/reflective".

Java examples:
- `provider.quote(parcel)` where the field is `ShippingProvider` → resolved to the *interface* method; the edge note lists implementations (dynamic dispatch).
- Overloads: `estimate(parcel)` vs `estimate(parcel, fee)` → chosen by **argument count**; if still ambiguous → unresolved.
- `Class.forName(...)`, `.newInstance()` → unresolved (reflection).
- `var x = factory.create()` (type unknowable syntactically) → unresolved.

A call from a **test file** into production code becomes a `TESTS` edge instead of `CALLS`.
Calls into external libraries (e.g. `List.add`) are ignored: only things that look *internal* are recorded.
Overloaded methods share a qualified name, so each reference carries its containing symbol's start line to tell them apart.

---

## 7. Search and impact analysis

### Search (`retrieval/service.py::SearchService.search`)

1. **Keyword**: the query is turned into tokens by the *same* function used at index time (`search_tokens`: lower-case,
   `calculateTotal`/`calculate_total` split into `calculate`,`total`, whole identifier kept). Tokens are OR-ed into a
   `tsquery` passed as a bound parameter; ranked by `ts_rank_cd`. Symbol/heading names are weighted higher (weight A)
   than body text (weight C), so a *definition* outranks callers.
2. **Vector**: embed the query with the same model, `ORDER BY embedding <=> query` (cosine).
3. **Fusion**: `rrf_fuse` adds `1/(60+rank)` per list, de-duplicates by chunk id, keeps the raw scores for debugging.
4. **Assembly**: attach file path, symbol, line range, text, ranks, and a citation.
If vector search is impossible, `hybrid` falls back to keyword **and says so in `warnings`**; `mode=vector` fails with 503. No fake vectors, ever.

### Impact analysis (`impact/analyzer.py::ImpactAnalyzer.analyze`)

1. Resolve the target (qualified name, simple name and/or file). Ambiguous → error listing candidates.
2. A class target includes its members; a file target includes all its symbols.
3. **Upstream BFS** over resolved edges to depth N (default 3) with a node cap. "Upstream" = things that depend on the target.
4. For a **method** target, also add subtypes/implementors of its class and the users of those (an interface change hits implementors).
5. Split results: test symbols → `related_tests`; others → `affected_components`.
6. Add unresolved references that leave the target or whose text ends with the target's name ("manual verification needed").
7. Hybrid search with the change description → `semantic_candidates` (always labelled low/unconfirmed) and docs
   (`mentions_target` for literal mentions via keyword, `semantic` otherwise).
8. Validate every citation; drop invalid evidence with a warning.
9. Optionally narrate with an LLM; persist the report.

**Confidence rule** (`classify`):
- **high** – direct resolved `CALLS/EXTENDS/IMPLEMENTS/TESTS` edge to the target
- **medium** – direct *import only*, or an indirect chain of non-import edges
- **low** – an indirect chain that relies on an import edge; semantic matches are always low

Four kinds of evidence are kept apart: static edges, semantic candidates, documentation, LLM text.

---

## 8. The optional LLM layer

Off by default (`TRACELENS_LLM_PROVIDER=none`). When enabled (`openai-compatible` endpoint):

- The model gets a *compact copy of the finished report* and may call 5 tools: `search_code`, `find_symbol`,
  `get_source_range`, `trace_dependencies`, `find_related_tests`.
- Tool arguments are validated with strict Pydantic schemas (unknown fields rejected, length/range limits).
- Tools only read the indexed snapshot in the database — no filesystem, no shell, no writes, no repository-root choice.
- Hard cap on calls (`TRACELENS_MAX_TOOL_CALLS`, default 6); once exhausted, calls get an error message.
- Everything it reads is wrapped as untrusted data; the system prompt says to ignore instructions inside it.
- The model writes **only** `llm_summary`. It can't add/remove affected components. Citations like `[cite:…]` in its
  text are checked against real evidence and removed if not valid.
- Any failure (timeout, HTTP error, no answer) → deterministic report plus a warning; `generated_by` honestly says
  `deterministic` vs `llm+deterministic`.

---

## 9. Database model (short)

`repositories` → `snapshots` → (`indexed_files`, `symbols`, `edges`, `chunks`, `chunk_embeddings`); `impact_analyses` stores reports.
Every derived row carries `snapshot_id`; every query filters on the repository's active snapshot. Edges have CHECK
constraints (a RESOLVED edge must have a target). Chunks have a generated `tsvector` with a GIN index; embeddings use an HNSW cosine index.
Migration 0002 (pgvector) is separate so a server without pgvector still gets the core schema.
Full details: [DATABASE.md](DATABASE.md).

---

## 10. API and CLI at a glance

CLI: `doctor`, `index`, `status`, `search`, `analyze`, `eval`, `report`, `db-reset` (dev only), `serve`, `version`.
API (`/api/v1`): `repositories/index`, `repositories`, `repositories/{id}/status`, `repositories/{id}/reindex`, `search`,
`dependencies/trace`, `impact/analyze`, `impact/analyses/{id}`, plus `/health/live`, `/health/ready`, `/system/info`.
Errors always look like `{"error": {"code": ..., "message": ...}}` with no stack traces. Details: [API_REFERENCE.md](API_REFERENCE.md).

---

## 11. A worked example (demo repository)

Change: *make `tax_rate_for` raise on unknown regions.* Call chain in the demo code:

```
tax_rate_for  <-  apply_tax  <-  calculate_total  <-  Invoice.total  <-  Invoice.render / checkout
                                       ^--- monthly_report (via module alias)
tests: test_tax_rate_known_region (direct), test_apply_tax_adds_rate, test_calculate_total_includes_tax ...
```
With depth 3 TraceLens reports `apply_tax` (**high**, depth 1), `calculate_total` (**medium**, depth 2), `Invoice.total` and
`monthly_report` (medium, depth 3), the three tests above, `docs/billing.md` as documentation that mentions it, and
each item cites the exact line that creates the relationship (e.g. `python/billing/tax.py#L14-L14@…`: `rate = tax_rate_for(region)`).
`Invoice.render` is beyond depth 3 and therefore not listed — raise `max_depth` to include it.

Another one: change the Java interface method `ShippingProvider.quote`. You get the two implementors (`IMPLEMENTS`, high),
`ShippingService.estimate` (high), `OrderFulfillment.fulfill` (medium), the factory and `quickQuote` (medium), the tests, and an
*unresolved* entry for `provider.quote(...)` in `quickQuote` because `var provider = ShippingFactory.create(kind)` has no
statically known type.

---

## 12. Tests and evaluation

- `tests/unit` – parsers, resolver on the real demo repo, chunker, fusion math, metrics, discovery rules, tool schemas, config.
- `tests/security` – path traversal, symlink handling, query-token safety, secret redaction, safe error envelope.
- `tests/integration` – needs PostgreSQL (`TRACELENS_TEST_DATABASE_URL`, **schema is wiped**): migrations, indexing
  (changes, failures, stale recovery), search, impact, CLI, API, LLM orchestration with a scripted test double, benchmark.
- `tests/integration/test_pgvector.py` – pgvector round-trip using an explicitly labelled *fixture* embedder; skipped without the extension.
- `tests/e2e` – full workflow.
- Benchmark: `tracelens eval` runs 13 retrieval + 12 impact cases with Recall@K, MRR, nDCG@K, precision/recall, citation validity and latency;
  unavailable modes are reported as *skipped*, never faked. See [EVALUATION.md](EVALUATION.md).

---

## 13. Where to change things

| I want to... | Edit |
|---|---|
| support another language | new parser in `analysis/` returning `ParsedFile`, wire into `indexing/service.py::_parse`, add extension in `discovery.py`, add resolver logic |
| tweak ranking | `search_tokens` (both index and query side) / weights in migration 0001's `tsv` / `retrieval/fusion.py` — then reindex and re-run `tracelens eval` |
| change confidence rules | `impact/analyzer.py::classify` (+ docs + tests) |
| add a setting | `config.py`, then `.env.example` and `docs/CONFIGURATION.md` |
| use another embedding model | `TRACELENS_EMBEDDING_MODEL` + `_DIM`; dimension change needs a new migration and reindex |
| use another LLM provider | implement `LLMProvider.chat` in `llm/provider.py` and extend `build_provider` |
| add an endpoint | new route in `api/routes/`, schema in `schemas/`, test in `tests/integration/test_api.py`, update `API_REFERENCE.md` |

---

## 14. Limitations (be aware)

- Static analysis can't see reflection, dependency injection, runtime dispatch, monkey patching (these are flagged as unresolved).
- Java overloads resolved by name + argument count only; Python receiver types are inferred heuristically.
- Languages: Python, Java, Markdown. Depth-bounded graph. Synchronous indexing. No authentication — run on localhost.
- Benchmark numbers come from a tiny synthetic repo; vector/hybrid modes still need to be measured on a pgvector-enabled machine.

## 15. Glossary

**RAG** retrieval-augmented generation · **FTS** full-text search · **pgvector** PostgreSQL vector extension ·
**HNSW** approximate nearest-neighbour index · **RRF** reciprocal rank fusion · **AST** abstract syntax tree ·
**tree-sitter** incremental parser library · **upstream** dependents of a symbol · **downstream** its dependencies ·
**snapshot** consistent index version · **citation** verifiable pointer to indexed source lines.
