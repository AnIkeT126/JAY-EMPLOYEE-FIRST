# Database

PostgreSQL 16 (pgvector for embeddings). Schema is created by Alembic migrations in `migrations/versions/`;
models are in `src/tracelens/models/tables.py` (classic SQLAlchemy `Column` mapping, 1.4/2.0-compatible).

## Entity relationships

```mermaid
erDiagram
    repositories ||--o{ snapshots : has
    repositories }o--|| snapshots : "active_snapshot_id"
    snapshots ||--o{ indexed_files : contains
    snapshots ||--o{ symbols : contains
    snapshots ||--o{ edges : contains
    snapshots ||--o{ chunks : contains
    indexed_files ||--o{ symbols : declares
    symbols ||--o{ symbols : "parent_id"
    symbols ||--o{ edges : "src / dst"
    indexed_files ||--o{ chunks : split_into
    chunks ||--o| chunk_embeddings : embedded_as
    repositories ||--o{ impact_analyses : has
```

## Tables

| Table | Key columns / constraints |
|---|---|
| `repositories` | `id` PK, `name` UNIQUE, `subdirectory` (relative to `TRACELENS_REPOSITORY_ROOT`), `active_snapshot_id` FK→snapshots (SET NULL) |
| `snapshots` | `id` PK, `repository_id` FK, `status` CHECK in (`RUNNING`,`COMPLETED`,`FAILED`), `started_at`, `finished_at`, `error`, `stats` JSONB. Index `(repository_id, started_at)` |
| `indexed_files` | `snapshot_id` FK (CASCADE), `rel_path`, `language`, `sha256`, `size_bytes`, `line_count`, `is_test`, `parse_error`, `content`; UNIQUE `(snapshot_id, rel_path)` |
| `symbols` | `snapshot_id`, `file_id`, `parent_id` (self FK), `kind`, `name`, `qualified_name`, `signature`, `start_line`, `end_line`, `is_test`; UNIQUE `(snapshot_id, file_id, qualified_name, start_line)` (overloads share a qualified name); indexes `(snapshot_id, qualified_name)`, `(snapshot_id, name)` |
| `edges` | `edge_type` CHECK in (`DEFINES`,`IMPORTS`,`CALLS`,`EXTENDS`,`IMPLEMENTS`,`TESTS`), `status` CHECK in (`RESOLVED`,`UNRESOLVED`), `src_symbol_id`, `dst_symbol_id` (NULL when unresolved), `dst_ref` (the textual reference), `file_id`, `line`, `evidence`, `note` (the reason it is unresolved / dispatch note). CHECK: a RESOLVED edge must have a target. Indexes on `(snapshot_id, src_symbol_id)` and `(snapshot_id, dst_symbol_id)` |
| `chunks` | `snapshot_id`, `file_id`, `symbol_id`, `kind`, `symbol_name`, `start_line`, `end_line`, `content`, `content_sha`, `name_text`, `search_text`, generated `tsv` tsvector (GIN index `ix_chunks_tsv`) |
| `chunk_embeddings` (migration 0002) | `chunk_id` PK FK→chunks (CASCADE), `snapshot_id` FK, `model`, `embedding vector(384)`; HNSW index with `vector_cosine_ops` |
| `impact_analyses` | `id` PK, `repository_id`, `snapshot_id` (SET NULL when old snapshots are pruned), `request` JSONB, `report` JSONB, `generated_by`, `duration_ms` |
| `alembic_version` | Alembic bookkeeping |

`tsv = setweight(to_tsvector('simple', name_text),'A') || setweight(to_tsvector('simple', search_text),'C')`.
`search_text`/`name_text` are pre-tokenised in Python (`indexing/chunker.py::search_tokens`: lower-case,
camelCase/snake_case split, whole identifier kept) and the query uses the same tokens, OR-combined,
ranked with `ts_rank_cd`. The `simple` configuration avoids stemming/stop-words so identifiers survive.

## Vector dimension and distance

Model `sentence-transformers/all-MiniLM-L6-v2` → **384** dimensions, vectors L2-normalised, **cosine**
distance (`<=>`, HNSW `vector_cosine_ops`). The dimension is fixed in the column type by migration 0002
(from `TRACELENS_EMBEDDING_DIM` at migration time). Every embedding is checked against
`TRACELENS_EMBEDDING_DIM` before insert (`validate_dimensions`), and `retrieval/vector.py::ensure_available`
compares the configured value with the column's `atttypmod`. Changing models/dimensions means a new
migration (alter or recreate `chunk_embeddings`) and a full reindex.

## Snapshot consistency

1. A `RUNNING` snapshot row is committed first (inside a repository row lock, which also serialises
   concurrent index requests; a second request gets HTTP 409).
2. Files, symbols, edges, chunks and embeddings are inserted in **one transaction** together with
   `status=COMPLETED` and `repositories.active_snapshot_id`. Readers only use the active snapshot, so a
   reader never mixes edges from one snapshot with files of another (every query filters on `snapshot_id`).
3. On any error the transaction rolls back (no partial rows) and the snapshot is marked `FAILED` with
   the error text; the previous active snapshot stays active.
4. Interrupted runs (process killed): the row stays `RUNNING`; once older than
   `TRACELENS_INDEX_STALE_AFTER_MINUTES` the next index call marks it `FAILED` (`recover_stale_snapshots`).
5. Retention: after a successful run, COMPLETED snapshots other than the new and the previous one are deleted (cascade).
6. Reindexing with no file changes creates no new snapshot (`unchanged`). Unchanged chunks reuse their
   previous embedding (matched by `content_sha` + model), so only changed content is re-embedded.

## Commands

```bash
alembic upgrade head          # apply all migrations
alembic upgrade 0001          # core schema only (no pgvector needed)
alembic current && alembic history
tracelens db-reset --yes      # DEV ONLY: DROP SCHEMA public CASCADE; CREATE SCHEMA public; then re-migrate
```
Ordinary startup never modifies or wipes data. Each migration runs in its own transaction.

## Backup / troubleshooting

Back up with `pg_dump -Fc` (snapshots can always be rebuilt from the repository with `tracelens index --force`,
so only `impact_analyses` is not reproducible). Common problems are in [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
