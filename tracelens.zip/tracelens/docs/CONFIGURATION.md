# Configuration reference

All settings are read from environment variables with the `TRACELENS_` prefix, or from a `.env`
file in the working directory (`.env.example` lists them all). Settings are validated at startup:
an invalid value makes the CLI exit with code 2 (and lists the offending variable) and prevents the
API from starting. Source of truth: `src/tracelens/config.py`.

## No-paid-API mode (the default)

Nothing to configure: `TRACELENS_LLM_PROVIDER=none`. Core indexing, dependency tracing, retrieval and
impact reports never call an LLM. Embeddings use a **local** model (downloaded once, free). To avoid
even that download use `TRACELENS_EMBEDDINGS_ENABLED=false` (keyword + static analysis only).

## Variables

"Restart" = the process must be restarted to pick up a change. "Reindex" = existing snapshots stay
as they were indexed until you run `tracelens index --force`.

| Variable | Purpose | Type | Default | Required | Example | Restart | Reindex |
|---|---|---|---|---|---|---|---|
| `TRACELENS_ENVIRONMENT` | Deployment mode; `db-reset` only works in `development`. | Literal['development', 'test', 'production'] | `development` | optional |  | restart | no |
| `TRACELENS_LOG_LEVEL` | Log verbosity. | Literal['DEBUG', 'INFO', 'WARNING', 'ERROR'] | `INFO` | optional |  | restart | no |
| `TRACELENS_API_HOST` | Bind address for `tracelens serve`. | str | `127.0.0.1` | optional |  | restart | no |
| `TRACELENS_API_PORT` | Bind port for `tracelens serve`. | int | `8000` | optional |  | restart | no |
| `TRACELENS_DATABASE_URL` | SQLAlchemy URL of the PostgreSQL database (driver `postgresql+psycopg2`). | str | `postgresql+psycopg2://tracelens:tracelens@localhost:5432/tracelens` | optional | `postgresql+psycopg2://u:p@host:5432/db` | restart | no (but a new database needs migrations + indexing) |
| `TRACELENS_REPOSITORY_ROOT` | Base directory all indexed repositories must live under. Relative paths resolve against the project root. | Path | `demo/sample_repository` | optional |  | restart | yes, if it points at different content |
| `TRACELENS_MAX_FILE_BYTES` | Files larger than this are skipped (reported in `skipped_files`). | int | `500000` | optional |  | restart | yes |
| `TRACELENS_MAX_FILES` | Indexing fails if more supported files are found (no silent truncation). | int | `5000` | optional |  | restart | yes |
| `TRACELENS_IGNORED_DIRS` | Comma-separated directory names never descended into. | str | `.git,.hg,.svn,.venv,venv,env,node_modules,build,dist,target,out,__pycache__,.mypy_cache,.pytest_cache,.ruff_cache,.idea,.vscode,.gradle,.tox` | optional |  | restart | yes |
| `TRACELENS_IGNORED_PATTERNS` | Comma-separated filename globs that are skipped. | str | `*.min.*,*_pb2.py,*.generated.*` | optional |  | restart | yes |
| `TRACELENS_MAX_CHUNK_LINES` | Chunks longer than this are split into overlapping windows. | int | `120` | optional |  | restart | yes |
| `TRACELENS_CHUNK_OVERLAP_LINES` | Overlap between windows of an oversized chunk (must be < max_chunk_lines). | int | `10` | optional |  | restart | yes |
| `TRACELENS_INDEX_STALE_AFTER_MINUTES` | A RUNNING snapshot older than this is treated as interrupted and marked FAILED. | int | `30` | optional |  | restart | no |
| `TRACELENS_EMBEDDINGS_ENABLED` | `false` = no embeddings: keyword search + static analysis only; hybrid degrades visibly to keyword. | bool | `True` | optional |  | restart | yes (index with embeddings to enable vector search) |
| `TRACELENS_EMBEDDING_PROVIDER` | Embedding backend (only `sentence-transformers`). | Literal['sentence-transformers'] | `sentence-transformers` | optional |  | restart | yes |
| `TRACELENS_EMBEDDING_MODEL` | Hugging Face model id. Downloaded on first use. | str | `sentence-transformers/all-MiniLM-L6-v2` | optional |  | restart | yes (vectors from another model are incompatible) |
| `TRACELENS_EMBEDDING_DIM` | Vector dimension. Must equal the model output AND the pgvector column created by migration 0002. | int | `384` | optional |  | restart | yes (needs a new migration + reindex) |
| `TRACELENS_EMBEDDING_LOCAL_FILES_ONLY` | `true` = never use the network; the model must already be in the Hugging Face cache. | bool | `False` | optional |  | restart | no |
| `TRACELENS_EMBEDDING_BATCH_SIZE` | Texts embedded per batch. | int | `32` | optional |  | restart | no |
| `TRACELENS_LLM_PROVIDER` | `none` (default, no API key needed) or `openai-compatible`. | Literal['none', 'openai-compatible'] | `none` | optional |  | restart | no |
| `TRACELENS_LLM_MODEL` | Model name sent to the chat-completions endpoint. Required if provider != none. | str | `""` | required if provider≠none | `my-model` | restart | no |
| `TRACELENS_LLM_BASE_URL` | Base URL ending in `/v1`; `/chat/completions` is appended. Required if provider != none. | str | `""` | required if provider≠none | `https://llm.example.internal/v1` | restart | no |
| `TRACELENS_LLM_API_KEY` | Bearer token for the endpoint. Secret: never commit. | SecretStr or unset | `(unset)` | optional | `<your-key>` | restart | no |
| `TRACELENS_LLM_TIMEOUT_SECONDS` | Per-request timeout for the LLM provider. | float | `30.0` | optional |  | restart | no |
| `TRACELENS_MAX_TOOL_CALLS` | Hard cap on LLM tool calls per analysis (0 disables tools). | int | `6` | optional |  | restart | no |
| `TRACELENS_LLM_MAX_CONTEXT_CHARS` | Upper bound for report context sent to the LLM; tool results are capped at half. | int | `20000` | optional |  | restart | no |
| `TRACELENS_KEYWORD_CANDIDATES` | Candidates fetched from full-text search before fusion. | int | `50` | optional |  | restart | no |
| `TRACELENS_VECTOR_CANDIDATES` | Candidates fetched from vector search before fusion. | int | `50` | optional |  | restart | no |
| `TRACELENS_DEFAULT_TOP_K` | Results returned when a request omits `top_k`. | int | `10` | optional |  | restart | no |
| `TRACELENS_MAX_TOP_K` | Largest accepted `top_k`. | int | `50` | optional |  | restart | no |
| `TRACELENS_RRF_K` | RRF constant k in 1/(k+rank). | int | `60` | optional |  | restart | no |
| `TRACELENS_MAX_QUERY_CHARS` | Longest accepted search query. | int | `1000` | optional |  | restart | no |
| `TRACELENS_MAX_TRACE_DEPTH` | Default dependency traversal depth (requests may ask for up to 8). | int | `3` | optional |  | restart | no |
| `TRACELENS_TRACE_NODE_LIMIT` | Maximum symbols collected by one traversal; sets `truncated`. | int | `500` | optional |  | restart | no |
| `TRACELENS_EVAL_DATASET_PATH` | Evaluation dataset JSON. | Path | `data/evaluation/cases.json` | optional |  | restart | no |
| `TRACELENS_EVAL_OUTPUT_DIR` | Where `tracelens eval` writes reports. | Path | `reports` | optional |  | restart | no |

## Test-only variable

| Variable | Purpose |
|---|---|
| `TRACELENS_TEST_DATABASE_URL` | Database used by `tests/integration`, `tests/e2e`. **The `public` schema is dropped and recreated.** Integration tests are skipped when unset. |

## Related, non-`TRACELENS_` variables

`HF_HOME` (Hugging Face cache directory; the Dockerfile sets it to `/models`) and
`TRACELENS_EMBEDDING_DIM` which is also read by migration `0002` when it creates the vector column.

## Examples

```bash
# deterministic mode, no model download
TRACELENS_EMBEDDINGS_ENABLED=false
# optional LLM (any OpenAI-compatible server)
TRACELENS_LLM_PROVIDER=openai-compatible
TRACELENS_LLM_BASE_URL=https://llm.example.internal/v1
TRACELENS_LLM_MODEL=my-model
TRACELENS_LLM_API_KEY=<your-key>
```
