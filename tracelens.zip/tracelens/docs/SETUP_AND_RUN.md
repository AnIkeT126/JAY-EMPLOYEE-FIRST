# Setup and run (clean machine)

Authoritative, ordered instructions. Commands marked **(unverified)** could not be executed in the
development sandbox (no Docker, no PyPI/Hugging Face access, no pgvector) — see
[HANDOFF.md](HANDOFF.md) for exactly what was verified.

## 0. Network needs

| Step | Needs network? |
|---|---|
| `pip install` (PyPI) | yes, once |
| `docker pull pgvector/pgvector:pg16` | yes, once |
| First embedding use downloads `sentence-transformers/all-MiniLM-L6-v2` (~90 MB, Hugging Face) | yes, once; afterwards set `TRACELENS_EMBEDDING_LOCAL_FILES_ONLY=true` to run offline |
| Everything else (indexing, search, analysis, API, tests) | no (LLM calls excepted, if you enable one) |

Resources: model needs roughly 0.5–1 GB RAM on CPU plus ~90 MB disk (torch itself is ~1–2 GB of disk).

## 1. Required software

- Python **3.11+** — `python3 --version`
- Docker with Compose v2 — `docker --version && docker compose version` (or any PostgreSQL 16 with the pgvector extension)
- Git (optional)

## 2. Get the code and install

Linux/macOS:
```bash
cd tracelens
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"            # (unverified here: packaging needs setuptools from PyPI)
```
Windows PowerShell:
```powershell
cd tracelens
py -3.11 -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -e ".[dev]"
```
Reproducibility: `requirements.lock` pins the direct dependencies to the versions the code was
tested with (`pip install -r requirements.lock` then `pip install --no-deps -e .`). For a full
transitive lock run `uv lock` (unverified; no `uv.lock` is shipped because it could not be generated offline).
Note: tests were run on **SQLAlchemy 1.4.54**; the code uses the 1.4/2.0-compatible API and the
`pyproject.toml` range is `>=1.4.50,<2.1`. SQLAlchemy 2.x is expected to work but was **not** run.

## 3. Environment file

```bash
cp .env.example .env        # PowerShell: Copy-Item .env.example .env
```
Defaults match `docker-compose.yml`. No secrets are required.

## 4. Start PostgreSQL

```bash
docker compose up -d db     # (unverified)
docker compose ps           # STATUS should become "healthy"
docker compose exec db pg_isready -U tracelens -d tracelens   # "accepting connections"
```

## 5. Migrate

```bash
alembic upgrade head
```
Expected: `Running upgrade -> 0001` then `0001 -> 0002`. Migration 0002 runs `CREATE EXTENSION vector`;
on a server without pgvector it fails *after* 0001 was committed (one transaction per migration).
That state is valid for the no-embeddings mode below.

## 6. Doctor

```bash
tracelens doctor
```
Prints `[OK  ]/[WARN]/[FAIL]` per check (config, repository root, Java parser, database, migrations,
pgvector/dimension, embedding model cache, LLM). Exit code 0 = all required checks pass, 1 = a check failed, 2 = invalid configuration.

## 7. Index the demo repository

```bash
tracelens index --name sample_repository
```
First run downloads the embedding model. Expect `result: indexed` and JSON stats
(27 files, 81 symbols, 130 edges, 91 chunks for the bundled demo). Re-running prints
`unchanged (no new snapshot)`; use `--force` to rebuild.

## 8. Explore

```bash
tracelens search "calculate total discount" -r sample_repository
tracelens analyze -r sample_repository --symbol tax_rate_for \
  --change "Unknown regions must raise an error instead of using the default rate"
tracelens report <analysis_id> --format md -o report.md      # analysis_id is printed by `analyze --json`
tracelens eval                                               # writes reports/evaluation.{json,md}
```

## 9. API

```bash
tracelens serve                      # or: uvicorn tracelens.main:app --port 8000
curl -s http://127.0.0.1:8000/health/live      # {"status":"ok"}
curl -s http://127.0.0.1:8000/health/ready     # checks database, migrations, vector availability
```
Swagger UI: http://127.0.0.1:8000/docs · OpenAPI JSON: `/openapi.json`. Sample calls: [API_REFERENCE.md](API_REFERENCE.md).

## 10. Tests

```bash
pytest tests/unit tests/security            # no database
export TRACELENS_TEST_DATABASE_URL=postgresql+psycopg2://tracelens:tracelens@localhost:5432/tracelens_test
docker compose exec db createdb -U tracelens tracelens_test
pytest                                      # everything; pgvector tests skip when the extension is missing
```
PowerShell: `$env:TRACELENS_TEST_DATABASE_URL="postgresql+psycopg2://tracelens:tracelens@localhost:5432/tracelens_test"`.
**The test database's `public` schema is dropped.** Never point it at data you care about.

## 11. Shutdown

```bash
docker compose down        # keep data
docker compose down -v     # also delete the database volume
```

## No-embeddings mode

For machines without Docker/pgvector or without access to Hugging Face:
```bash
export TRACELENS_EMBEDDINGS_ENABLED=false
alembic upgrade 0001       # core schema only (PostgreSQL 14+ without pgvector is enough)
tracelens doctor && tracelens index --name sample_repository && tracelens eval
```
Keyword retrieval, dependency tracing and impact analysis work. `mode=vector` returns HTTP 503;
`mode=hybrid` returns keyword results with an explicit warning. This is the mode that was
executed end-to-end during development.

## Docker-only run (unverified)

```bash
docker compose --profile api up --build      # API at http://127.0.0.1:8000, runs migrations on start
docker compose exec api tracelens index --name sample_repository
```

## Local PostgreSQL without Docker

`scripts/local_postgres.sh start` creates a throw-away cluster under `.local-postgres/` (uses the
`initdb/pg_ctl` on your PATH) and prints a `TRACELENS_TEST_DATABASE_URL`. Stop with `scripts/local_postgres.sh stop`.
