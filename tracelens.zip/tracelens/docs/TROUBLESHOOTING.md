# Troubleshooting

Start with `tracelens doctor` and `GET /health/ready`; they cover most of the items below.

| Problem | Symptoms | Likely cause | Diagnose | Safe fix |
|---|---|---|---|---|
| Docker not running | `Cannot connect to the Docker daemon` | Docker Desktop/daemon stopped | `docker info` | Start Docker; or use `scripts/local_postgres.sh` / the no-embeddings mode |
| PostgreSQL unavailable | doctor `[FAIL] database`; `/health/ready` 503 `unreachable` | DB down, wrong host/port | `docker compose ps`; `pg_isready -h localhost -p 5432` | `docker compose up -d db`; check `TRACELENS_DATABASE_URL` |
| Wrong credentials | `password authentication failed` | URL differs from compose creds | `psql "<url without +psycopg2>"` | Align `.env` with `docker-compose.yml` |
| pgvector missing | `extension "vector" is not available` during `alembic upgrade head` | Server lacks pgvector | `psql -c "select * from pg_available_extensions where name='vector'"` | Use the `pgvector/pgvector:pg16` image, or `alembic upgrade 0001` + `TRACELENS_EMBEDDINGS_ENABLED=false` |
| Migration failure | alembic traceback; doctor `[FAIL] migrations` | partial/old schema | `alembic current`, `alembic history` | Fix cause, rerun. Dev DB: `tracelens db-reset --yes` then `alembic upgrade head` |
| Model download failure | `EmbeddingError: could not load embedding model` | No access to huggingface.co | `tracelens doctor` (embedding model line) | Allow network once, or copy the model into `HF_HOME` and set `TRACELENS_EMBEDDING_LOCAL_FILES_ONLY=true`; or disable embeddings |
| Insufficient memory | killed / `MemoryError` while embedding | Model + batch too large | `free -m` | Lower `TRACELENS_EMBEDDING_BATCH_SIZE`, close other processes |
| Wrong embedding dimension | `database vectors have dimension X but TRACELENS_EMBEDDING_DIM=Y` or `embedding … has dimension` | model/config/column mismatch | `tracelens doctor` | Make `TRACELENS_EMBEDDING_DIM` match the model; changing the column needs a new migration + reindex (DATABASE.md) |
| Empty search results | `hits: []` | query tokens absent, wrong repository/snapshot, filters too narrow, nothing indexed | `tracelens status`; try `mode=keyword` with an identifier | Re-index; remove `language`/`path_prefix`; check `warnings` |
| Repository path rejected | 400 `path_policy_violation` | absolute path, `..`, symlink escape, not a directory | read the message | Use a path relative to `TRACELENS_REPOSITORY_ROOT`, or change the root |
| 422 on index | unknown field | the API takes `subdirectory`, not a path | response `details` | Use documented fields |
| Index limit | 422 `index_limit_exceeded` | more than `TRACELENS_MAX_FILES` files | message | Raise the limit or index a subdirectory |
| Java parser failure | doctor `[FAIL] java parser`; `parse_error` on `.java` files | `tree-sitter-java` missing/incompatible; invalid Java | `python -c "import tree_sitter_java"` | `pip install -r requirements.lock`; a syntax-error file is still indexed with a warning |
| Stale indexing state | `indexing_in_progress` (409) with no running process | previous run was killed | `tracelens status` (latest snapshot RUNNING) | Wait `TRACELENS_INDEX_STALE_AFTER_MINUTES` (default 30) or lower it; the next run marks it FAILED and proceeds |
| Failed indexing | `indexing_failed`; latest snapshot FAILED | see `error` in status | `GET /repositories/{id}/status` | Fix cause, re-run; the previous snapshot stays active |
| LLM provider failure | report has warning `LLM narration failed (…)` | endpoint down/timeout/HTTP error | warnings + server log | Check `TRACELENS_LLM_*`; the deterministic report is still valid |
| `use_llm` ignored | warning `no provider is configured` | `TRACELENS_LLM_PROVIDER=none` | `GET /api/v1/system/info` | Configure a provider (CONFIGURATION.md) |
| Port conflict | `address already in use` | 8000/5432 occupied | `ss -ltnp \| grep 8000` | Change `TRACELENS_API_PORT` / compose port mapping |
| Integration tests skipped | `TRACELENS_TEST_DATABASE_URL is not set` | env var missing | `pytest -rs` | Export it (SETUP_AND_RUN §10) |
| pgvector test skipped | `pgvector extension is not available` | server lacks extension | `pytest -rs` | Run against the compose DB |
| Config error | exit code 2 and a list of variables | invalid value | message | Fix `.env` (CONFIGURATION.md) |
