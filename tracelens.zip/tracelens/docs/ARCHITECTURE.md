# Architecture

TraceLens is a **modular monolith**: one Python package (`src/tracelens`), one PostgreSQL database,
no queues, caches or extra services.

```mermaid
flowchart LR
    CLI[CLI typer] --> SVC
    API[FastAPI routes] --> SVC
    subgraph SVC[Services]
      IDX[indexing.service.Indexer]
      SRCH[retrieval.service.SearchService]
      IMP[impact.analyzer.ImpactAnalyzer]
      LLM[llm.agent.ImpactNarrator - optional]
    end
    IDX --> DISC[discovery / chunker]
    IDX --> AN[analysis: python_parser, java_parser, resolver]
    IDX --> EMB[retrieval.embeddings - local model]
    IDX --> PG[(PostgreSQL + pgvector)]
    SRCH --> KW[keyword: full-text]
    SRCH --> VEC[vector: pgvector]
    SRCH --> RRF[fusion: RRF]
    KW --> PG
    VEC --> PG
    IMP --> DG[analysis.dependency_graph]
    IMP --> SRCH
    DG --> PG
    IMP --> LLM
    LLM --> TOOLS[llm.tools - 5 read-only tools] --> SRCH
    LLM -. HTTP .-> EXT[(optional OpenAI-compatible endpoint)]
```

Main data flow: **index** (discover → parse → resolve edges → chunk → embed → persist one snapshot) →
**query** (keyword + vector → RRF → citations) → **impact** (resolve target → bounded graph traversal →
tests → docs → semantic candidates → citation validation → optional LLM narration → persist).

## Module responsibilities

| Module | Responsibility |
|---|---|
| `config.py` | Validated settings; path properties resolve against the project root, never the CWD |
| `models/`, `migrations/` | Schema; every derived row belongs to one snapshot |
| `indexing/discovery.py` | Safe file walk: root confinement, symlink policy, size/count limits, generated/binary filters |
| `indexing/chunker.py` | Symbol-aware chunks, markdown sections, bounded fallback windows; `search_tokens` |
| `indexing/service.py` | Snapshot lifecycle, change detection, atomic persistence, embedding reuse |
| `analysis/python_parser.py`, `java_parser.py` | Syntax → symbols + raw references (no execution) |
| `analysis/resolver.py` | Raw references → resolved or unresolved edges |
| `analysis/dependency_graph.py` | Target resolution, bounded BFS, unresolved lookup |
| `retrieval/*` | Keyword, vector, RRF, citations, embedding provider |
| `impact/analyzer.py` | Merges graph + retrieval evidence into the report; confidence rule |
| `llm/*` | Provider interface, tool schemas/executor, narrator with citation validation |
| `evaluation/*` | Metrics, runner, report writers |
| `api/*`, `main.py`, `cli.py` | Thin transport layers (validation + error mapping only) |

## Key design decisions

- **PostgreSQL does everything** (FTS, vectors, graph edges as rows). One transactional store makes
  snapshot atomicity simple and avoids a separate graph/vector DB.
- **Snapshots, not in-place updates**: a new snapshot is built and swapped in atomically; stale edges cannot leak.
- **Unresolved edges are first-class.** The resolver records *why* a reference is ambiguous (e.g. 4 candidate
  methods, reflection, overloads) instead of fabricating an edge. Impact reports surface them.
- **Evidence classes are never merged**: static edges → `affected_components`/`related_tests`;
  retrieval-only hits → `semantic_candidates` (always `low`, labelled unconfirmed); docs separately;
  LLM text only in `llm_summary`.
- **Confidence is a rule, not a probability** (`impact/analyzer.py::classify`): high = direct resolved
  CALLS/EXTENDS/IMPLEMENTS/TESTS edge; medium = direct import only, or an indirect chain of non-import
  edges; low = an indirect chain relying on an import edge. Semantic matches are always low.
- **Inheritance**: changing a method also reports subtypes/implementors (`IMPLEMENTS`/`EXTENDS`) and,
  within the depth bound, the users of those subtypes.
- **RRF over score blending**: keyword (`ts_rank_cd`) and cosine scores are not comparable; only ranks are fused.

## Provider interfaces

`Embedder` (`retrieval/embeddings.py`: `model_name`, `dimension`, `embed(texts)`) and `LLMProvider`
(`llm/provider.py`: `chat(messages, tools)`). Only the real `SentenceTransformerEmbedder` exists in
`src/`; tests define scripted/fixture doubles with explicit names inside `tests/`.

## Degradation without GenAI / embeddings

| Missing | Behaviour |
|---|---|
| LLM (`provider=none`) | Everything works; `generated_by="deterministic"`. `use_llm=true` adds a warning, not a fake summary |
| LLM error/timeout/invalid output | Deterministic report returned with a warning; `generated_by` stays `deterministic` |
| Embeddings disabled / pgvector missing | `keyword` works; `vector` → HTTP 503; `hybrid` → keyword results with `mode_used="keyword"` and a warning |
| Embedding model unavailable at index time | Indexing fails (snapshot `FAILED`), previous snapshot stays active |

## Limitations and trade-offs

Static analysis cannot see reflection, DI, runtime dispatch or dynamic imports (they are flagged as
unresolved). Java overloads are resolved by name + argument count only; Python receiver types are inferred
from constructor assignments, annotations and `self.attr = Class()`. Indexing is synchronous and holds whole
parsed content in memory (fine for ≤ `TRACELENS_MAX_FILES` files). No auth, no multi-tenancy.
