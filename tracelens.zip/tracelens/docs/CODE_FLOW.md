# Code flow

Describes what the code actually does (function names are real; grep them). Two entry points share the
same services: the CLI (`tracelens.cli:app`) and the ASGI app (`tracelens.main:app`).

```mermaid
sequenceDiagram
    participant U as User (CLI/API)
    participant IX as Indexer.index/_run
    participant D as discover_files
    participant P as parse_python/parse_java
    participant R as build_edges
    participant C as chunk_file
    participant E as Embedder
    participant DB as PostgreSQL
    U->>IX: index(name, subdirectory)
    IX->>D: walk + filter (resolve_within first)
    IX->>DB: lock repo, create RUNNING snapshot
    IX->>P: parse every file
    IX->>R: resolve edges
    IX->>C: chunk
    IX->>E: embed new chunks (reuse unchanged)
    IX->>DB: ONE tx: rows + COMPLETED + active_snapshot_id
    U->>SearchService.search: query
    SearchService.search->>DB: full-text + pgvector
    SearchService.search->>SearchService.search: rrf_fuse -> citations
    U->>ImpactAnalyzer.analyze: target + change
    ImpactAnalyzer.analyze->>DB: trace (BFS) + retrieval
    ImpactAnalyzer.analyze->>ImpactNarrator: optional narrate
    ImpactAnalyzer.analyze->>DB: persist report
```

Main call chain for `POST /api/v1/impact/analyze`:
`routes/impact.analyze` → `ImpactAnalyzer.analyze` → `require_active_snapshot` → `resolve_target` →
`_expand_targets` → `dependency_graph.trace` → `_inheritance_steps` → `_partition` (`classify`) →
`_unresolved` → `_retrieval` (→ `SearchService.search`) → `_validate_citations` → `_narrate` (optional) → `_persist`.

## Stages

Each stage: entry file · main function · input → output · dependencies · error behaviour · next.

1. **Startup / configuration** — `main.py::create_app` (API) or `cli.py::_settings` (CLI). Input: environment/`.env`.
   Output: frozen `Settings` (`config.py::get_settings`, cached). Invalid values raise `ValidationError`
   → API fails to start; CLI prints the offending variables and exits 2. Lifespan creates the engine,
   session factory, `build_embedder`, `build_provider` on `app.state`. **No database access, no data changes at startup.**
   Next: any request.
2. **Database initialisation** — not done at startup; `alembic upgrade head` (`migrations/env.py`). `/health/ready`
   and `tracelens doctor` call `database/migration_state.py::migration_state` to detect missing migrations.
3. **Repository discovery** — `indexing/discovery.py::resolve_within` (confines the requested subdirectory to
   `TRACELENS_REPOSITORY_ROOT`; raises `PathPolicyError`) then `discover_files` (walk without following links,
   prune ignored dirs, skip symlink escapes, oversize, binary, non-UTF-8, generated files; raises
   `IndexLimitError` above `max_files`). Output: `DiscoveryResult(files, skipped)` with sha256, line count, `is_test`.
4. **Snapshot start / change detection** — `indexing/service.py::Indexer._run`, `_lock_repo`, `_previous_hashes`.
   Locks the repository row, recovers stale RUNNING snapshots, refuses if a fresh one is RUNNING
   (`IndexingInProgressError` → 409), diffs file hashes against the active snapshot. No changes and no `--force`
   → returns the active snapshot (`unchanged`). Otherwise commits a RUNNING snapshot row.
5. **Source parsing** — `_parse` → `analysis/python_parser.py::parse_python` (stdlib `ast`) or
   `analysis/java_parser.py::parse_java` (tree-sitter). Output: `ParsedFile` (symbols with line ranges, raw
   references with source line text). Syntax errors set `ParsedFile.error` (file still indexed, falls back to
   window chunks); nothing is executed.
6. **Symbol & dependency extraction** — `analysis/resolver.py::build_edges`: emits `DEFINES`, resolves imports
   (`IMPORTS`), inheritance first (`EXTENDS`/`IMPLEMENTS`), then calls (`CALLS`; `TESTS` when a test file calls
   production code). Receiver types come from constructors, annotations, fields, parameters, `var x = new T()`.
   Anything internal-looking but ambiguous (several candidate methods, overload with same arity, reflection,
   dynamic import) becomes an `UNRESOLVED` edge with a reason. Overloads are told apart by start line
   (`RawRef.src_start_line`).
7. **Chunking** — `indexing/chunker.py::chunk_file`: one chunk per function/method, class header, markdown
   section; leftovers become `module` chunks; chunks > `max_chunk_lines` become overlapping windows.
   `search_tokens` builds `search_text`/`name_text`.
8. **Embedding generation** — `Indexer._build_and_commit` → `vector_store.reusable_embeddings` (reuse by
   `content_sha`+model) → `SentenceTransformerEmbedder.embed` → `validate_dimensions`. Disabled when
   `embeddings_enabled=false`. Failure aborts indexing (`EmbeddingError`; snapshot FAILED).
9. **Persistence** — same method: one `session_scope` inserts files, symbols, edges, chunks, embeddings
   (`vector_store.insert_embeddings`), flips snapshot to COMPLETED, sets `repositories.active_snapshot_id`,
   prunes old snapshots. Exception → rollback, then snapshot marked FAILED in a separate transaction,
   `IndexingFailedError` raised (previous index remains active).
10. **Keyword retrieval** — `retrieval/keyword.py::keyword_search`: tokens → OR `tsquery` (bound parameter) →
    `ts_rank_cd` over `chunks.tsv`, filtered by snapshot/language/path prefix. Returns `RankedHit` list (1-based ranks).
11. **Vector retrieval** — `retrieval/service.py::SearchService._vector` → `vector_store.ensure_available`
    (table + dimension) → `embedder.embed([query])` → `validate_dimensions` → `vector_store.vector_search`
    (`<=>` cosine). Raises `VectorUnavailableError` (503) when unavailable.
12. **Reciprocal Rank Fusion** — `retrieval/fusion.py::rrf_fuse`: `sum 1/(k+rank)` over the lists, dedupe by
    chunk id, deterministic tie-break; raw scores kept for diagnostics only. `SearchService.search` degrades
    `hybrid`→keyword with a warning when vector fails; `_assemble` loads chunk rows and builds citations
    (`retrieval/citations.py::make_citation`).
13. **Dependency traversal** — `analysis/dependency_graph.py::trace`: level-by-level BFS over RESOLVED edges of
    one snapshot (`upstream` = dependents), bounded by `max_depth` and `trace_node_limit`; each step keeps its edge path.
14. **Impact assembly** — `impact/analyzer.py::ImpactAnalyzer.analyze` (see call chain above). Class targets include
    their members; method targets also trace subtypes/implementors and their users; steps are merged by shortest
    path; test symbols go to `related_tests`; confidence via `classify`.
15. **Optional LLM orchestration** — `llm/agent.py::ImpactNarrator.narrate`: sends a compact report, loops
    `provider.chat` up to `max_tool_calls`, executing calls through `llm/tools.py::ToolExecutor.run`
    (pydantic-validated args, DB-only, results wrapped `{"untrusted_content": true}` and size-capped).
    Errors/timeouts propagate as exceptions that `ImpactAnalyzer._narrate` converts into a warning + deterministic report.
16. **Citation validation** — `retrieval/citations.py::validate_citation` (file exists in that snapshot and the
    range is inside it). `ImpactAnalyzer._validate_citations` drops invalid evidence; `ImpactNarrator._validate`
    removes `[cite:…]` markers that are not in the report/tool evidence or do not validate.
17. **Report construction / persistence** — `ImpactReport` (pydantic) built in `analyze`; `_persist` stores it in
    `impact_analyses`. API route session dependency commits on success.
18. **Response serialisation** — FastAPI `response_model` (`schemas/impact.py`, `schemas/api.py`); domain errors
    mapped by `api/errors.py::register_error_handlers` to the safe envelope. CLI renders with `impact/render.py`.

## Evaluation flow
`cli.py::eval_command` → `evaluation/runner.py::run_evaluation` → `_run_retrieval` / `_run_impact` (each
mode that cannot run is reported `skipped` with the reason) → `write_reports` (JSON + Markdown).
