# Handoff checklist

One page: everything needed to move TraceLens to a fresh machine.

## 1. Copy

The whole `tracelens/` directory **except** `.venv/`, `.local-postgres/`, `__pycache__/`, `.*_cache/`, `.env`.
Essential: `pyproject.toml`, `requirements.lock`, `alembic.ini`, `src/`, `migrations/`, `demo/`, `data/`,
`tests/`, `docs/`, `scripts/`, `Dockerfile`, `docker-compose.yml`, `Makefile`, `.env.example`, `.gitignore`,
`README.md`, `AGENTS.md`. (`reports/` is a generated artifact and may be omitted.)

## 2. Infrastructure
- Python 3.11+; PostgreSQL 16 **with pgvector** (Docker image `pgvector/pgvector:pg16` via `docker compose up -d db`).
- Network (one-time): PyPI, Docker Hub, and Hugging Face for model `sentence-transformers/all-MiniLM-L6-v2` (~90 MB).
  Afterwards the app runs offline (`TRACELENS_EMBEDDING_LOCAL_FILES_ONLY=true`). Do not commit models.

## 3. First run
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]" && cp .env.example .env
docker compose up -d db && alembic upgrade head
tracelens doctor && tracelens index --name sample_repository && tracelens eval
```

## 4. Verify
`pytest tests/unit tests/security` (70 tests) · `TRACELENS_TEST_DATABASE_URL=… pytest` (expect 107 collected; the pgvector
round-trip test runs only when the extension exists) · `curl localhost:8000/health/ready` after `tracelens serve`.

## 5. Optional LLM
`TRACELENS_LLM_PROVIDER=openai-compatible`, `TRACELENS_LLM_BASE_URL`, `TRACELENS_LLM_MODEL`, `TRACELENS_LLM_API_KEY`
(see CONFIGURATION.md). Then `tracelens analyze … --llm` or `"use_llm": true`.

## 6. Expected artifacts
Tables from migrations; a COMPLETED snapshot for `sample_repository` (27 files / 81 symbols / 130 edges / 91 chunks);
`reports/evaluation.json` and `.md`; stored `impact_analyses` rows.

## 7. Known external dependencies
PyPI packages in `pyproject.toml`/`requirements.lock`; `pgvector` extension; Hugging Face model hub; (optional) an
OpenAI-compatible LLM endpoint; Docker.

## 8. Verification status of THIS handoff (honest)

| Item | Status |
|---|---|
| Unit + security tests (70), integration/e2e/CLI/API tests (36+1) on PostgreSQL 16.15 | **Implemented and verified** (106 passed, 1 skipped) |
| Alembic 0001 from an empty DB; migration 0002 failure leaves 0001 applied | **Verified** (0002 failure path only) |
| Indexing, static analysis (Python, Java), keyword retrieval, RRF, citations, dependency tracing, impact analysis, LLM orchestration with a scripted test double, CLI, REST API (live uvicorn), evaluation run (keyword/deps modes) | **Verified** |
| ruff, mypy, Semgrep (MCP) | **Verified** (clean) |
| pgvector migration 0002 success path, vector storage/search, hybrid fusion with real vectors | **Implemented, not executed** (no pgvector in the sandbox) |
| Real embedding model (Sentence Transformers), first-run download | **Implemented, not executed** (Hugging Face blocked) |
| Real LLM provider | **Implemented, not executed** (only a scripted double) |
| `docker compose`, Dockerfile, `docker compose --profile api` | **Written, not executed** (no Docker) |
| `pip install -e .` packaging, `tracelens` console script | **Not executed** (setuptools not available offline); verified via `python -m tracelens.cli` |
| SQLAlchemy 2.x | **Not executed**; verified only on 1.4.54 |
| Windows/macOS | **Not executed**; PowerShell commands provided |
| `uv.lock` | **Not generated** (offline); `requirements.lock` pins direct deps |
| Benchmark with vector/hybrid modes | **Not measured** |

## 9. Final checklist (tick on the new machine)
- [ ] `alembic upgrade head` succeeds (both revisions)
- [ ] `tracelens doctor` exits 0 with embeddings enabled
- [ ] `tracelens index` completes; `tracelens status` shows counts
- [ ] `POST /api/v1/search` with `mode=hybrid` returns `mode_used":"hybrid"` and no warnings
- [ ] `pytest` all green incl. `tests/integration/test_pgvector.py`
- [ ] `tracelens eval` shows measured vector and hybrid rows; update docs/EVALUATION.md with those numbers
